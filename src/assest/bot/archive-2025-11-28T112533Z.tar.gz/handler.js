import './settings.js';
import btnHelper from '@ryuu-reinzz/button-helper';
const { sendInteractiveMessageV2, sendButtons } = btnHelper;
import { modul } from './module.js';
import path from 'path';
import { exec, spawn, execSync } from 'child_process';
import { color, bgcolor } from './lib/color.js';
import BodyForm from 'form-data';
const { os, axios, baileys, chalk, cheerio, FileType, fs, PhoneNumber, process, moment, speed, ms, util } = modul;
import simis from 'similarity';
const similarity = simis;
import meannn from 'didyoumean';
const didyoumean = meannn;
import { fileURLToPath } from 'url';
import { dirname } from 'path';
import { Jimp } from 'jimp';
import antiTagSW from './lib/antitagsw.js'
import {
  generateWAMessageFromContent,
  proto,
  generateWAMessageContent,
  generateWAMessage,
  prepareWAMessageMedia,
  areJidsSameUser,
  getContentType,
} from '@ryuu-reinzz/baileys';
import { 
  getRegisteredRandomId, 
  addRegisteredUser, 
  removeRegisteredUser,
  createSerial, 
  checkRegisteredUser,
  reduceUserLimit,
  theLimit,
  resetAllLimit,
  checkName
} from './lib/register.js';

import { 
  clockString,
  parseMention,
  formatp,
  isUrl,
  sleep,
  runtime,
  getBuffer,
  jsonformat,
  capital,
} from './lib/myfunc.js';

const readFile = util.promisify(fs.readFile);
const more = String.fromCharCode(8206);
const readmore = more.repeat(4001);
let db = JSON.parse(fs.readFileSync('./database/welcome.json'));

export const mainHandler = async (RyuuBotz, m, chatUpdate, store, isLogs) => {
let ntlinkgc =JSON.parse(fs.readFileSync('./database/antilinkgc.json'))
let ntlinkch =JSON.parse(fs.readFileSync('./database/antilinkch.json'))
let ntlinkall =JSON.parse(fs.readFileSync('./database/antilinkall.json'))
let isMentioned = m.mtype == "groupStatusMentionMessage";
let blacklist = JSON.parse(fs.readFileSync("./database/blacklist.json"));
try {

//==============
//AFK FUNCTION 
//==============
const afkPath = path.join(__dirname, './database/afk.json');
let afkDB = fs.existsSync(afkPath) ? JSON.parse(fs.readFileSync(afkPath)) : [];
if (!fs.existsSync(afkPath)) fs.writeFileSync(afkPath, JSON.stringify(afkDB, null, 2));

function saveAFK() {
  fs.writeFileSync(afkPath, JSON.stringify(afkDB, null, 2));
}

function clockStrink(ms) {
  let d = Math.floor(ms / 86400000);
  let h = Math.floor(ms / 3600000) % 24;
  let m = Math.floor(ms / 60000) % 60;
  let s = Math.floor(ms / 1000) % 60;
  return [
    d > 0 ? `${d} hari` : "",
    h > 0 ? `${h} jam` : "",
    m > 0 ? `${m} menit` : "",
    s > 0 ? `${s} detik` : "",
  ].filter(Boolean).join(" ");
}

//=================
// CEK AFK
//=================
let mentionUsers = [...new Set([...(m.mentionedJid || []), ...(m.quoted ? [m.quoted.sender] : [])])];
for (let jid of mentionUsers) {
  if (!m.key.fromMe) {
    // cari afk per grup
    let afkUser = afkDB.find(u => u.user === jid && u.chat === m.chat);
    if (afkUser && afkUser.afkTime > -1) {
      RyuuBotz.sendMessage(m.chat, {
        text: `🍡 *Heii~ jangan tag dulu ya~* 💬✨
📴 *Dia lagi AFK* ${afkUser.alasan ? `\n🍰 *Karena:* ${afkUser.alasan}~` : '\n🍰 *Tanpa alasan khusus~*'}
🕒 *Udah AFK selama:* ${clockStrink(new Date - afkUser.afkTime)} 💤`,
        contextInfo: {
                    forwardingScore: 1,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                    newsletterName: global.namabot,
                    newsletterJid: global.idSaluran
                },
                    externalAdReply: {
                        title: "Dia pergi afk",
                        body: global.ownername,
                        thumbnailUrl: 'https://api.ryuu-dev.offc.my.id/random/mahiruImages' 
                    },
                    mentions: [jid]
                }
            }, { quoted: m });
    }
  }
}

// kalau yang AFK sendiri kirim pesan
let senderAFK = afkDB.find(u => u.user === m.sender && u.chat === m.chat);
if (senderAFK && senderAFK.afkTime > -1) {
  await RyuuBotz.sendMessage(m.chat, {
    text: `🍥 *Heii~ @${m.sender.split("@")[0]} udah balik dari AFK loh~* ✨💬
${senderAFK.alasan ? `🍧 *Alasannya:* ${senderAFK.alasan}~` : ''}
🕒 *AFK selama:* ${clockStrink(new Date - senderAFK.afkTime)} 🍡💤`,
    contextInfo: {
            mentionedJid: [m.sender],       
            forwardingScore: 1,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                    newsletterName: global.namabot,
                    newsletterJid: global.idSaluran
                },
            externalAdReply: {
                title: "Dia kembali dari afk",
                body: global.ownername,
                thumbnailUrl: 'https://api.ryuu-dev.offc.my.id/random/mahiruImages'
            },
            mentions: [m.sender]
        }
    }, { quoted: m });

  senderAFK.afkTime = -1;
  senderAFK.alasan = '';
  saveAFK();
}
//======================
//END OF AFK FUNCTION 
//======================

if (chatUpdate?.messages) {
  for (let msg of chatUpdate.messages) {
    try {
      if (msg.key.remoteJid?.endsWith('@g.us')) {
        const m = msg.message || {}

        if (isMentioned && antiTagSW.isActive(msg.key.remoteJid)) {
          await RyuuBotz.sendMessage(msg.key.remoteJid, {
            delete: {
              remoteJid: msg.key.remoteJid,
              fromMe: false,
              id: msg.key.id,
              participant: msg.key.participant
            }
          })
        }
      }
    } catch (err) {
      console.error('❌ Antitagsw error:', err)
    }
  }
}



  async function appenTextMessage(text, chatUpdate) {
    let messages = await generateWAMessage(
      m.chat,
      {
        text: text,
        mentions: m.mentionedJid,
      },
      {
        userJid: RyuuBotz.user.id,
        quoted: m.quoted && m.quoted.fakeObj,
      },
    );
    messages.key.fromMe = areJidsSameUser(m.sender, RyuuBotz.user.id);
    messages.key.id = m.key.id;
    messages.pushName = m.pushName;
    if (m.isGroup) messages.participant = m.sender;
    let msg = {
      ...chatUpdate,
      messages: [proto.WebMessageInfo.fromObject(messages)],
      type: "append",
    };
    RyuuBotz.ev.emit("messages.upsert", msg);
  }
  const { type, quotedMsg, mentioned, now, fromMe } = m;
  let body =
  m.mtype === "interactiveResponseMessage"
    ? JSON.parse(m.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id
    : m.mtype === "conversation"
      ? m.message.conversation
      : m.mtype == "imageMessage"
        ? (m.message.imageMessage.caption || "")
        : m.mtype == "videoMessage"
          ? (m.message.videoMessage.caption || "")
          : m.mtype == "extendedTextMessage"
            ? m.message.extendedTextMessage.text
            : m.mtype == "buttonsResponseMessage"
              ? m.message.buttonsResponseMessage.selectedButtonId
              : m.mtype == "listResponseMessage"
                ? m.message.listResponseMessage.singleSelectReply.selectedRowId
                : m.mtype == "templateButtonReplyMessage"
                  ? m.message.templateButtonReplyMessage.selectedId
                  : m.mtype == "messageContextInfo"
                    ? m.message.buttonsResponseMessage?.selectedButtonId ||
                      m.message.listResponseMessage?.singleSelectReply?.selectedRowId ||
                      m.text
                    : m.mtype === "editedMessage"
                      ? m.message.editedMessage.message.protocolMessage.editedMessage.extendedTextMessage
                        ? m.message.editedMessage.message.protocolMessage.editedMessage.extendedTextMessage.text
                        : m.message.editedMessage.message.protocolMessage.editedMessage.conversation || ""
                      : "";

const premium = JSON.parse(fs.readFileSync("./database/premium.json"))

if (m.key.remoteJid && m.key.remoteJid.endsWith('@newsletter')) {
    return;
}        
const budy = (typeof m.text == 'string' ? m.text : '.')

let preff;
if (global.pref === true) {
    preff = global.prefix;
} else if (global.pref === false) {
    preff = ['']; 
} else {
    preff = ['.']; 
}

  const prefixes = preff;
  const prefix = prefixes.find(p => body.startsWith(p));
  const chath = body;
  const pes = body || "";
  const messagesC = pes.slice(0).trim();
  const content = JSON.stringify(m.message);
  const isCmd = prefix !== undefined;
  const from = m.key.remoteJid;
  const messagesD = body.slice(0).trim().split(/ +/).shift().toLowerCase();
  const args = body.trim().split(/ +/).slice(1)  
  const command = isCmd 
  ? body.slice(prefix.length).trim().split(/ +/).shift().toLowerCase() : '';
  const botNumber = await RyuuBotz.decodeJid(RyuuBotz.user.id);
  const botLid = (await RyuuBotz.getLidFromPN(m.chat, botNumber))
  const isLidCreator = m.sender === global.lidownernumber.replace(/[^0-9]/g, "") + "@lid";
  const isJidCreator = m.sender === global.ownernumber.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
  const isCreator = isJidCreator || isLidCreator;
  const isLimit = theLimit(m.sender)
  const pushname = m.pushName || "Nothing";
  const text = args.join(" ");
  const isAsync = budy.slice(2).trim().length > 0;
  const q = args.join(" ");
  const quoted = m.quoted ? m.quoted : m;
  const mime = (quoted.msg || quoted).mimetype || "";
  const qmsg = quoted.msg || quoted;
  const isMedia = /image|video|sticker|audio/.test(mime);
  const isImage = m.mtype == "imageMessage";
  const isVideo = m.mtype == "videoMessage";
  const isAudio = m.mtype == "audioMessage";
  const isSticker = m.mtype == "stickerMessage";
  const isQuotedImage =
    type === "extendedTextMessage" && content.includes("imageMessage");
  const isQuotedLocation =
    type === "extendedTextMessage" && content.includes("locationMessage");
  const isQuotedVideo =
    type === "extendedTextMessage" && content.includes("videoMessage");
  const isQuotedSticker =
    type === "extendedTextMessage" && content.includes("stickerMessage");
  const isQuotedAudio =
    type === "extendedTextMessage" && content.includes("audioMessage");
  const isQuotedContact =
    type === "extendedTextMessage" && content.includes("contactMessage");
  const isQuotedDocument =
    type === "extendedTextMessage" && content.includes("documentMessage");
  const sender = m.isGroup
    ? m.key.participant
      ? m.key.participant
      : m.participant
    : m.key.remoteJid;
  const senderNumber = sender.split("@")[0];
  const groupMetadata = m.isGroup
    ? await RyuuBotz.groupMetadata(m.chat).catch((e) => {})
    : "";
  const participants =
    m.isGroup && groupMetadata ? groupMetadata.participants : [];
  const groupAdmins = m.isGroup
    ? await participants.filter((v) => v.admin !== null).map((v) => v.id)
    : [];
  const groupName = m.isGroup && groupMetadata ? groupMetadata.subject : [];
  const groupOwner = m.isGroup && groupMetadata ? groupMetadata.owner : [];
  const groupMembership =
    m.isGroup && groupMetadata ? groupMetadata.membership : [];
  const groupMembers =
    m.isGroup && groupMetadata ? groupMetadata.participants : [];
  const isBotAdmins = m.isGroup ? groupAdmins.includes(botLid) : false;
  const isGroupAdmins = m.isGroup ? groupAdmins.includes(m.participant) : false;
  const isAdmins = m.isGroup ? groupAdmins.includes(m.participant) : false;
  const Antilinkgc = m.isGroup ? ntlinkgc.includes(m.chat) : false
  const Antilinkch = m.isGroup ? ntlinkch.includes(m.chat) : false
  const Antilinkall = m.isGroup ? ntlinkall.includes(m.chat) : false
  const rawPremium = premium.includes(m.sender);
  const isPremium = rawPremium || isCreator;
  const isRegistered = checkRegisteredUser(m.sender)
  const delay = ms => new Promise(resolve => setTimeout(resolve, ms))
 const deviceinfo = /^3A/.test(m.id) ? 'ɪᴏs' : m.id.startsWith('3EB') ? 'ᴡᴇʙ' : /^.{21}/.test(m.id) ? 'ᴀɴᴅʀᴏɪᴅ' : /^.{18}/.test(m.id) ? 'ᴅᴇsᴋᴛᴏᴘ' : 'ᴜɴᴋɴᴏᴡ';
  const ments = (text) => {
  return text.match('@') ? [...text.matchAll(/@([0-9]{5,16}|0)/g)].map(v => v[1] + '@s.whatsapp.net') : []}
  const froms = m.quoted ? m.quoted.sender : text ? (text.replace(/[^0-9]/g, '') ? text.replace(/[^0-9]/g, '') + '@s.whatsapp.net' : false) : false;
  const mentionUser = [
    ...new Set([
      ...(m.mentionedJid || []),
      ...(m.quoted ? [m.quoted.sender] : []),
    ]),
  ];
  const Spath = './database/sticker-cmd.json'
const stickerDB = fs.existsSync(Spath)
  ? JSON.parse(fs.readFileSync(Spath))
  : {}
  const mentionByTag =
    type == "extendedTextMessage" &&
    m.message.extendedTextMessage.contextInfo != null
      ? m.message.extendedTextMessage.contextInfo.mentionedJid
      : [];
  const mentionByReply =
    type == "extendedTextMessage" &&
    m.message.extendedTextMessage.contextInfo != null
      ? m.message.extendedTextMessage.contextInfo.participant || ""
      : "";
  const numberQuery =
    q.replace(new RegExp("[()+-/ +/]", "gi"), "") + "@s.whatsapp.net";
  const usernya = mentionByReply ? mentionByReply : mentionByTag[0];
  const Input = mentionByTag[0]
    ? mentionByTag[0]
    : mentionByReply
      ? mentionByReply
      : q
        ? numberQuery
        : false;
              
  const xtime = moment.tz("Asia/Jakarta").format("HH:mm:ss");
  const xdate = moment.tz("Asia/Jakarta").format("DD/MM/YYYY");
  const time2 = moment().tz("Asia/Jakarta").format("HH:mm:ss");
  if (time2 < "23:59:00") {
    var timewisher = `Selamat Malam`;
  }
  if (time2 < "19:00:00") {
    var timewisher = `Selamat Malam`;
  }
  if (time2 < "18:00:00") {
    var timewisher = `Selamat Sore`;
  }
  if (time2 < "15:00:00") {
    var timewisher = `Selamat Siang`;
  }
  if (time2 < "11:00:00") {
    var timewisher = `Selamat Pagi`;
  }
  if (time2 < "05:00:00") {
    var timewisher = `Selamat Pagi`;
  }
  let sekarang = new Date(
    new Date().toLocaleString("en-US", { timeZone: "Asia/Jakarta" }),
  );
  function tanggal(ms) {
    return new Date(ms).getDate().toString().padStart(2, "0");
  }
  function bulan(ms) {
    return (new Date(ms).getMonth() + 1).toString().padStart(2, "0"); 
  }
  function tahun(ms) {
    return new Date(ms).getFullYear();
  }
  function formatJam(date) {
    let jam = date.getHours().toString().padStart(2, "0");
    let menit = date.getMinutes().toString().padStart(2, "0");
    let detik = date.getSeconds().toString().padStart(2, "0");
    return `${jam}:${menit}:${detik}`;
  }
  let futureDescription = `
📅 *Update Kurs:* ${tanggal(sekarang.getTime())}/${bulan(sekarang.getTime())}/${tahun(sekarang.getTime())}
🕰 *Waktu Jakarta (WIB):* ${formatJam(sekarang)}`;

//Quoted\\
const qmeta = {
  key: {
    participant: "13135550002@s.whatsapp.net",
    remoteJid: "status@broadcast",
  },
  message: {
    contactMessage: {
      displayName: global.namabot,
      vcard: `BEGIN:VCARD\nVERSION:3.0\nN:XL;ttname,;;;\nFN:ttname\nitem1.TEL;waid=13135550002:+62 852-9802-7445\nitem1.X-ABLabel:Ponsel\nEND:VCARD`,
      sendEphemeral: true,
    },
  },
};
const qbotz = {
  key: {
    participant: "6288704756515@s.whatsapp.net",
    remoteJid: "status@broadcast",
  },
  message: {
    contactMessage: {
      displayName: global.namabot,
      vcard: `BEGIN:VCARD\nVERSION:3.0\nN:XL;ttname,;;;\nFN:ttname\nitem1.TEL;waid=6288704756515:+62 887-0475-6515\nitem1.X-ABLabel:Ponsel\nEND:VCARD`,
      sendEphemeral: true,
    },
  },
};

const qgrup = {
  key: {
    participant: "6288704756515@s.whatsapp.net",
    remoteJid: "status@broadcast",
  },
  message: {
    contactMessage: {
      displayName: "Minna!!",
      vcard: `BEGIN:VCARD\nVERSION:3.0\nN:XL;ttname,;;;\nFN:ttname\nitem1.TEL;waid=6288704756515:+62 887-0475-6515\nitem1.X-ABLabel:Ponsel\nEND:VCARD`,
      sendEphemeral: true,
    },
  },
};

const qtext = {
  key: {
    remoteJid: "status@broadcast",
    participant: "0@s.whatsapp.net",
  },
  message: {
    extendedTextMessage: {
      text: `${prefix + command}`,
    },
  },
};

const qbug = {
  key: {
    remoteJid: "status@broadcast",
    fromMe: false,
    participant: "0@s.whatsapp.net",
  },
  message: {
    listResponseMessage: {
      title: `${global.ownername}`,
    },
  },
};

const qdoc = {
  key: {
    participant: "0@s.whatsapp.net",
    ...(m.chat ? { remoteJid: "status@broadcast" } : {}),
  },
  message: {
    documentMessage: {
      title: `${global.ownername}`,
      jpegThumbnail: "",
    },
  },
};

const qloc = {
  key: {
    participant: "0@s.whatsapp.net",
    ...(m.chat ? { remoteJid: "status@broadcast" } : {}),
  },
  message: {
    locationMessage: {
      name: `${global.ownername}`,
      jpegThumbnail: "",
    },
  },
};

const qloc2 = {
  key: {
    participant: "0@s.whatsapp.net",
    ...(m.chat ? { remoteJid: "status@broadcast" } : {}),
  },
  message: {
    locationMessage: {
      name: `${global.ownername}`,
      jpegThumbnail: "",
    },
  },
};

const qpayment = {
  key: {
    remoteJid: "0@s.whatsapp.net",
    fromMe: false,
    id: `ownername`,
    participant: "0@s.whatsapp.net",
  },
  message: {
    requestPaymentMessage: {
      currencyCodeIso4217: "USD",
      amount1000: 999999999,
      requestFrom: "0@s.whatsapp.net",
      noteMessage: {
        extendedTextMessage: {
          text: "𝙕͢𝙖𝙝𝙡𝙚𝙖",
        },
      },
      expiryTimestamp: 999999999,
      amount: {
        value: 91929291929,
        offset: 1000,
        currencyCode: "USD",
      },
    },
  },
};

const qtoko = {
  key: {
    fromMe: false,
    participant: "0@s.whatsapp.net",
    ...(m.chat ? { remoteJid: "status@broadcast" } : {}),
  },
  message: {
    productMessage: {
      product: {
        productImage: {
          mimetype: "image/jpeg",
          jpegThumbnail: "",
        },
        title: `${global.ownername}`,
        description: null,
        currencyCode: "IDR",
        priceAmount1000: "1000000000",
        retailerId: `${global.ownername}`,
        productImageCount: 1,
      },
      businessOwnerJid: "0@s.whatsapp.net",
    },
  },
};

const qlive = {
  key: {
    participant: "0@s.whatsapp.net",
    ...(m.chat ? { remoteJid: "status@broadcast" } : {}),
  },
  message: {
    liveLocationMessage: {
      caption: `${global.ownername}`,
      jpegThumbnail: "",
    },
  },
};
// Reply function 
async function replymahiru(text) {

    await RyuuBotz.sendMessage(m.chat, {
        text,
        contextInfo: {
            forwardingScore: 1,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterName: global.ownername,
                newsletterJid: global.idSaluran
            },
            externalAdReply: {
                title: 'Mahiru-AI',
                body: global.ownername,
                thumbnailUrl: 'https://api.ryuu-dev.offc.my.id/random/mahiruImages'
            }
        }
    }, { quoted: m });
}

async function replyalma(text) {

    await RyuuBotz.sendMessage(m.chat, {
        text,
        contextInfo: {
            forwardingScore: 1,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterName: global.ownername,
                newsletterJid: global.idSaluran
            },
            externalAdReply: {
                title: 'Alma-AI',
                body: global.ownername,
                thumbnailUrl: 'https://api.ryuu-dev.offc.my.id/src/assest/bot/alma-ai.jpg'
            }
        }
    }, { quoted: m });
}

async function replymarin(text) {

    await RyuuBotz.sendMessage(m.chat, {
        text,
        contextInfo: {
            forwardingScore: 1,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterName: global.ownername,
                newsletterJid: global.idSaluran
            },
            externalAdReply: {
                title: 'Marin-AI',
                body: global.ownername,
                thumbnailUrl: 'https://cdn.aceimg.com/56310de3b.jpg'
            }
        }
    }, { quoted: m });
}

async function replyrio(text) {

    await RyuuBotz.sendMessage(m.chat, {
        text,
        contextInfo: {
            forwardingScore: 1,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterName: global.ownername,
                newsletterJid: global.idSaluran
            },
            externalAdReply: {
                title: 'Rio-AI',
                body: global.ownername,
                thumbnailUrl: 'https://files.catbox.moe/o2yq2c.jpg'
            }
        }
    }, { quoted: m });
}

async function replyelaina(text) {

    await RyuuBotz.sendMessage(m.chat, {
        text,
        contextInfo: {
            forwardingScore: 1,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterName: global.ownername,
                newsletterJid: global.idSaluran
            },
            externalAdReply: {
                title: 'Elaina-AI',
                body: global.ownername,
                thumbnailUrl: 'https://files.catbox.moe/j6uoif.jpg'
            }
        }
    }, { quoted: m });
}

async function replyaoi(text) {
    await RyuuBotz.sendMessage(m.chat, {
        text,
        contextInfo: {
            forwardingScore: 1,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterName: 'Character AI',
                newsletterJid: global.idSaluran
            },
            externalAdReply: {
                title: 'Aoi-AI',
                body: global.ownername,
                thumbnailUrl: 'https://files.catbox.moe/gy0b0m.jpg'
            }
        }
    }, { quoted: m });
}

async function replyamelia(text) {
    await RyuuBotz.sendMessage(m.chat, {
        text,
        contextInfo: {
            forwardingScore: 1,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterName: 'Character AI',
                newsletterJid: global.idSaluran
            },
            externalAdReply: {
                title: 'Amelia-AI',
                body: global.ownername,
                thumbnailUrl: 'https://files.catbox.moe/tlv50f.jpg'
            }
        }
    }, { quoted: m });
}

async function replyiroha(text) {
    await RyuuBotz.sendMessage(m.chat, {
        text,
        contextInfo: {
            forwardingScore: 1,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterName: 'Character AI',
                newsletterJid: global.idSaluran
            },
            externalAdReply: {
                title: 'Iroha-AI',
                body: global.ownername,
                thumbnailUrl: 'https://files.catbox.moe/ii8hg1.jpg'
            }
        }
    }, { quoted: m });
}

async function replymongfa(text) {
    await RyuuBotz.sendMessage(m.chat, {
        text,
        contextInfo: {
            forwardingScore: 1,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterName: 'Character AI',
                newsletterJid: global.idSaluran
            },
            externalAdReply: {
                title: 'Mongfa-AI',
                body: global.ownername,
                thumbnailUrl: 'https://files.catbox.moe/96e0td.jpg'
            }
        }
    }, { quoted: m });
}

async function replykarin(text) {
    await RyuuBotz.sendMessage(m.chat, {
        text,
        contextInfo: {
            forwardingScore: 1,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterName: 'Character AI',
                newsletterJid: global.idSaluran
            },
            externalAdReply: {
                title: 'Karin-AI',
                body: global.ownername,
                thumbnailUrl: 'https://files.catbox.moe/jjbu7b.jpg'
            }
        }
    }, { quoted: m });
}
async function reply(text) {
    
    RyuuBotz.sendMessage(m.chat, {
        text,
        contextInfo: {
            forwardingScore: 1,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterName: '𝙕͢𝙖𝙝𝙡𝙚𝙖',
                newsletterJid: global.idSaluran
            },
            externalAdReply: {
                title: global.namabot,
                body: global.ownername,
                thumbnailUrl: 'https://api.ryuu-dev.offc.my.id/random/mahiruImages'
            }
        }
    }, { quoted: m });
}
async function reply_(text) {
    
    RyuuBotz.sendMessage(m.chat, {
        text,
        contextInfo: {
            mentionedJid: [botNumber],
            forwardingScore: 1,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterName: '𝙕͢𝙖𝙝𝙡𝙚𝙖',
                newsletterJid: global.idSaluran
            },
            externalAdReply: {
                title: global.namabot,
                body: global.ownername,
                thumbnailUrl: 'https://api.ryuu-dev.offc.my.id/random/mahiruImages'
            }
        }
    }, { quoted: m });
}
const replyafk = (text) => {

    RyuuBotz.sendMessage(m.chat, {
        text,
        contextInfo: {      
            mentionedJid: [m.sender],
            forwardingScore: 1,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                    newsletterName: global.namabot,
                    newsletterJid: global.idSaluran
                },
            externalAdReply: {
                title: 'Dia mau Afk',
                body: global.ownername,
                thumbnailUrl: "https://api.ryuu-dev.offc.my.id/random/mahiruImages"
            },
            mentions: [m.sender]
        }
    }, { quoted: m });
};
const replyitsuki = (text) => {
    RyuuBotz.sendMessage(m.chat, {
        text,
        contextInfo: {
            forwardingScore: 1,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterName: global.namabot,
                newsletterJid: global.idSaluran
            },
            externalAdReply: {
                title: 'Itsuki-AI',
                body: global.ownername,
                thumbnailUrl: 'https://files.catbox.moe/iwxe5y.jpg'
            }
        }
    }, { quoted: m });
};
const replymiku = (text) => {
    RyuuBotz.sendMessage(m.chat, {
        text,
        contextInfo: {
            forwardingScore: 1,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterName: global.namabot,
                newsletterJid: global.idSaluran
            },
            externalAdReply: {
                title: 'Miku-AI',
                body: global.ownername,
                thumbnailUrl: 'https://files.catbox.moe/no85cx.jpg'
            }
        }
    }, { quoted: m });
};
const reply2 = (teks) => {
RyuuBotz.sendMessage(from, { text : teks }, { quoted : m })
}
const example = (teks) => {
return `\n *Contoh Penggunaan :*\n Ketik *${prefix+command}* ${teks}\n`
}

    
if (m.message) {
  if (isLogs) {
    const accent = chalk.hex("#FFB347")
const highlight = chalk.hex("#FFD369")
const dim = chalk.gray

const time = highlight(moment().tz('Asia/Jakarta').format('DD/MM/YYYY HH:mm:ss'))
const msgType = accent(budy ? budy : m.mtype)
const keyId = `${chalk.white(m.key.id)}`
const sender = `${chalk.white(pushname)} ${dim(`<${m.sender}>`)}`
const location = m.isGroup
  ? `${accent('👥 Group')} ${chalk.white(groupName)} ${dim(`(${m.chat})`)}`
  : highlight('✉️ Private Chat')

console.log(`
${highlight("╔══════════════════ ✦ MESSAGE LOG ✦ ══════════════════╗")}
 ${dim("│")} ⏰ ${chalk.cyan.bold("Time:")} ${time}
 ${dim("│")} 💬 ${chalk.cyan.bold("Message:")} ${msgType}
 ${dim("│")} 🙋 ${chalk.cyan.bold("Sender:")} ${sender}
 ${dim("│")} 🎮 ${chalk.cyan.bold("ID:")} ${keyId}
 ${dim("│")} 📍 ${chalk.cyan.bold("Location:")} ${location}
${highlight("╚═════════════════════════════════════════════════════╝")}
`)
if (global.autoread) {
 RyuuBotz.readMessages([m.key]);
  };
 };
};
 let lidSender = await RyuuBotz.getLidFromPN(m.chat, m.sender);
 if (m.isGroup) {
   if (blacklist.includes(lidSender)) {
    await RyuuBotz.sendMessage(m.key.remoteJid, {
      delete: {
        remoteJid: m.key.remoteJid,
        fromMe: false,
        id: m.key.id,
        participant: m.key.participant
       }
      });
    }
   }
if (!m.fromMe) {
  if (Antilinkgc) {
    if (budy.match(`chat.whatsapp.com`)) { 
      
      if (isCreator) {
        return RyuuBotz.sendMessage(m.chat, {
          text: global.antilink.owner,
          contextInfo: {
            externalAdReply: {
              title: "🍰 Group Link Terdeteksi ✨",
              body: "💬 Pesan diizinkan",
              thumbnailUrl: "https://api.ryuu-dev.offc.my.id/random/mahiruImages",
              sourceUrl: "https://api.ryuu-dev.offc.my.id",
              mediaType: 1
            }
          }
        }, { quoted: m });
      }

      if (isAdmins) {
        return RyuuBotz.sendMessage(m.chat, {
          text: global.antilink.admin,
          contextInfo: {
            externalAdReply: {
              title: "🍰 Group Link Terdeteksi ✨",
              body: "💬 Pesan diizinkan",
              thumbnailUrl: "https://api.ryuu-dev.offc.my.id/random/mahiruImages",
              sourceUrl: "https://api.ryuu-dev.offc.my.id",
              mediaType: 1
            }
          }
        }, { quoted: m });
      }

      await RyuuBotz.sendMessage(m.chat, {
        delete: {
          remoteJid: m.chat,
          fromMe: false,
          id: m.key.id,
          participant: m.key.participant
        }
      });

      RyuuBotz.sendMessage(m.chat, {
        text: `🍧 *@${m.sender.split("@")[0]} ngirim link grup dan udah dihapus ya~* 💦`,
        contextInfo: {
          mentionedJid: [m.sender],
          externalAdReply: {
            title: "🍡 Group Link Dihapus 💨",
            body: "⚠️ Pesan terdeteksi dan sudah dihapus otomatis~",
            thumbnailUrl: "https://api.ryuu-dev.offc.my.id/random/mahiruImages",
            sourceUrl: "https://api.ryuu-dev.offc.my.id",
            mediaType: 1
          }
        }
      }, { quoted: m });
    }
  }

  if (Antilinkch) {
    if (budy.match(`whatsapp.com/channel/`)) {

      let gclink = "https://whatsapp.com/channel/0029Vb5xetZBadmS2IPdmG1X";
      let isLinkThisGc = new RegExp(gclink, "i");
      let isgclink = isLinkThisGc.test(m.text);

      if (isgclink) {
        return RyuuBotz.sendMessage(m.chat, {
          text: global.antilink.ch,
          contextInfo: {
            externalAdReply: {
              title: "🍰 Channel Link Terdeteksi ✨",
              body: "💬 Pesan diizinkan karena link milik owner grup~",
              thumbnailUrl: "https://api.ryuu-dev.offc.my.id/random/mahiruImages",
              sourceUrl: "https://api.ryuu-dev.offc.my.id",
              mediaType: 1
            }
          }
        }, { quoted: m });
      }

      if (isCreator) {
        return RyuuBotz.sendMessage(m.chat, {
          text: global.antilink.owner,
          contextInfo: {
            externalAdReply: {
              title: "🍡 Channel Link Terdeteksi ✨",
              body: "💬 Pesan diizinkan",
              thumbnailUrl: "https://api.ryuu-dev.offc.my.id/random/mahiruImages",
              sourceUrl: "https://api.ryuu-dev.offc.my.id",
              mediaType: 1
            }
          }
        }, { quoted: m });
      }

      if (isAdmins) {
        return RyuuBotz.sendMessage(m.chat, {
          text: global.antilink.admin,
          contextInfo: {
            externalAdReply: {
              title: "🍰 Channel Link Terdeteksi ✨",
              body: "💬 Pesan diizinkan",
              thumbnailUrl: "https://api.ryuu-dev.offc.my.id/random/mahiruImages",
              sourceUrl: "https://api.ryuu-dev.offc.my.id",
              mediaType: 1
            }
          }
        }, { quoted: m });
      }

      await RyuuBotz.sendMessage(m.chat, {
        delete: {
          remoteJid: m.chat,
          fromMe: false,
          id: m.key.id,
          participant: m.key.participant
        }
      });

      await RyuuBotz.sendMessage(m.chat, {
        text: `🍡 *@${m.sender.split("@")[0]} ngirim link channel dan udah dihapus ya~* 💨`,
        contextInfo: {
          mentionedJid: [m.sender],
          externalAdReply: {
            title: "🍰 Channel Link Dihapus 💦",
            body: "⚠️ Link terdeteksi",
            thumbnailUrl: "https://api.ryuu-dev.offc.my.id/random/mahiruImages",
            sourceUrl: "https://api.ryuu-dev.offc.my.id",
            mediaType: 1
          }
        }
      }, { quoted: m });
    }
  }

  if (Antilinkall) {
    let tldList = [];
    try {
      tldList = JSON.parse(fs.readFileSync("./database/domain.json"));
    } catch (e) {
      console.error("Gagal membaca file domain.json:", e);
    }

    const whitelist = ["https://api.ryuu-dev.offc.my.id"];

    if (tldList.length > 0) {
      const foundTLD = tldList.find(tld => {
        const regex = new RegExp(`\\b[a-z0-9-]+\\.${tld}\\b`, "i");
        return regex.test(budy);
      });

      const isWhitelisted = whitelist.some(w =>
        budy.toLowerCase().includes(w.toLowerCase())
      );

      if (foundTLD && !isWhitelisted) {
        if (isCreator) {
          return RyuuBotz.sendMessage(m.chat, {
            text: global.antilink.owner,
            contextInfo: {
              externalAdReply: {
                title: "🍰 Link Terdeteksi ✨",
                body: "💬 Pesan diizinkan",
                thumbnailUrl: "https://api.ryuu-dev.offc.my.id/random/mahiruImages",
                sourceUrl: "https://api.ryuu-dev.offc.my.id",
                mediaType: 1
              }
            }
          }, { quoted: m });
        }

        if (isAdmins) {
          return RyuuBotz.sendMessage(m.chat, {
            text: global.antilink.admin,
            contextInfo: {
              externalAdReply: {
                title: "🍰 Link Terdeteksi ✨",
                body: "💬 Pesan diizinkan",
                thumbnailUrl: "https://api.ryuu-dev.offc.my.id/random/mahiruImages",
                sourceUrl: "https://api.ryuu-dev.offc.my.id",
                mediaType: 1
              }
            }
          }, { quoted: m });
        }

        await RyuuBotz.sendMessage(m.chat, {
          delete: {
            remoteJid: m.chat,
            fromMe: false,
            id: m.key.id,
            participant: m.key.participant
          }
        });

        RyuuBotz.sendMessage(m.chat, {
          text: `🍧 *@${m.sender.split("@")[0]} ngirim link (.${foundTLD}) dan udah dihapus ya~* 💦`,
          contextInfo: {
            mentionedJid: [m.sender],
            externalAdReply: {
              title: "🍡 Link Dihapus 💨",
              body: "⚠️ Link terdeteksi",
              thumbnailUrl: "https://api.ryuu-dev.offc.my.id/random/mahiruImages",
              sourceUrl: "https://api.ryuu-dev.offc.my.id",
              mediaType: 1
            }
          }
        }, { quoted: m });
      }
    }
  }
}

// Respon Cmd with media
if (isSticker && (m.msg.fileSha256.toString() in stickerDB)) {
    const hash = m.msg.fileSha256.toString()
    const { text, mentionedJid } = stickerDB[hash]

    const fakeMsg = {
        key: {
            remoteJid: m.chat,
            fromMe: false,
            id: m.key.id,
            participant: m.sender
        },
        message: {
            conversation: text
        },
        pushName: m.pushName,
        sender: m.sender,
        mentionedJid
    }
    RyuuBotz.ev.emit('messages.upsert', {
        messages: [fakeMsg],
        type: 'append'
    })
}

try {
  if (typeof m.text === 'string' && new RegExp(`@${global.ownernumber || global.lidownernumber}`, 'i').test(m.text)) {
    if (!isCreator && !m.fromMe) {
      const stickerBuffer = fs.readFileSync('./stiker/apa-woi.webp');
      RyuuBotz.sendImageAsSticker(
        m.chat,
        stickerBuffer,
        m,
        {
          packname: `Jangan tag owner ku 😡`
        },
        {
          quoted: m
        }
      )
      RyuuBotz.sendMessage(
      m.chat,
      {
        video: { url : "https://api.ryuu-dev.offc.my.id/src/assest/mahiru/VID-20250830-WA0024.mp4" },
        ptv: true
});
    }
  }
} catch (err) {
  console.error('Error saat mengirim stiker:', err);
  reply(`Owner ku pusing anj😭\n*Error:* ${err.message}`);
}
// ─────乂  ALL FUNCTION ────乂 \\
function saveStickerDB() {
  fs.writeFileSync(Spath, JSON.stringify(stickerDB, null, 2))
}
setInterval(() => {
  const now = new Date()
  if (now.getHours() === 0 && now.getMinutes() === 0) {
    resetAllLimit()
  }
}, 60 * 1000)

function cekSelfStatus(noJadibot) {
  const dir = `./database/jadibot/${noJadibot}`;
  const filePath = `${dir}/code-${noJadibot}.json`;

  if (!fs.existsSync(filePath)) return false;

  try {
    const raw = fs.readFileSync(filePath, "utf8");
    const json = JSON.parse(raw);
    return json.self === true;
  } catch {
    return false;
  }
}
const noBotz = RyuuBotz.user.id;             
const noJadibot = noBotz.split(":")[0];       
const jadibotSelf = cekSelfStatus(noJadibot);
if (jadibotSelf) {
  if (!isCreator && !m.key.fromMe) {
    return;
  }
}
if (self_) {
   if (!isCreator && !m.key.fromMe) { 
    return;    
  }
}

async function RyuuCloud(filePath) {
	try {
		const fileStream = fs.createReadStream(filePath);
		const formData = new BodyForm();
		formData.append('file', fileStream);
		const response = await axios.post('https://files.ryuu-dev.offc.my.id/api/upload', formData, {
			headers:
			 { ...formHeaders },
		});
		return response.data;
	} catch (error) {
		console.error("Error at RyuuCloud uploader:", error);
		return "Terjadi kesalahan saat upload ke RyuuCloud.";
	}
};

async function CatBox(filePath) {
	try {
		const fileStream = fs.createReadStream(filePath);
		const formData = new BodyForm();
		formData.append('fileToUpload', fileStream);
		formData.append('reqtype', 'fileupload');
		formData.append('userhash', '');
		const response = await axios.post('https://catbox.moe/user/api.php', formData, {
			headers: {
				...formData.getHeaders(),
			},
		});
		return response.data;
	} catch (error) {
		console.error("Error at Catbox uploader:", error);
		return "Terjadi kesalahan saat upload ke Catbox.";
	}
};

async function loadingBar(m, RyuuBotz) {
try {
if (BarLoad) {
  const createProgressBar = (value, maxValue, length) => {
    const percentage = value / maxValue;
    const progress = Math.round(length * percentage);
    const empty = length - progress;
    return `[${"█".repeat(progress)}${"░".repeat(empty)}]`;
  };

  let progress = 0;
  let message = await RyuuBotz.sendMessage(
    m.chat,
    { text: `Loading...\n${createProgressBar(progress, 100, 20)} ${progress}%` },
    { quoted: m }
  );

  while (progress < 100) {
    await global.sleep(100);
    progress += 5;
    const newText = `Loading...\n${createProgressBar(progress, 100, 20)} ${progress}%`;

    await RyuuBotz.relayMessage(
      m.chat,
      {
        protocolMessage: {
          key: message.key,
          type: 14,
          editedMessage: { conversation: newText }
        }
      },
      {}
    );
  }

  const finalText = `Loading Selesai!!!`;
  await RyuuBotz.relayMessage(
    m.chat,
    {
      protocolMessage: {
        key: message.key,
        type: 14,
        editedMessage: { conversation: finalText }
      }
    },
    {}
  );

  return message;
  } else {
  await RyuuBotz.sendMessage(m.chat, { react: { text: '⏱️', key: m.key } });
  }
  } catch(err) {
  console.log('error bang :v', err);
  reply(`Yah error ${err}`);
  }
}

  async function sendconnMessage(chatId, message, options = {}) {
    let generate = await generateWAMessage(chatId, message, options);
    let type2 = getContentType(generate.message);
    if ("contextInfo" in options)
      generate.message[type2].contextInfo = options?.contextInfo;
    if ("contextInfo" in message)
      generate.message[type2].contextInfo = message?.contextInfo;
    return await RyuuBotz.relayMessage(chatId, generate.message, {
      messageId: generate.key.id,
    });
  }
  
  function GetType(Data) {
    return new Promise((resolve, reject) => {
      let Result, Status;
      if (Buffer.isBuffer(Data)) {
        Result = new Buffer.from(Data).toString("base64");
        Status = 0;
      } else {
        Status = 1;
      }
      resolve({
        status: Status,
        result: Result,
      });
    });
  }
  
  function randomId() {
    return Math.floor(100000 + Math.random() * 900000);
  }
  
  function monospace(string) {
    return '```' + string + '```'
}

function monospa(string) {
    return '`' + string + '`'
}

function getRandomFile(ext) {
return `${Math.floor(Math.random() * 10000)}${ext}`;
}

function pickRandom(list) {
return list[Math.floor(Math.random() * list.length)]
}

function randomNomor(min, max = null){
if (max !== null) {
min = Math.ceil(min);
max = Math.floor(max);
return Math.floor(Math.random() * (max - min + 1)) + min;
} else {
return Math.floor(Math.random() * min) + 1
}
}

function generateRandomPassword() {
const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#%^&*';
const length = 10;
let password = '';
for (let i = 0; i < length; i++) {
const randomIndex = Math.floor(Math.random() * characters.length);
password += characters[randomIndex];
}
return password;
}

function generateRandomNumber(min, max) {
return Math.floor(Math.random() * (max - min + 1)) + min;
}

    async function listbut2(m, teks, listnye, qtext) {
let msg = generateWAMessageFromContent(m.chat, {
viewOnceMessage: {
message: {
"messageContextInfo": {
"deviceListMetadata": {},
"deviceListMetadataVersion": 2
},
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: {
mentionedJid: [m.sender],
forwardingScore: 999999,
isForwarded: true,
forwardedNewsletterMessageInfo: {
newsletterJid: `120363405649403674@newsletter`,
newsletterName: `— ${namabot} AI WhatsApp Bot`,
serverMessageId: 145
}
},
body: proto.Message.InteractiveMessage.Body.create({
text: teks
}),
footer: proto.Message.InteractiveMessage.Footer.create({
text: `${namabot} By ${ownername}`
}),
header: proto.Message.InteractiveMessage.Header.create({
title: ``,
thumbnailUrl: "",
gifPlayback: true,
subtitle: "",
hasMediaAttachment: true,
...(await prepareWAMessageMedia({ image: { url: 'https://files.catbox.moe/rj0ok0.jpg' } }, { upload: RyuuBotz.waUploadToServer })),
}),
gifPlayback: true,
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
buttons: [
{
"name": "single_select",
"buttonParamsJson": JSON.stringify(listnye)
}],
}), })}
}}, {quoted: qtext})
await RyuuBotz.relayMessage(msg.key.remoteJid, msg.message, {
messageId: msg.key.id
})
}

async function dellCase(filePath, caseNameToRemove) {
            fs.readFile(filePath, 'utf8', (err, data) => {
                if (err) {
                    console.error('Terjadi kesalahan:', err);
                    return;
                }

                const regex = new RegExp(`case\\s+'${caseNameToRemove}':[\\s\\S]*?break`, 'g');
                const modifiedData = data.replace(regex, '');

                fs.writeFile(filePath, modifiedData, 'utf8', (err) => {
                    if (err) {
                        console.error('Terjadi kesalahan saat menulis file:', err);
                        return;
                    }

                    console.log(`Teks dari case '${caseNameToRemove}' telah dihapus dari file.`);
                });
            });
        }
        
  
const pluginsLoader = async (directory) => {
  let plugins = [];
  const folders = fs.readdirSync(directory);

  for (const file of folders) {
    const filePath = path.join(directory, file);
    if (filePath.endsWith('.js')) {
      try {
        const plugin = await import(`file://${filePath}?update=${Date.now()}`);
        plugins.push(plugin.default || plugin);
      } catch (error) {
        console.log(`Error loading plugin at ${filePath}:`, error);
      }
    }
  }
  return plugins;
};

let pluginsDisable = true;
const pluginsDir = path.resolve(__dirname, "plugins");
let plugins = await pluginsLoader(pluginsDir);


const ryuu_dev = {
  RyuuBotz, prefix, command, reply, replyafk, afkDB, text,
  isGroup: m.isGroup, isCreator, example, sender, senderNumber,
  pushname, args, runtime, formatp, sleep, getBuffer, isBotAdmins,
  isAdmins, isCmd, qtext, isPremium, randomNomor, monospace,
  pickRandom, getRandomFile, groupMetadata, saveAFK, participants,
  createSerial, deviceinfo, isRegistered, addRegisteredUser, removeRegisteredUser, db, q,
  replykarin, replymongfa, replyiroha, replyamelia, replyaoi,
  replymarin, replymahiru, replyelaina, replyrio, replymiku, replyitsuki, replyalma, mime, quoted,
  qgrup, loadingBar, checkName, stickerDB, saveStickerDB, isAsync, budy, util, exec
};

if (isCmd) {
  let pluginCommands = [];
  for (let plugin of plugins) {
    if (plugin.command) {
      pluginCommands.push(...plugin.command.map(c => c.toLowerCase()));
    }
  }

  const tulung = [...new Set(pluginCommands)];
  const code = fs.readFileSync("./handler.js", "utf8");
  const regex = /case\s+['"`]([^'"`]+)['"`]:/g;
  const matches = [];
  let match;

  while ((match = regex.exec(code))) {
    matches.push(match[1]);
  }

  const tulong = Object.values(matches)
    .flatMap(v => v ?? [])
    .map(entry => entry.trim().split(' ')[0].toLowerCase())
    .filter(Boolean);

  if ((tulung.includes(command.toLowerCase()) || tulong.includes(command)) &&
    !isRegistered && !['daftar', 'regis', 'register'].includes(command)) {
    return reply(mess.notregist);
  }
}

for (let plugin of plugins) {
  const runPlugin = plugin.default || plugin;

  if (runPlugin.usePrefix === true && !isCmd) continue;
  if (runPlugin.usePrefix === false && isCmd) continue;
  if (runPlugin.usePrefix === undefined && !isCmd) continue;

  if (runPlugin.usePrefix === false) {
    let isMatch = runPlugin.command?.some(cmd => budy.startsWith(cmd));

    if (!isMatch) continue;
    }

  if (runPlugin.usePrefix === true) {
    if (!runPlugin.command?.includes(command.toLowerCase())) continue;
  }

  pluginsDisable = false;

  if (runPlugin.group && !m.isGroup) return reply(global.mess.group);
  if (runPlugin.privates && m.isGroup) return reply(global.mess.private);
  if (runPlugin.premium && !isPremium) return reply(global.mess.premium);
  if (runPlugin.admin && !isAdmins) return reply(global.mess.admin);
  if (runPlugin.creator && !isCreator) return reply(global.mess.creator);
  if (runPlugin.botAdmin && !isBotAdmins) return reply(global.mess.botAdmin);

  if (runPlugin.limit && runPlugin.usePrefix === true) {
    if (isRegistered && !m.fromMe) {
      if (!isCreator && !isPremium) {
        if (isLimit) return reply(global.mess.endLimit);
        reduceUserLimit(m.sender);
        reply(`Limit kamu berkurang 1`);
      }
    }
  }

  if (typeof runPlugin === "function") {
    await RyuuBotz.sendPresenceUpdate('composing', m.chat);
    await global.sleep(700);
    await runPlugin(m, ryuu_dev);
  } else {
    console.log(`[PLUGIN WARNING] Plugin "${runPlugin.command?.[0]}" bukan fungsi valid.`);
  }
}
// End of plugins function 


//Similarity
const antitypo = global.antiTypo;
    if (isCmd) {
  if (command) {
  await RyuuBotz.sendPresenceUpdate('composing', m.chat)
  if (antitypo) {
  let handlerCommands = []
  try {
    const code = fs.readFileSync("./handler.js", "utf8")
    const regex = /case\s+['"`]([^'"`]+)['"`]:/g
    let match
    while ((match = regex.exec(code))) {
      handlerCommands.push(match[1].toLowerCase())
    }
  } catch (err) {
    console.error("Gagal baca handler.js:", err)
  }

  let pluginCommands = []
  try {
    for (let plugin of plugins) {
      if (plugin.command) {
        pluginCommands.push(...plugin.command.map(c => c.toLowerCase()))
      }
    }
  } catch (err) {
    console.error("Gagal ambil plugin command:", err)
  }

  const help = [...new Set([...handlerCommands, ...pluginCommands])]

  if (!help.includes(command.toLowerCase()) && !budy.startsWith('$ ') && !budy.startsWith('> ')) {
    const mean = didyoumean(command, help)
    const sim = similarity(command, mean)
    const similarityPercentage = parseInt(sim * 100)

    if (mean && command.toLowerCase() !== mean.toLowerCase()) {
      const respon = `
ᴄᴏᴍᴍᴀɴᴅ ɪᴛᴜ ᴛɪᴅᴀᴋ ᴀᴅᴀ ᴍᴜɴɢᴋɪɴ ʏᴀɴɢ ᴋᴀᴍᴜ ᴍᴀᴋsᴜᴅ

➠ Command \`${prefix + mean}\`
➠ Similarity   \`[ ${similarityPercentage}% ]\`
      `.trim()

      await RyuuBotz.sendButton(m.chat, {
        footer: `${global.namabot}`,
        buttons: [
          {
            buttonId: `.${mean} ${text || ""}`,
            buttonText: { displayText: `${mean}` },
            type: 1
          },
        ],
        headerType: 1,
        viewOnce: true,
        image: { url: global.thumbnail },
        caption: respon,
        contextInfo: {
          mentionedJid: [m.sender],          
            },
          })
        }
      }
    }
  }
}
//type CASE command  
switch (command) {
case 'owner': {
try {
const owner = global.ownernumber
 function formatNomor(nomor) {
  nomor = nomor.replace(/\D/g, '');

  if (!nomor.startsWith('62')) return 'Format salah, harus diawali 62';

  const kodeNegara = '+62';
  const bagian1 = nomor.slice(2, 5);   
  const bagian2 = nomor.slice(5, 9);   
  const bagian3 = nomor.slice(9);     

  return `${kodeNegara} ${bagian1}-${bagian2}-${bagian3}`;
}
const nomorAsli = owner;
const ownerEdit = formatNomor(nomorAsli);

    const vcard = `
BEGIN:VCARD
VERSION:3.0
FN:Ryuu/Reinzz
ORG:The Developer Of ${global.namabot};
TEL;type=CELL;type=VOICE;waid=${owner}:${ownerEdit}
URL: https://api.ryuu-dev.offc.my.id
END:VCARD
    `.trim()

   await RyuuBotz.sendMessage(m.chat, {
      contacts: {
        displayName: "Ryuu Reinzz",
        contacts: [{ vcard }]
      },
      contextInfo: {
        externalAdReply: {
          title: "WhatsApp Business • Store",
          body: `The Developer Of ${global.namabot}`,
          thumbnailUrl: '' + global.thumbnail,
          sourceUrl: 'https://wa.me/6288246552068',
          mediaUrl: 'https://linkbio.co',
          mediaType: 1,
          renderLargerThumbnail: true
        }
      }
    }, { quoted : m })
    global.sleep(500)
    reply(`Semua transaksi di luar command \`.owner\` tidak di tanggung oleh developer asli *Ryuu Reinzz*, jika ada pembelian di luar command \`.owner\`, developer tidak bertanggung jawab atas apa yang terjadi`);
  } catch (e) {
     RyuuBotz.sendMessage(m.chat, {
      text: typeof e === 'string' ? e : '🚫 *Terjadi kesalahan saat memproses permintaan.*',
      quoted: m
    });
  } finally {
    await RyuuBotz.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
  }
  }
  break;
case "runtime": {
        let lowq = `*@${botNumber.split("@")[0]} Telah Online Selama:*\n${runtime(
          process.uptime(),
        )}`;
        reply_(`${lowq}`);
      }
      break
      case 'addcase': {
 if (!isCreator) return reply(mess.creator)
 if (!text) return reply('Mana case nya');
const namaFile = 'handler.js';
const caseBaru = `${text}`;
fs.readFile(namaFile, 'utf8', (err, data) => {
    if (err) {
        console.error('Terjadi kesalahan saat membaca file:', err);
        return;
    }
    const posisiAwalGimage = data.indexOf("case 'addcase':");

    if (posisiAwalGimage !== -1) {
        const kodeBaruLengkap = data.slice(0, posisiAwalGimage) + '\n' + caseBaru + '\n' + data.slice(posisiAwalGimage);
        fs.writeFile(namaFile, kodeBaruLengkap, 'utf8', (err) => {
            if (err) {
                reply('Terjadi kesalahan saat menulis file:', err);
            } else {
                reply(mess.success);
            }
        });
    } else {
        reply('Tidak dapat menambahkan case dalam file.');
    }
});

}
break
case 'getcase': {       
 if (!isCreator) return reply(mess.creator)
 if (!text) return reply('Case apa bang?');

    try {
        const fileContent = fs.readFileSync('./handler.js', 'utf8')

        const casePattern1 = `case "${text}"`
        const casePattern2 = `case '${text}'`

        let startIndex = -1
        let caseDeclaration = ''

        if (fileContent.includes(casePattern1)) {
            startIndex = fileContent.indexOf(casePattern1)
            caseDeclaration = casePattern1
        } else if (fileContent.includes(casePattern2)) {
            startIndex = fileContent.indexOf(casePattern2)
            caseDeclaration = casePattern2
        } else {
            return reply(`❌ Case "${text}" tidak ditemukan.`)
        }

        const caseContentFromStart = fileContent.substring(startIndex)
        const breakIndex = caseContentFromStart.indexOf('break')

        if (breakIndex === -1) return reply('❌ Tidak menemukan akhir dari case (break).')

        const finalCaseContent = caseContentFromStart.substring(0, breakIndex + 5) 
        reply(`✅ Isi case *${text}*:\n\n\`\`\`js\n${finalCaseContent}\n\`\`\``)

    } catch (err) {
        console.error(err)
        reply('❌ Terjadi kesalahan saat mengambil case.')
    }
    }
    break
            case 'delcase': {
                if (!isCreator) return reply(mess.creator)
                if (!text) return reply('Mana case nya bang?');
                dellCase('./handler.js', q)
                reply('Berhasil menghapus case!.');
            }
            break
    default:
if (budy.startsWith('=>')) {
    if (!isCreator) return;
    if (!isAsync) return reply("There is no word to execute");    
    let _text = budy.slice(2).trim();
    let _return;
    try {
        if (_text.includes('return')) {
            _return = await eval(`(async () => { ${_text} })()`);
        } else {
            _return = await eval(`(async () => { return ${_text} })()`);
        }
        const output = typeof _return === 'object'
            ? JSON.stringify(_return, null, 2)
            : String(_return);
        let isOutput =`*Input:*\n${_text}\n\n*___________________________*\n${global.kosong} *Output:*\n${output}`;

        await m.reply(isOutput);
    } catch (err) {
        await m.reply(String(err));
    }
}

if (budy.startsWith('>')) {
    if (!isCreator) return;
    try {
        let evaled = await eval(budy.slice(2));
        if (typeof evaled !== 'string') evaled = util.inspect(evaled);
        let output =`*Input:*\n${budy.slice(2)}\n\n*___________________________*\n${global.kosong} *Output:*\n${evaled}`;
        await m.reply(output);
    } catch (err) {
        await m.reply(String(err));
    }
}

if (budy.startsWith('$')) {
    if (!isCreator) return;
    exec(budy.slice(2), (err, stdout) => {
        if (err) return reply(`${err}`)
        let output =`*Input:*\n${budy.slice(2)}\n\n*___________________________*\n${global.kosong} *Output:*\n${stdout}`;
        if (stdout) return m.reply(output)
    })
   }
  }
} catch (err) {
    console.log(util.format(err))
}
}
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
let file = __filename;
fs.watchFile(file, async () => {
    fs.unwatchFile(file);
    console.log(chalk.redBright(`Update ${file}`));
    try {
        const module = await import(`${file}?update=${Date.now()}`); 
    } catch (err) {
        console.error(err);
    }
});

// === AUTO RELOAD PLUGINS === //
const pluginsFolder = path.resolve("./plugins");
async function reloadPlugins() {
  try {
    const files = fs.readdirSync(pluginsFolder).filter(f => f.endsWith(".js"));
    let loaded = 0;

    for (const file of files) {
      const filePath = path.join(pluginsFolder, file);
      try {
        await import(`${filePath}?update=${Date.now()}`);
        loaded++;
      } catch (err) {
        console.log(chalk.red(`❌ Gagal reload: ${file}`));
      }
    }

    console.log(chalk.greenBright(`Reloaded ${loaded} Plugins ✅`));
  } catch (err) {
    console.log(chalk.redBright("❌ Gagal membaca folder plugins!"));
    console.error(err);
  }
}

// Pantau folder plugin
fs.watch(pluginsFolder, (eventType, filename) => {
  if (filename && filename.endsWith(".js")) {
    console.log(chalk.yellowBright(`\nUpdate ./plugins/${filename}`));
    reloadPlugins();
  }
});