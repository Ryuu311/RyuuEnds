import fs from "fs";
import "../settings.js";

let handler = async (m, { RyuuBotz, args, text, q, reply, prefix }) => {
  if (!args[0]) return reply(`Penggunaan ${prefix}addprem nomor\nContoh: ${prefix}addprem ${global.owner}`);

  let prrkek = q.split("|")[0].replace(/[^0-9]/g, '') + "@s.whatsapp.net";
  let ceknya = await RyuuBotz.onWhatsApp(prrkek);
  if (ceknya.length == 0) return reply("Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp!!!");

  let premium = JSON.parse(fs.readFileSync("./database/premium.json"));
  if (!premium.includes(prrkek)) premium.push(prrkek);
  fs.writeFileSync("./database/premium.json", JSON.stringify(premium));

  reply(`Successfully Added ${prrkek} To Database`);
};

handler.command = ["addpremium", "addprem"];
handler.group = false
handler.premium = false
handler.limit = false
handler.admin = false
handler.creator = true
handler.botAdmin = false
handler.privates = false
handler.usePrefix = true

export default handler;