import "../settings.js";

let handler = async (m, { text, reply, prefix, command }) => {
  if (!text) {
    return reply(
      `Contoh penggunaan:\n${prefix + command} self\n${prefix + command} public\n\nStatus Self bot: *${global.self_}*`
    );
  }

  if (text.toLowerCase() === "self") {
    global.self_ = true;
    reply(`✅ Bot mode self aktif\nStatus self bot sekarang ${global.self_}`);
  } else if (text.toLowerCase() === "public") {
    global.self_ = false;
    reply(`✅ Bot mode public\nStatus self bot sekarang ${global.self_}`);
  } else {
    reply(
      `❌ Pilihan tidak valid.\nGunakan:\n${prefix + command} self\n${prefix + command} public`
    );
  }
};

handler.command = ["mode", "bot-mode"];
handler.group = false
handler.premium = false
handler.limit = false
handler.admin = false
handler.creator = true
handler.botAdmin = false
handler.privates = false
handler.usePrefix = true

export default handler;