import fs from "fs";
import "../settings.js";

let handler = async (m, { RyuuBotz, args, text, reply, prefix }) => {
  let blacklist = JSON.parse(fs.readFileSync("./database/blacklist.json"));

  if (!args[0]) {
    return reply(`Penggunaan:
${prefix}blacklist add (reply/nomor)
${prefix}blacklist delete nomor`);
  }

  let subcmd = args[0].toLowerCase();
  let rawTarget;

  if (m.quoted && m.quoted.fakeObj && m.quoted.fakeObj.participant && subcmd === "add") {
    rawTarget = m.quoted.fakeObj.participant;
  } else if (args[1]) {
    rawTarget = args[1];
  } else {
    return reply(`Kamu harus reply chat atau memberi nomor yang valid, sayang~`);
  }
  let target = rawTarget;

  if (/@s\.whatsapp\.net$/i.test(rawTarget)) {
    try {
      target = await RyuuBotz.getLidFromPN(m.chat, rawTarget);
      if (!target) return reply(`Nomornya tidak bisa dikonversi menjadi LID, sayang.`);
    } catch (e) {
      return reply(`Gagal convert nomor ke LID, sayang…\n${e.message}`);
    }
  }

  if (subcmd === "add") {
    if (!blacklist.includes(target)) {
      blacklist.push(target);
      fs.writeFileSync("./database/blacklist.json", JSON.stringify(blacklist));
      return reply(`Added to blacklist: ${target}`);
    } else {
      return reply(`Nomor ini sudah ada di blacklist, sayang.`);
    }
  }

  if (subcmd === "delete") {
    let index = blacklist.indexOf(target);
    if (index !== -1) {
      blacklist.splice(index, 1);
      fs.writeFileSync("./database/blacklist.json", JSON.stringify(blacklist));
      return reply(`Deleted from blacklist: ${target}`);
    } else {
      return reply(`Nomornya tidak ditemukan di blacklist, sayang.`);
    }
  }

  reply(`Subcommand tidak dikenal.`);
};

handler.command = ["blacklist"];
handler.group = true
handler.premium = false
handler.limit = false
handler.admin = false
handler.creator = true
handler.botAdmin = true
handler.privates = false
handler.usePrefix = true

export default handler;