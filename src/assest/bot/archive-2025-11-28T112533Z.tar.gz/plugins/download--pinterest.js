import axios from 'axios'
import { proto, generateWAMessageFromContent, prepareWAMessageMedia } from '@ryuu-reinzz/baileys'

let handler = async (m, { text, RyuuBotz, sender, reply }) => {
  await RyuuBotz.sendMessage(m.chat, { react: { text: "⏱️", key: m.key } })
  try {
    if (!text) return reply(`Format salah, contoh: \n.pin Anime`)

    let searchrest = await axios.get(`https://api.ryuu-dev.offc.my.id/search/pinterest?query=${encodeURIComponent(text)}`)
    let anurest = searchrest.data.result

    if (!anurest || anurest.length === 0) 
      return reply("Error, Foto Tidak Ditemukan")

    let selectedImages = anurest.slice(0, 10)
    let cards = []

    for (let i = 0; i < selectedImages.length; i++) {
      let img = await prepareWAMessageMedia(
        { image: { url: selectedImages[i].image } },
        { upload: RyuuBotz.waUploadToServer }
      )

      cards.push({
        header: proto.Message.InteractiveMessage.Header.fromObject({
          title: `Gambar ke *${i + 1}*\n${selectedImages[i].caption || 'Tanpa caption'}`,
          hasMediaAttachment: true,
          ...img
        }),
        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
          buttons: [{
            name: "cta_url",
            buttonParamsJson: JSON.stringify({
              display_text: "Lihat di Pinterest",
              url: selectedImages[i].source || selectedImages[i].image
            })
          }]
        }),
        footer: proto.Message.InteractiveMessage.Footer.create({
          text: "© Ryuu Reinzz 2022 - 2025"
        })
      })
    }

    const msg = await generateWAMessageFromContent(m.chat, {
      viewOnceMessage: {
        message: {
          messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
          interactiveMessage: proto.Message.InteractiveMessage.fromObject({
            body: proto.Message.InteractiveMessage.Body.fromObject({
              text: `🔎 Berikut hasil pencarian gambar untuk *${text}*`
            }),
            carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
              cards
            })
          })
        }
      }
    }, {
      userJid: sender,
      quoted: m
    })

    await RyuuBotz.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
  } catch (err) {
    console.error(err)
    reply("Maaf, terjadi error saat mengambil gambar dari Pinterest 😢\nCoba lagi nanti ya~ 💗")
  }
}

handler.command = ['pinterest', 'pin']
handler.group = false
handler.premium = false
handler.limit = true
handler.admin = false
handler.creator = false
handler.botAdmin = false
handler.privates = false
handler.usePrefix = true

export default handler