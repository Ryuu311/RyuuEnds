import "../settings.js";

let handler = async (m, { RyuuBotz, args, reply }) => {

  const keyword = args[0]?.toLowerCase();
  if (!keyword || !['add', 'out'].includes(keyword))
    return reply(`Gunakan format:\n.simulating add\n.simulating out`);

  const fakeUser = m.sender; // Pengirim sebagai target simulasi

  if (keyword === 'add') {
    RyuuBotz.ev.emit('group-participants.update', {
  id: m.chat,
  author: m.participant,
  authorPn: null,
  participants: [
    {
      id: m.participant,
      phoneNumber: m.sender,
      admin: null
    }
  ],
  action: 'add'
});
    reply(`Simulasi pengguna masuk berhasil.`);
  } else if (keyword === 'out') {
    RyuuBotz.ev.emit('group-participants.update', {
  id: m.chat,
  author: m.participant,
  authorPn: null,
  participants: [
    {
      id: m.participant,
      phoneNumber: m.sender,
      admin: null
    }
  ],
  action: 'remove'
});
    reply(`Simulasi pengguna keluar berhasil.`);
  }
};

handler.command = ["simulating"];
handler.group = true
handler.premium = false
handler.limit = false
handler.admin = false
handler.creator = true
handler.botAdmin = true
handler.privates = false
handler.usePrefix = true

export default handler;