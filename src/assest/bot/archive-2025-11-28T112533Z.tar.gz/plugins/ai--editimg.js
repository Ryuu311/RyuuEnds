import fs from 'fs';
import { GoogleGenAI, Modality } from "@google/genai";

const handler = async (m, { RyuuBotz, text, reply, command, prefix }) => {
  let q = m.quoted ? m.quoted : m;
  let mime = (q.msg || q).mimetype || '';

  if (!/image/.test(mime)) {
    return reply(
      `📌 Reply gambar dengan caption: *${prefix + command} [prompt]*\nContoh: *${prefix + command} beri topi santa*`
    );
  }

  if (!text || text.trim().length < 3) {
    return reply(
      `*Prompt tidak boleh kosong!*\nContoh: *${prefix + command} beri topi santa*`
    );
  }

  await RyuuBotz.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

  try {
    // Download gambar yang di-reply
    const timestamp = Date.now();
    const mediaPath = await RyuuBotz.downloadAndSaveMediaMessage(m.quoted, `./database/tmp/gemini_img_${timestamp}`);
    
    const ai = new GoogleGenAI({
  apiKey: "AIzaSyAhlkNjHySt9rEtjUlUfa8JE06DETYPW2s",
});
    const imageBuffer = fs.readFileSync(mediaPath);
    const base64Image = imageBuffer.toString("base64");
    const prompt = [
    { text: text },
    {
      inlineData: {
        mimeType: "image/png",
        data: base64Image,
      },
    },
  ];

    // Generate gambar dengan prompt + input gambar
    const response = await ai.models.generateContent({
    model: "gemini-2.5-flash-image-preview",
    contents: prompt,
  });

    // Ambil hasil gambar
    const content = response?.candidates?.[0]?.content;
    if (!content) throw new Error('No content generated');

    const result = content.find((p) => p.inlineData);
    if (!result) throw new Error('No image found in response');

    const imgBuffer = Buffer.from(result.inlineData.data, 'base64');

    // Kirim hasil ke chat
    await RyuuBotz.sendMessage(
      m.chat,
      {
        image: imgBuffer,
        caption: `✅ *Hasil AI Edit*\nPrompt: ${text}`,
      },
      { quoted: m }
    );

    await RyuuBotz.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    // Hapus file sementara
    fs.unlinkSync(mediaPath);
  } catch (err) {
    console.error(err);
    await RyuuBotz.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    reply(`❌ Gagal memproses gambar.\n*Error:* ${err.message}`);
  }
};

handler.command = ['aiedit', 'image-edit', 'imgedit', 'editimg'];
handler.group = false
handler.premium = false
handler.limit = true
handler.admin = false
handler.creator = false
handler.botAdmin = false
handler.privates = false
handler.usePrefix = true

export default handler;