let handler = async (m, { reply, stickerDB, saveStickerDB }) => {
  if (!m.quoted) return reply('Reply ke stiker yang mau dikunci!');
  if (!m.quoted.fileSha256) return reply('SHA256 Hash Missing');

  const hash = m.quoted.fileSha256.toString('base64');
  if (!(hash in stickerDB))
    return reply('Stiker ini belum punya command.');

  stickerDB[hash].locked = true;
  saveStickerDB();
  reply('Command berhasil dikunci 🔒');
};

handler.command = ['lockcmd'];
handler.creator = true;
handler.admin = false;
handler.group = false;
handler.premium = false;
handler.limit = false;
handler.botAdmin = false;
handler.privates = false;
handler.usePrefix = true

export default handler;