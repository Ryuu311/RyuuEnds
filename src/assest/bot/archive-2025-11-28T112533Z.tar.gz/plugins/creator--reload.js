import "../settings.js";
import fs from "fs";
import path, { resolve } from "path";
import chalk from "chalk";

let handler = async (m, { RyuuBotz, reply }) => {
  await RyuuBotz.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key } });

  const pluginsFolder = path.resolve("./plugins");
  const handlerPath = resolve(process.cwd(), "handler.js");
  let loaded = 0;

  try {
    // Reload semua plugin
    const files = fs.readdirSync(pluginsFolder).filter(f => f.endsWith(".js"));
    for (const file of files) {
      const filePath = path.join(pluginsFolder, file);
      try {
        await import(`${filePath}?update=${Date.now()}`);
        loaded++;
      } catch {
        console.log(chalk.red(`❌ Gagal reload: ${file}`));
      }
    }

    // Reload handler.js
    await import(`${handlerPath}?update=${Date.now()}`);

    // Console log hasil
    console.log(chalk.greenBright(`
Reload Success ✅
🔹Reloaded plugin: ${loaded}
🔹Reloaded handler.js
`));

    // Balasan ke user
    reply(`✅ *Reload Success!*
🔹Reloaded plugin: ${loaded}
🔹Reloaded handler.js`);
  } catch (err) {
    console.error(chalk.redBright("❌ Gagal reload system!"), err);
    reply("❌ Gagal reload plugins!");
  }
};

handler.command = ["reload", "refresh"];
handler.group = false;
handler.premium = false;
handler.limit = false;
handler.admin = false;
handler.creator = true;
handler.botAdmin = false;
handler.privates = false;
handler.usePrefix = true

export default handler;