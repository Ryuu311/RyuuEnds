let handler = async (m, { text, reply, prefix }) => {  
  if (!text) {
    return reply(
      `📌 Contoh penggunaan:\n${prefix}prefix on\n${prefix}prefix off`
    );
  }

  if (text.toLowerCase() === "on") {
    global.pref = true;
    reply(`✅ Prefix diaktifkan.\nPrefix sekarang: "${global.prefix}"`);
  } else if (text.toLowerCase() === "off") {
    global.pref = false;
    reply(`✅ Prefix dimatikan.\nSekarang command tanpa prefix.`);
  } else {
    reply(
      `❌ Pilihan tidak valid.\nGunakan:\n${prefix}prefix on\n${prefix}prefix off`
    );
  }
};

handler.command = ["prefix"];
handler.group = false
handler.premium = false
handler.limit = false
handler.admin = false
handler.creator = true
handler.botAdmin = false
handler.privates = false
handler.usePrefix = true

export default handler;