import "../settings.js";
import helper from '@ryuu-reinzz/button-helper';
const { sendInteractiveMessageV2 } = helper;

let handler = async (m, { RyuuBotz, reply }) => {
  try {

    let groupMetadata = await RyuuBotz.groupMetadata(m.chat);
    let response = await RyuuBotz.groupInviteCode(m.chat);

    const link = `https://chat.whatsapp.com/${response}`;
    const caption = `🌸 *Nama Grup:* ${groupMetadata.subject}\n👑 *Owner:* wa.me/${groupMetadata.owner ? groupMetadata.owner.split('@')[0] : 'Tidak diketahui'}\n🔗 *Link Invite:* ${link}`;

    const buttons = {
      text: "✨ Ini link undangan grup kamu!",
      footer: `© ${global.ownername} - 2025`,
      media: {
        type: 'document',
        source: {
          url: 'https://raw.githubusercontent.com/Ryuu311/Arisu-Botz/refs/heads/main/README.md',
        },
        mimetype: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        fileName: 'Group Link Info',
        caption: '📎 Group Invite Link',
        thumbnailUrl: 'https://telegra.ph/file/78c2d45dba4e77df6f84b.jpg' // thumbnail custom boleh
      },
      interactiveButtons: [
        {
          name: 'cta_copy',
          buttonParamsJson: JSON.stringify({
            display_text: 'Salin Link Grup',
            copy_code: link
          })
        },
        {
          name: 'cta_url',
          buttonParamsJson: JSON.stringify({
            display_text: 'Buka Link Grup',
            url: link
          })
        }
      ]
    };

    await sendInteractiveMessageV2(RyuuBotz, m.chat, buttons);

  } catch (err) {
    console.error(err);
    reply(`❌ Terjadi kesalahan: ${err.message}`);
  }
};

handler.command = ["linkgc", "gruplink", "grouplink", "invitelink"];
handler.group = true;
handler.premium = false;
handler.limit = false;
handler.admin = false;
handler.creator = false;
handler.botAdmin = false;
handler.privates = false;
handler.usePrefix = true

export default handler;