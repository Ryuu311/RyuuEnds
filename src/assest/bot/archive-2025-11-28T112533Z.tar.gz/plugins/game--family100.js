import fs from "fs";

const filePath = "./database/game/family100.json";
const soalDB = fs.existsSync(filePath)
  ? JSON.parse(fs.readFileSync(filePath))
  : [];

const pickRandom = (arr) => arr[Math.floor(Math.random() * arr.length)];

// SIMPAN TIMEOUT DI MEMORI, BUKAN DI FILE
const timeoutStore = {};

let handler = async (m, { reply, args }) => {
  const from = m.chat;
  const cmd = args[0]?.toLowerCase();

  if (!cmd) return reply("❌ Gunakan: .family100 <start/jawaban/nyerah>");

  const tmpFile = `./database/tmp/family100-${from}.json`;

  const readSession = () => {
    if (fs.existsSync(tmpFile)) {
      return JSON.parse(fs.readFileSync(tmpFile));
    }
    return null;
  };

  const saveSession = (data) => {
    fs.writeFileSync(tmpFile, JSON.stringify(data));
  };

  // =====================
  // START GAME
  // =====================
  if (cmd === "start") {
    if (readSession())
      return reply("⚠️ Game sedang berjalan, jawab dulu atau ketik `.family100 nyerah`!");

    const data = pickRandom(soalDB);
    const soal = data.soal;
    const jawaban = data.jawaban.map((x) => x.toLowerCase());

    reply(
      `💯 *FAMILY 100*\n` +
      `📝 Soal: *${soal}*\n` +
      `🔢 Jumlah jawaban: *${jawaban.length}*\n` +
      `⏱️ 10 menit dimulai sekarang`
    );

    // Simpan session tanpa timeout
    saveSession({ answers: jawaban });

    // Timer disimpan di memori
    timeoutStore[from] = setTimeout(() => {
      const session = readSession();
      if (session) {
        reply(
          `⏱️ *Waktu habis!*\nJawaban yang belum terjawab:\n- ${session.answers.join("\n- ")}`
        );
        fs.unlinkSync(tmpFile);
      }
    }, 600000);

    return;
  }

  // =====================
  // CEK JAWABAN
  // =====================
  if (cmd === "jawaban") {
    const session = readSession();
    if (!session)
      return reply("❌ Tidak ada game aktif. Ketik `.family100 start` untuk memulai!");

    const userAnswer = args.slice(1).join(" ").toLowerCase();
    if (!userAnswer)
      return reply("❌ Ketik jawabanmu setelah `.family100 jawaban`!");

    for (let i of session.answers) {
      if (userAnswer.includes(i)) {
        session.answers = session.answers.filter((a) => a !== i);
        saveSession(session);

        await reply(`🎉 *Benar!* Jawaban: *${i}*`);

        if (session.answers.length < 1) {
          clearTimeout(timeoutStore[from]);
          delete timeoutStore[from];
          fs.unlinkSync(tmpFile);
          reply(`🏆 Semua jawaban benar!`);
        }
        return;
      }
    }

    return reply("❌ Salah atau jawaban sudah terjawab!");
  }

  // =====================
  // MENYERAH
  // =====================
  if (cmd === "nyerah") {
    const session = readSession();
    if (!session) return reply("❌ Tidak ada game aktif.");

    clearTimeout(timeoutStore[from]);
    delete timeoutStore[from];
    fs.unlinkSync(tmpFile);

    return reply(
      `🫧 Kamu menyerah…\nJawaban yang belum terjawab:\n- ${session.answers.join("\n- ")}`
    );
  }

  return reply("❌ Gunakan: .family100 <start/jawaban/nyerah>");
};

handler.command = ["family100", "f100"];
handler.group = true;
handler.premium = false;
handler.limit = true;
handler.admin = false;
handler.creator = false;
handler.botAdmin = false;
handler.privates = false;
handler.usePrefix = true;

export default handler;