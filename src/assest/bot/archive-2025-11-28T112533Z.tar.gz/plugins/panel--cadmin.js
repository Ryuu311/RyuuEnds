import "../settings.js";
import axios from "axios";
import helper from "@ryuu-reinzz/button-helper";
const { sendInteractiveMessageV2 } = helper;

let handler = async (m, { prefix, command, RyuuBotz, text, reply }) => {
  if (!text)
    return reply(
      `📦 *Usage:*\n.cadmin <nama|nomorOpsional>\n\n📌 *Example:*\n.cadmin ryuu|62xxxxxxxx`
    );

  const [name, maybeNumber] = text.split("|").map(s => s && s.trim());
  if (!name) return reply(`⚠️ Format salah!\n\nGunakan: ${prefix + command} nama|nomorOpsional`);
  const username = name.toLowerCase().replace(/\s+/g, "");
  const password = `${username}LeaPanel`;

  let target = maybeNumber ? `${maybeNumber.replace(/^0+/, "").replace(/\D+/g, "")}@s.whatsapp.net` : m.sender;

  const Domain = global.domain;
  const apikey = global.aapikey;
  if (!Domain || !apikey) return reply("❌ Domain atau API key Pterodactyl belum dikonfigurasikan pada global.");

  const host = "api.ryuu-dev.offc.my.id";
  const email = `${username}@${host}`;

  await RyuuBotz.sendMessage(m.chat, {
    react: { text: "⏱️", key: m.key },
  });

  try {
    const url = `${Domain.replace(/\/$/, "")}/api/application/users`;
    const body = {
      email,
      username,
      first_name: name,
      last_name: "Staff",
      language: "en",
      password,
      root_admin: true
    };

    const res = await axios.post(url, body, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apikey}`
      },
      timeout: 20000
    });

    const data = res.data;

    const createdUsername = (data.attributes && data.attributes.username) || username;
    const createdEmail = (data.attributes && data.attributes.email) || email;

    const caption = `✅ *Create Admin Successfully*\n\n👤 *Username:* ${createdUsername}\n🔑 *Password:* ${password}\n✉️ *Email:* ${createdEmail}\n\n🌐 *Panel:* ${Domain}`;

    const buttons = {
      text: caption,
      footer: `© ${global.ownername} - 2025`,
      media: {
        type: "document",
        source: {
          url: "https://raw.githubusercontent.com/Ryuu311/Arisu-Botz/refs/heads/main/README.md",
        },
        mimetype:
          "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        fileName: "Admin-Account",
        caption: "Your admin account is ready"
      },
      interactiveButtons: [
        {
          name: "cta_copy",
          buttonParamsJson: JSON.stringify({
            display_text: "Salin Username",
            copy_code: `${createdUsername}`,
          }),
        },
        {
          name: "cta_copy",
          buttonParamsJson: JSON.stringify({
            display_text: "Salin Password",
            copy_code: `${password}`,
          }),
        },
        {
          name: "cta_url",
          buttonParamsJson: JSON.stringify({
            display_text: "Buka Panel",
            url: `${Domain}`,
          }),
        },
      ],
    };

    await sendInteractiveMessageV2(RyuuBotz, target, buttons);
  } catch (err) {
    console.error("cadmin error:", err?.response?.data || err.message || err);
    const msg = err.response?.data?.errors
      ? JSON.stringify(err.response.data.errors)
      : (err.response?.data?.message || err.message || "Unknown error");
    reply(`❌ *Error membuat admin!*\n${msg}`);
  }
};

handler.command = ["cadmin", "createadmin"];
handler.group = false;
handler.premium = true;
handler.limit = false;
handler.admin = false;
handler.creator = false;
handler.botAdmin = false;
handler.privates = false;
handler.usePrefix = true

export default handler;