import fs from "fs";
import "../settings.js";

let handler = async (m, { RyuuBotz, args, q, reply, prefix }) => {
  if (!args[0]) return reply(`Penggunaan ${prefix}delprem nomor\nContoh: ${prefix}delprem ${global.owner}`);

  let ya = q.split("|")[0].replace(/[^0-9]/g, '') + "@s.whatsapp.net";
  let premium = JSON.parse(fs.readFileSync("./database/premium.json"));
  let unp = premium.indexOf(ya);
  if (unp === -1) return reply(`${ya} Tidak Ada Di Database`);

  premium.splice(unp, 1);
  fs.writeFileSync("./database/premium.json", JSON.stringify(premium));
  reply(`Successfully Removed ${ya} From Database`);
};

handler.command = ["delpremium", "delprem"];
handler.group = false
handler.premium = false
handler.limit = false
handler.admin = false
handler.creator = true
handler.botAdmin = false
handler.privates = false
handler.usePrefix = true

export default handler;