import fetch from 'node-fetch';
import helper from '@ryuu-reinzz/button-helper';
const { sendInteractiveMessageV2 } = helper;
import fs from 'fs';

let handler = async (m, { text, prefix, RyuuBotz, reply }) => {
  if (!text) return reply("⚠️ Masukkan judul lagu/video YouTube!");
  await RyuuBotz.sendMessage(m.chat, { react: { text: '⏱️', key: m.key } });

  try {
    const apiUrl = `https://ryuu-endss-api.vercel.app/search/youtube?q=${encodeURIComponent(text)}`;

    let res;
    try {
      res = await fetch(apiUrl);
    } catch (fetchErr) {
      console.error("❌ Error saat fetch API:", fetchErr);
      return reply("❌ Gagal terhubung ke API.");
    }

    let response;
    try {
      response = await res.json();
    } catch (jsonErr) {
      console.error("❌ Error saat parsing JSON:", jsonErr);
      return reply("❌ Gagal membaca respon dari API.");
    }

    if (!response.status || !Array.isArray(response.result) || response.result.length === 0) {
      console.error("❌ API mengembalikan data kosong:", response);
      return reply("❌ Video tidak ditemukan atau API error.");
    }

    let firstVideo = response.result[0];
    let { title, channel, duration, imageUrl } = firstVideo;
    let firstLink = firstVideo.link;

    let menu = `🎵 *${title}*\n\n📺 Channel: ${channel}\n⏳ Durasi: ${duration}\n\n🔗 Link: ${firstLink}`;

    try {
      await RyuuBotz.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (thumbErr) {
      console.error("❌ Error kirim thumbnail:", thumbErr);
      reply("⚠️ Thumbnail gagal dikirim, lanjut ke tombol menu...");
    }
        
 const buttons = {
  text: menu,
  footer: `© ${global.ownername} - 2025`,
  thumbnailUrl: imageUrl,
  document: Buffer.from("RyuuReinzz"),
  fileName: "RyuuMusic.pdf",
  mimetype: "application/pdf",

  interactiveButtons: [
    {
      name: 'quick_reply',
      buttonParamsJson: JSON.stringify({
        display_text: '🎥 Video',
        id: `${prefix}yttmp4 ${firstLink}`
      })
    },
    {
      name: 'quick_reply',
      buttonParamsJson: JSON.stringify({
        display_text: '🎤 Audio',
        id: `${prefix}yttmp3 ${firstLink}`
      })
    }/*,
  {
    name: 'single_select',
    buttonParamsJson: JSON.stringify({
      title: "MENU DOWNLOAD LAINNYA",
      sections: [
        {
          title: "Menu Download V2",
          highlight_label: "V2",
          rows: [
            { title: "🎤 Mp3 Download", description: "Audio Download", id: `${prefix}yttmp3 ${firstLink}` },
            { title: "🎥 Mp4 Download", description: "Video Download", id: `${prefix}yttmp4 ${firstLink}` }
          ]
        },
        {
          title: "Menu Download V3",
          highlight_label: "V3",
          rows: [
            { title: "🎤 Mp3 Download", description: "Audio Download", id: `${prefix}yytmp3 ${firstLink}` },
            { title: "🎥 Mp4 Download", description: "Video Download", id: `${prefix}yytmp4 ${firstLink}` }
          ]
        }
      ]
    })
  }*/
  ]
}; 


    try {     
        await sendInteractiveMessageV2(RyuuBotz, m.chat, buttons);
    } catch (buttonErr) {
      console.error("❌ Error kirim button message:", buttonErr);
      return reply("❌ Gagal mengirim tombol menu.");
    }

  } catch (err) {
    console.error("❌ Error umum:", err);
    await RyuuBotz.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    reply("❌ Terjadi kesalahan, coba lagi nanti.");
  }
};

handler.command = ["ytplay", "play"];
handler.group = false
handler.premium = false
handler.limit = true
handler.admin = false
handler.creator = false
handler.botAdmin = false
handler.privates = false
handler.usePrefix = true

export default handler;