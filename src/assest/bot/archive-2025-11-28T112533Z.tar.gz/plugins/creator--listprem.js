import fs from "fs";
import "../settings.js";

let handler = async (m, { RyuuBotz, qtext, reply, mess }) => {

  let premList = JSON.parse(fs.readFileSync("./database/premium.json"));
  if (premList.length === 0) return reply("⚠️ Tidak ada Premium yang terdaftar!");

  let text = "💭 *Daftar Premium:*\n\n";
  premList.forEach((prrem, index) => {
    text += `- ${index + 1}. @${prrem.replace("@s.whatsapp.net","")}\n`;
  });

  RyuuBotz.sendMessage(m.chat, { text, mentions: premList }, { quoted: qtext });
};

handler.command = ["listpremium", "listprem"];
handler.group = false
handler.premium = false
handler.limit = false
handler.admin = false
handler.creator = true
handler.botAdmin = false
handler.privates = false
handler.usePrefix = true

export default handler;