import "../settings.js";
import fs from "fs";
import path from "path";

let handler = async (m, { RyuuBotz, reply }) => {
  // kasih reaksi loading
  await RyuuBotz.sendMessage(m.chat, {
    react: { text: "⏳", key: m.key },
  });

  try {
    // ====== BACA CASE DARI handler.js ======
    let handlerCommands = [];
    try {
      const code = fs.readFileSync("./handler.js", "utf8");
      const regex = /case\s+['"`]([^'"`]+)['"`]:/g;
      let match;
      while ((match = regex.exec(code))) {
        handlerCommands.push(match[1].toLowerCase());
      }
    } catch (err) {
      console.error("Gagal baca handler.js:", err);
    }

    // ====== BACA COMMAND DARI PLUGIN ======
    let pluginCommands = [];
    try {
      const pluginDir = path.join(process.cwd(), "plugins");
      const files = fs.readdirSync(pluginDir).filter(f => f.endsWith(".js"));

      for (const file of files) {
        const content = fs.readFileSync(path.join(pluginDir, file), "utf8");
        const matchArray = [
          ...content.matchAll(/handler\.command\s*=\s*(\[[^\]]+\]|["'`][^"'`]+["'`])/g),
        ];

        for (const match of matchArray) {
          let cmd = match[1];
          if (cmd.startsWith("[")) {
            try {
              const arr = eval(cmd);
              pluginCommands.push(...arr.map(v => v.toLowerCase()));
            } catch {
              pluginCommands.push(cmd.replace(/["'`\[\]]/g, "").toLowerCase());
            }
          } else {
            pluginCommands.push(cmd.replace(/["'`]/g, "").toLowerCase());
          }
        }
      }
    } catch (err) {
      console.error("Gagal ambil plugin command:", err);
    }

    // ====== GABUNG & HITUNG TOTAL ======
    const help = [...new Set([...handlerCommands, ...pluginCommands])];

    const result = `📦 *Total Fitur:*\n` +
                   `🔹 Command Case: ${handlerCommands.length}\n` +
                   `🔹 Command Plugin: ${pluginCommands.length}\n` +
                   `🔹 Total Command: ${help.length + 1}`;

    await reply(result);

    // kasih reaksi selesai
    await RyuuBotz.sendMessage(m.chat, {
      react: { text: "✅", key: m.key },
    });

  } catch (err) {
    console.error(err);
    reply(`❌ Error membaca fitur: ${err.message}`);
  }
};

handler.command = ["totalcmd", "totalfitur"];
handler.group = false;
handler.premium = false;
handler.limit = false;
handler.admin = false;
handler.creator = false;
handler.botAdmin = false;
handler.privates = false;
handler.usePrefix = true

export default handler;