import "../settings.js";

let handler = async (m, { participants, reply, q, RyuuBotz }) => {
    
  let themeemoji = global.themeemoji;
  let me = m.sender;
  let teks = `╚»˙·٠${themeemoji}●♥ Tag All ♥●${themeemoji}٠·˙«╝

 😶 *Penanda :* @${me.split("@")[0]}
 🌿 *Isi pesan :* ${q ? q : "tidak ada pesan"}\n\n`;

  for (let mem of participants) {
    teks += `${themeemoji} @${mem.id.split("@")[0]}\n`;
  }

  await RyuuBotz.sendMessage(
    m.chat,
    { text: teks, mentions: participants.map(a => a.id) },
    { quoted: m }
  );
};

handler.command = ["tagall"];
handler.group = true
handler.premium = false
handler.limit = false
handler.admin = true
handler.creator = false
handler.botAdmin = true
handler.privates = false
handler.usePrefix = true

export default handler;