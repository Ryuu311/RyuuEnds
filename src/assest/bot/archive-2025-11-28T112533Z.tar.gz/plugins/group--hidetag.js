import "../settings.js";

let handler = async (m, { groupMetadata, reply, RyuuBotz, mess, text, qgrup }) => {

  let mem = m.isGroup ? groupMetadata.participants.map(a => a.id) : [];

  await RyuuBotz.sendMessage(m.chat, {
    text: `${text ? text : ""}`,
    contextInfo: {
      mentionedJid: mem,
      groupMentions: [
        {
          groupSubject: groupMetadata.subject || "Minna!!",
          groupJid: m.chat,
        },
      ],
    },
  }, { quoted : qgrup });
};

handler.command = ["hidetag", "h", "ht"];
handler.group = true
handler.premium = false
handler.limit = false
handler.admin = true
handler.creator = false
handler.botAdmin = true
handler.privates = false
handler.usePrefix = true

export default handler;