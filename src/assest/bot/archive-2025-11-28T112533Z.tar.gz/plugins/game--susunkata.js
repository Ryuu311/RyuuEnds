import fs from "fs";

const filePath = "./database/game/susunkata.json";
const soalDB = fs.existsSync(filePath)
  ? JSON.parse(fs.readFileSync(filePath))
  : [];

const timeoutMap = {};
const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];

let handler = async (m, { reply, args }) => {
  const from = m.chat;
  const cmd = args[0]?.toLowerCase();
  if (!cmd) return reply("❌ Gunakan: .susunkata <start/jawaban/nyerah>");

  const tmpFile = `./database/tmp/susunkata-${from}.json`;
  const readSession = () => fs.existsSync(tmpFile) ? JSON.parse(fs.readFileSync(tmpFile)) : null;
  const saveSession = (data) => fs.writeFileSync(tmpFile, JSON.stringify(data));

  if (cmd === "start") {
    if (readSession()) return reply("⚠️ Game sedang berjalan!");

    const data = pick(soalDB);
    const soal = data.soal;
    const jawaban = data.jawaban.toLowerCase();
    const hint = jawaban.replace(/[bcdfghjklmnpqrstvwxyz]/gi, "-");

    reply(`🎮 *SUSUN KATA*\n🔤 Soal: ${soal}\n🔍 Clue: \`${hint}\`\n⏱️ 30 detik`);
    saveSession({ answer: jawaban });

    timeoutMap[from] = setTimeout(() => {
      if (readSession()) {
        reply(`⏱️ Waktu habis!\nJawabannya: *${jawaban}*`);
        fs.unlinkSync(tmpFile);
      }
      delete timeoutMap[from];
    }, 30000);

    return;
  }

  if (cmd === "jawaban") {
    const session = readSession();
    if (!session) return reply("❌ Game belum dimulai!");

    const userAns = args.slice(1).join(" ").toLowerCase();
    if (!userAns) return reply("❌ Masukkan jawaban!");

    if (userAns.includes(session.answer)) {
      clearTimeout(timeoutMap[from]);
      delete timeoutMap[from];
      fs.unlinkSync(tmpFile);
      return reply(`✨ Benar! Jawaban: *${session.answer}*`);
    }

    return reply("❌ Salah, coba lagi!");
  }

  if (cmd === "nyerah") {
    const session = readSession();
    if (!session) return reply("❌ Tidak ada game.");

    clearTimeout(timeoutMap[from]);
    delete timeoutMap[from];
    fs.unlinkSync(tmpFile);

    return reply(`🫧 Jawaban: *${session.answer}*`);
  }
};

handler.command = ["susunkata"];
handler.group = true;
handler.premium = false;
handler.limit = true;
handler.admin = false;
handler.creator = false;
handler.botAdmin = false;
handler.privates = false;
handler.usePrefix = true;

export default handler;