import "../settings.js";
import { generateWAMessageFromContent } from "@ryuu-reinzz/baileys";
import helper from '@ryuu-reinzz/button-helper';
const { sendInteractiveMessageV2 } = helper;

let handler = async (m, { RyuuBotz, text, reply }) => {
  if (!text) return reply("💬 Link channel-nya mana sayang?");
  if (!text.includes("https://whatsapp.com/channel/")) return reply("❌ Link tautan tidak valid!");

  try {
    const result = text.split("https://whatsapp.com/channel/")[1];
  async function cekInfoCh (input) {
    const metadataCh = await RyuuBotz.newsletterMetadata("invite", input);

    const followers = metadataCh.thread_metadata.subscribers_count
    const verif = metadataCh.thread_metadata.verification
    const name = metadataCh.thread_metadata.name.text
    const id = metadataCh.id
    const state = metadataCh.state.type

    return { followers, verif, name, id, state }
  };

    const output = await cekInfoCh(result)
    const teks = `🌐 *Informasi Channel WhatsApp*\n\n` +
      `*🆔 ID:* ${output.id}\n` +
      `*📛 Nama:* ${output.name}\n` +
      `*👥 Total Pengikut:* ${output.followers}\n` +
      `*⚙️ Status:* ${output.state}\n` +
      `*✅ Verified:* ${output.verif}`;     
        
        const buttons = {
  text: teks,
  footer: `© ${global.ownername} - 2025`,
  media: {
    type: 'document', 
    source: { 
      url: 'https://raw.githubusercontent.com/Ryuu311/Arisu-Botz/refs/heads/main/README.md' 
    },
    mimetype: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    fileName: 'Your ID',
    caption: '𝙍͢𝙮𝙪𝙪 𝙍͢𝙚𝙞𝙣𝙯𝙯',
    thumbnailUrl: global.thumbnail
  },
  interactiveButtons: [
  {
    name: 'cta_copy',
    buttonParamsJson: JSON.stringify({
      display_text: 'Copy ID',
      copy_code: output.id || "unknown"
    })
  }
 ]
}          

        await sendInteractiveMessageV2(RyuuBotz, m.chat, buttons);
        
  } catch (err) {
    console.error(err);
    reply(`❌ Gagal mengambil data channel!\n📄 ${err.message}`);
  }
};

handler.command = ["idch", "cekidch"];
handler.group = false;
handler.premium = false;
handler.limit = true;
handler.admin = false;
handler.creator = false;
handler.botAdmin = false;
handler.privates = false;
handler.usePrefix = true

export default handler;