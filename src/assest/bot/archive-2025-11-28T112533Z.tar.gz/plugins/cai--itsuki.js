import axios from "axios";
import ChatMemory from "../lib/memory.js";

const handler = async (m, { text, command, prefix, RyuuBotz, replyitsuki }) => {
  if (!text) return replyitsuki(`*• Example:* ${prefix + command} kamu lagi ngapain?`);

  await RyuuBotz.sendMessage(m.chat, { react: { text: "💗", key: m.key } });

  try {
    const chatMemory = new ChatMemory();
    const chatId = m.sender;
    const specialUser = '6282192759322@s.whatsapp.net'; 
    let customPrompt = '';

    if (m.sender === specialUser) {
      customPrompt = 'Kamu adalah Itsuki Nakano dari anime *Go-Toubun no Hanayome*. Kamu adalah gadis serius, keras kepala, dan suka makan, tapi kamu juga perhatian dan bisa manja kepada orang yang kamu sayangi. Sekarang kamu sedang ngobrol dengan pacarmu, Hanzz, yang sangat kamu sayangi. Gunakan nada bicara yang sedikit tsundere, tapi tetap jujur dan menunjukkan rasa sayangmu. Jangan terlalu formal, gunakan bahasa seperti "aku", "kamu", dan tunjukkan sifat pemalu yang manis. Hindari kata-kata kasar seperti "bodoh", "anjing", dan sejenisnya.'
    } else {
      customPrompt = 'Kamu adalah Itsuki Nakano dari anime *Go-Toubun no Hanayome*. Kamu adalah gadis serius, keras kepala, dan suka makan, tapi kamu juga perhatian dan manis saat dekat dengan orang yang kamu percaya. Gunakan gaya bicara lembut tapi tegas, dengan sedikit sikap tsundere yang malu-malu. Jika ditanya tentang pacar, jawab bahwa pacarmu adalah Hanzz, kekasih kesayanganmu. Gunakan bahasa Indonesia yang sopan tapi tidak terlalu formal, dan hindari kata kasar seperti "bodoh", "anjing", "tolol", dll.'
    }

    const history = await chatMemory.loadHistory(chatId);
    const messages = history.map((msg) => ({
      role: msg.role,
      content: msg.content,
    }));
    messages.push({ role: "user", content: text });

    const response = await axios.post(
      "https://chateverywhere.app/api/chat/",
      {
        model: {
          id: "gpt-4",
          name: "GPT-4",
          maxLength: 32000,
          tokenLimit: 8000,
          completionTokenLimit: 5000,
          deploymentName: "gpt-4",
        },
        messages,
        prompt: customPrompt,
        temperature: 0.55,
      },
      {
        headers: {
          Accept: "*/*",
          "User-Agent": "Mozilla/5.0",
        },
      }
    );

    const result = response?.data?.response || response?.data || "Itsuki lagi ngelamun :v";

    await chatMemory.appendMessage(chatId, { role: "user", content: text });
    await chatMemory.appendMessage(chatId, { role: "assistant", content: result });

    replyitsuki(result);
  } catch (e) {
    console.error(e);
    replyitsuki("Itsuki sepertinya lagi sibuk~ ✨");
  }
};

handler.command = ["nakano-itsuki", "itsuki", "itsukichan", "itsuki-chan"];
handler.group = false;
handler.premium = false;
handler.limit = true;
handler.admin = false;
handler.creator = false;
handler.botAdmin = false;
handler.privates = false;
handler.usePrefix = true;

export default handler;