import "../settings.js";
import fs from "fs";
import path from "path";
import { runtime } from "../lib/myfunc.js";

let handler = async (m, { RyuuBotz, reply, pushname, prefix, isPremium, isCreator, self_, checkName, text }) => {
  try {
    await RyuuBotz.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key } });

    // Fungsi hitung total user
    function countIdsFromFile(path = "./database/registered.json") {
      try {
        const rawData = fs.readFileSync(path);
        const database = JSON.parse(rawData);
        return database.length;
      } catch (err) {
        return 0;
      }
    }

    const infoBot = path.join("package.json");
    const botData = fs.readFileSync(infoBot, "utf8");
    const rootPackage = JSON.parse(botData);

    const totalIds = countIdsFromFile();
    const status = isPremium ? "ᴘʀᴇᴍɪᴜᴍ ✓" : "ғʀᴇᴇ 𝕏";
    const status_ = isCreator ? "ᴏᴡɴᴇʀ👑" : status;

    // 🌸 tambahan Mahiru untuk filter kategori
    let args = text?.trim()?.toLowerCase() || "";
    let filterCategory = args || null;

    // Baca semua plugin
    const folderPath = "./plugins";
    let menu = {};

    for (let file of fs.readdirSync(folderPath)) {
      if (file.endsWith(".js") && file.includes("--")) {
        let [category, featureWithExt] = file.split("--");
        let feature = featureWithExt.replace(".js", "");
        if (!menu[category]) menu[category] = [];
        menu[category].push(feature);
      }
    }

    // 🌷 Jika user mengetik .menu <kategori>
    if (filterCategory) {
      if (!menu[filterCategory]) {
        return reply(
          `⚠️ Kategori *${filterCategory}* tidak ditemukan!\n\nKategori yang tersedia:\n${Object.keys(menu)
            .map((v) => "• " + v)
            .join("\n")}`
        );
      }

      let list = menu[filterCategory]
        .sort()
        .map((f) => `• ${prefix}${f}`)
        .join("\n");

      let teks = `📂 *Kategori:* ${filterCategory.toUpperCase()}\n\n${list}`;

      return RyuuBotz.sendMessage(
        m.chat,
        {
          text: teks,
          contextInfo: {
            mentionedJid: [m.sender],
            externalAdReply: {
              title: global.namabot,
              body: `Menampilkan kategori ${filterCategory}`,
              thumbnailUrl: `${global.thumbnail}`,
              sourceUrl: `https://whatsapp.com/channel/0029Vb49CCWJ93wO2dLDqx14`,
              mediaType: 1,
              renderLargerThumbnail: true,
            },
          },
        },
        { quoted: m }
      );
    }

    // Ambil case command dari handler.js
    const code = fs.readFileSync("./handler.js", "utf8");
    const regex = /case\s+['"`]([^'"`]+)['"`]:/g;
    let matches = [],
      match;
    while ((match = regex.exec(code))) matches.push(match[1]);
    const tulong = [
      ...new Set(
        matches
          .map((v) => v.trim().split(" ")[0].toLowerCase())
          .filter(Boolean)
      ),
    ];

    // Bentuk tampilan menu
    let treeMenu = `./𝐙𝐚𝐡𝐥𝐞𝐚⁩\n`;
    treeMenu += `├─ INFO USER\n`;
    treeMenu += `│  ├─ Nama   : ${checkName(m.sender)}\n`;
    treeMenu += `│  ├─ Status : ${status_}\n`;
    treeMenu += `│  └─ Nomor  : @${m.sender.split("@")[0]}\n`;
    treeMenu += `│\n`;
    treeMenu += `├─ BOT INFO\n`;
    treeMenu += `│  ├─ Nama Bot : ${global.namabot}\n`;
    treeMenu += `│  ├─ Versi    : ${rootPackage.version}\n`;
    treeMenu += `│  ├─ Type     : CASE x PLUGIN\n`;
    treeMenu += `│  ├─ Runtime  : ${runtime(process.uptime())}\n`;
    treeMenu += `│  ├─ Developer: ${global.ownername}\n`;
    treeMenu += `│  ├─ Mode     : ${self_ ? "Self" : "Public"}\n`;
    treeMenu += `│  └─ Pengguna : ${totalIds} ${global.kosong}\n`;
    treeMenu += `└─ PLUGINS\n`;

    const categoryNames = Object.keys(menu).sort();
    categoryNames.forEach((category, i) => {
      const features = menu[category].sort();
      const isLastCategory = i === categoryNames.length - 1 && tulong.length === 0;
      const branchCat = isLastCategory ? "   └─" : "   ├─";
      treeMenu += `${branchCat} ${category}\n`;
      features.forEach((f, j) => {
        const isLastFeature = j === features.length - 1;
        const branchFeat = isLastFeature ? "   │  └─" : "   │  ├─";
        treeMenu += `${branchFeat} ${prefix}${f}\n`;
      });
    });

    if (tulong.length) {
      treeMenu += `   ├─ CASE\n`;
      tulong.forEach((c, i) => {
        const isLast = i === tulong.length - 1;
        const branch = isLast ? "   │  └─" : "   │  ├─";
        treeMenu += `${branch} ${prefix}${c}\n`;
      });
    }

    // Kirim menu utuh
    await RyuuBotz.sendMessage(
      m.chat,
      {
        text: treeMenu,
        contextInfo: {
          mentionedJid: [m.sender],
          forwardingScore: 1,
          isForwarded: true,
          forwardedNewsletterMessageInfo: {
            newsletterName: global.namabot,
            newsletterJid: "120363419382206255@newsletter",
          },
          externalAdReply: {
            title: global.namabot,
            body: global.ownername,
            thumbnailUrl: `${global.thumbnail}`,
            sourceUrl: `https://whatsapp.com/channel/0029Vb49CCWJ93wO2dLDqx14`,
            mediaType: 1,
            renderLargerThumbnail: true,
          },
        },
      },
      { quoted: m }
    );

  } catch (err) {
    await RyuuBotz.sendMessage(
      m.chat,
      { text: `⚠️ Ups, ada error: ${err.message}` },
      { quoted: m }
    );
  }
};

handler.command = ["menu"];
handler.group = false;
handler.premium = false;
handler.limit = false;
handler.admin = false;
handler.creator = false;
handler.botAdmin = false;
handler.privates = false;
handler.usePrefix = true

export default handler;