import fs from "fs";

const filePath = "./database/game/tebakkata.json";
const soalDB = fs.existsSync(filePath)
  ? JSON.parse(fs.readFileSync(filePath))
  : [];

const timeoutMap = {};
const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];

let handler = async (m, { reply, args }) => {
  const from = m.chat;
  const cmd = args[0]?.toLowerCase();
  if (!cmd) return reply("❌ Gunakan: .tebakkata <start/jawaban/nyerah>");

  const tmpFile = `./database/tmp/tebakkata-${from}.json`;
  const readSession = () => fs.existsSync(tmpFile) ? JSON.parse(fs.readFileSync(tmpFile)) : null;
  const saveSession = (data) => fs.writeFileSync(tmpFile, JSON.stringify(data));

  if (cmd === "start") {
    if (readSession()) return reply("⚠️ Masih ada game!");

    const data = pick(soalDB);
    const soal = data.soal;
    const jawaban = data.jawaban.toLowerCase();
    const hint = jawaban.replace(/[bcdfghjklmnpqrstvwxyz]/gi, "-");

    reply(`🔤 *TEBAK KATA*\n📝 Soal: ${soal}\n🔍 Clue: \`${hint}\`\n⏱️ 30 detik`);
    saveSession({ answer: jawaban });

    timeoutMap[from] = setTimeout(() => {
      if (readSession()) {
        reply(`⏱️ Waktu habis!\nJawaban: *${jawaban}*`);
        fs.unlinkSync(tmpFile);
      }
      delete timeoutMap[from];
    }, 30000);

    return;
  }

  if (cmd === "jawaban") {
    const session = readSession();
    if (!session) return reply("❌ Belum mulai!");

    const userAns = args.slice(1).join(" ").toLowerCase();
    if (!userAns) return reply("Masukkan jawaban!");

    if (userAns.includes(session.answer)) {
      clearTimeout(timeoutMap[from]);
      delete timeoutMap[from];
      fs.unlinkSync(tmpFile);
      return reply(`💗 Benar! *${session.answer}*`);
    }

    return reply("❌ Salah!");
  }

  if (cmd === "nyerah") {
    const session = readSession();
    if (!session) return reply("❌ Tidak ada game!");

    clearTimeout(timeoutMap[from]);
    delete timeoutMap[from];
    fs.unlinkSync(tmpFile);

    reply(`🫧 Jawabannya: *${session.answer}*`);
  }
};

handler.command = ["tebakkata"];
handler.group = true;
handler.premium = false;
handler.limit = true;
handler.admin = false;
handler.creator = false;
handler.botAdmin = false;
handler.privates = false;
handler.usePrefix = true;

export default handler;