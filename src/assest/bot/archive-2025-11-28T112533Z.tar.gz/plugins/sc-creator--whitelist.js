import "../settings.js";

const GH_USER = "Ryuu311";
const GH_REPO = "RyuuEnds";
const GH_PATH = "src/assest/bot/whitelist.json";
const GH_BRANCH = "main";
const GH_TOKEN = "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";

let handler = async (m, { args, reply, command, prefix }) => {
  const subcmd = args[0];
  const number = args[1];

  if (!["add", "del", "cek"].includes(subcmd))
    return reply(
      `❗Gunakan format:\n${prefix + command} add <nomor>\n${prefix + command} del <nomor>\n${prefix + command} cek <nomor>`
    );

  if (!number) return reply("⚠️ Nomor belum dimasukkan!");

  try {
    const res = await fetch(
      `https://api.github.com/repos/${GH_USER}/${GH_REPO}/contents/${GH_PATH}?ref=${GH_BRANCH}`,
      {
        headers: { Authorization: `Bearer ${GH_TOKEN}` }
      }
    );
    if (!res.ok) throw new Error(`Gagal ambil file (${res.status})`);
    const data = await res.json();

    const raw = Buffer.from(data.content, "base64").toString("utf-8");
    let list = JSON.parse(raw);
    if (!Array.isArray(list)) list = [];

    // ===== SUBCMD CEK =====
    if (subcmd === "cek") {
      if (list.includes(number))
        return reply(`✅ Nomor *${number}* ADA di whitelist!`);
      else return reply(`❌ Nomor *${number}* tidak ditemukan di whitelist.`);
    }

    // ===== SUBCMD ADD =====
    if (subcmd === "add") {
      if (list.includes(number)) return reply("⚠️ Nomor sudah ada di whitelist!");
      list.push(number);
    }

    // ===== SUBCMD DEL =====
    else if (subcmd === "del") {
      const index = list.indexOf(number);
      if (index === -1) return reply("❌ Nomor tidak ditemukan di whitelist!");
      list.splice(index, 1);
    }

    const updatedContent = Buffer.from(JSON.stringify(list, null, 2)).toString("base64");

    const commit = await fetch(
      `https://api.github.com/repos/${GH_USER}/${GH_REPO}/contents/${GH_PATH}`,
      {
        method: "PUT",
        headers: {
          Authorization: `Bearer ${GH_TOKEN}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          message:
            subcmd === "add"
              ? `Add ${number} to whitelist`
              : `Remove ${number} from whitelist`,
          content: updatedContent,
          sha: data.sha,
          branch: GH_BRANCH
        })
      }
    );

    if (!commit.ok) throw new Error(`Gagal commit (${commit.status})`);
    reply(
      `✅ Berhasil ${
        subcmd === "add" ? "menambahkan" : "menghapus"
      } *${number}* dari whitelist GitHub!`
    );
  } catch (err) {
    console.error(err);
    reply("❌ Terjadi kesalahan: " + err.message);
  }
};

handler.command = ["whitelist"];
handler.group = false;
handler.premium = false;
handler.limit = false;
handler.admin = false;
handler.creator = true;
handler.botAdmin = false;
handler.privates = false;
handler.usePrefix = true

export default handler;