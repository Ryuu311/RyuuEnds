import '../settings.js';
import fetch from "node-fetch";

let handler = async (m, { reply }) => {

    const headers = { Authorization: `Bearer ${global.vercelToken}` };
  const res = await fetch('https://api.vercel.com/v9/projects', { headers });
  const data = await res.json();

  if (!data.projects || data.projects.length === 0)
    return reply('Tidak ada website yang ditemukan.');

  let teks = '*🌐 Daftar Website Anda:*\n\n';
  for (let proj of data.projects) {
    teks += `• ${proj.name} → https://${proj.name}.vercel.app\n`;
  }

  reply(teks);
};

handler.command = ["listweb"];
handler.group = false
handler.premium = false
handler.limit = false
handler.admin = false
handler.creator = true
handler.botAdmin = false
handler.privates = false
handler.usePrefix = true

export default handler;