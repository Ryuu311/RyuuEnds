import "../settings.js";

let handler = async (m, { prefix, command, RyuuBotz, text, reply }) => {
  if (!m.quoted) return reply(`Reply media (foto/video/audio) yang ingin dikirim ke saluran.\n\nContoh: *${prefix + command} Ini caption-nya!*`);

  const idch = "120363419382206255@newsletter"
  const quoted = m.quoted;
  const mime = quoted.mimetype || '';
  const caption = text || '';
  const username = m.pushName;
  let url;

  try {
    url = await RyuuBotz.profilePictureUrl(m.sender, 'image');
  } catch {
    url = 'https://files.catbox.moe/f61syu.jpg';
  }

  try {
    const buffer = await quoted.download();
    let content;

    if (/image/.test(mime)) {
      content = {
        image: buffer,
        caption,
        contextInfo: {
          forwardingScore: 1,
          isForwarded: true,
          forwardedNewsletterMessageInfo: {
            newsletterName: global.ownername,
            newsletterJid: idch,
          },
          externalAdReply: {
            title: `Pesan dari ${username}`,
            body: 'Media ke Channel',
            thumbnailUrl: url,
            mediaType: 1,
            showAdAttribution: false,
          },
        },
      };
    } else if (/video/.test(mime)) {
      content = {
        video: buffer,
        caption,
        mimetype: mime,
        contextInfo: {
          forwardingScore: 1,
          isForwarded: true,
          forwardedNewsletterMessageInfo: {
            newsletterName: global.ownername,
            newsletterJid: idch,
          },
          externalAdReply: {
            title: `Pesan dari ${username}`,
            body: 'Video ke Channel',
            thumbnailUrl: url,
            mediaType: 1,
            showAdAttribution: false,
          },
        },
      };
    } else if (/audio/.test(mime)) {
      content = { 
      audio: buffer, 
      mimetype: mime, 
      ptt: true
       };
    } else {
      return reply("Jenis media tidak didukung. Reply foto, video, atau audio.");
    }

    await RyuuBotz.sendMessage(idch, content);
    reply(global.mess.success);

  } catch (err) {
    console.error(err);
    reply(`❌ Gagal meneruskan media:\n${err.message}`);
  }
};

handler.command = ["msgch2"];
handler.creator = true;
handler.group = false;
handler.premium = false;
handler.limit = false;
handler.admin = false;
handler.botAdmin = false;
handler.privates = false;
handler.usePrefix = true

export default handler;