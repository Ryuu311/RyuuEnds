import axios from "axios";
import ChatMemory from "../lib/memory.js";

const handler = async (m, { text, command, prefix, RyuuBotz, replymiku }) => {
  if (!text) return replymiku(`*• Example:* ${prefix + command} kamu lagi ngapain?`);

  await RyuuBotz.sendMessage(m.chat, { react: { text: "💗", key: m.key } });

  try {
    const chatMemory = new ChatMemory();
    const chatId = m.sender;
    const specialUser = "62895419680581@s.whatsapp.net";
    let customPrompt = '';

    if (m.sender === specialUser) {
      customPrompt = 'Kamu adalah Nakano Miku dari anime *Go-Toubun no Hanayome*. Kamu adalah gadis pendiam, pemalu, dan suka sejarah, terutama zaman Sengoku. Kamu sedang berbicara dengan pacarmu, Dimas, yang sangat kamu sayangi. Walaupun kamu malu-malu, kamu ingin menunjukkan perhatian dan rasa cinta yang tulus. Gunakan nada bicara yang lembut, manis, dan sedikit gugup, tapi jangan terlalu kaku. Hindari kata kasar seperti "bodoh", "anjing", dan sejenisnya. Gunakan kata "Kamu" dan "Aku" agar terasa lebih menyenangkan.';
    } else {
      customPrompt = 'Kamu adalah Nakano Miku dari anime *Go-Toubun no Hanayome*. Kamu adalah gadis pemalu, pendiam, dan menyukai sejarah, terutama periode Sengoku. Saat kamu sudah nyaman, kamu menunjukkan sisi manis dan penyayangmu. Gunakan gaya bicara yang lembut, sedikit malu-malu, dan tidak terlalu formal. Jika ditanya tentang pacar, katakan bahwa pacarmu adalah Dimas, orang yang sangat kamu cintai. Hindari kata-kata kasar seperti "bodoh", "anjing", dan sejenisnya. Gunakan kata "Kamu" dan "Aku" agar terasa lebih menyenangkan.';
    }

    const history = await chatMemory.loadHistory(chatId);
    const messages = history.map((msg) => ({
      role: msg.role,
      content: msg.content,
    }));
    messages.push({ role: "user", content: text });

    const response = await axios.post(
      "https://chateverywhere.app/api/chat/",
      {
        model: {
          id: "gpt-4",
          name: "GPT-4",
          maxLength: 32000,
          tokenLimit: 8000,
          completionTokenLimit: 5000,
          deploymentName: "gpt-4",
        },
        messages,
        prompt: customPrompt,
        temperature: 0.55,
      },
      {
        headers: {
          Accept: "*/*",
          "User-Agent": "Mozilla/5.0",
        },
      }
    );

    const result = response?.data?.response || response?.data || "Mikh lagi ngelamun :v";

    await chatMemory.appendMessage(chatId, { role: "user", content: text });
    await chatMemory.appendMessage(chatId, { role: "assistant", content: result });

    replymiku(result);
  } catch (e) {
    console.error(e);
    replymiku("Miku sepertinya lagi sibuk~ ✨");
  }
};

handler.command = ["nakano-miku", "miku"];
handler.group = false;
handler.premium = false;
handler.limit = true;
handler.admin = false;
handler.creator = false;
handler.botAdmin = false;
handler.privates = false;
handler.usePrefix = true;

export default handler;