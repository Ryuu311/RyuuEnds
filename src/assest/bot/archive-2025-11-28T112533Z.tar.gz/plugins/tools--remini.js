import fs from "fs";
import axios from "axios";
import FormData from "form-data";

let handler = async (m, { RyuuBotz, quoted, mime, reply, command, prefix }) => {
  if (!/image/.test(mime) || !quoted) {
    return reply(`📸 Kirim/reply foto dengan caption *${prefix + command}*`);
  }

  await RyuuBotz.sendMessage(m.chat, { react: { text: "⏳️", key: m.key } });

  try {
    // download media sementara
    let mediaPath = await RyuuBotz.downloadAndSaveMediaMessage(quoted);
    let fileSize = (fs.statSync(mediaPath).size / 1024).toFixed(2);

    // fungsi upload ke uguu.se
    async function UploadFileUgu(input) {
      return new Promise(async (resolve, reject) => {
        try {
          const form = new FormData();
          form.append("files[]", fs.createReadStream(input));

          const { data } = await axios.post("https://uguu.se/upload.php", form, {
            headers: {
              "User-Agent":
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36",
              ...form.getHeaders(),
            },
          });

          resolve(data.files[0]);
        } catch (e) {
          reject(e);
        }
      });
    }

    // upload file → dapat link
    let mem = await UploadFileUgu(mediaPath);

    // API remini
    const apiKey = "RyuuGanteng"; // ganti dengan API keymu
    const apiUrl = `https://api.ryuu-dev.offc.my.id/imagecreator/remini?apikey=${apiKey}&url=${mem.url}`;

    const { data } = await axios.get(apiUrl, {
      headers: { "Content-Type": "application/json", "User-Agent": "RyuuBotz/1.0" },
    });

    if (!data.status || !data.result) {
      throw new Error("Remini API gagal memproses gambar");
    }

    // kirim hasil
    await RyuuBotz.sendMessage(
      m.chat,
      {
        image: { url: data.result },
        caption: `_Sudah HD kak 🌸_\nUkuran file asli: ${fileSize} KB`,
      },
      { quoted: m }
    );

    fs.unlinkSync(mediaPath); // hapus file sementara
    await RyuuBotz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

  } catch (err) {
    console.error(err);
    reply(`Ups, terjadi kesalahan 🥺\n*Error:* ${err.message}`);
  }
};

handler.command = ["hd", "remini"];
handler.group = false
handler.premium = false
handler.limit = true
handler.admin = false
handler.creator = false
handler.botAdmin = false
handler.privates = false
handler.usePrefix = true

export default handler;