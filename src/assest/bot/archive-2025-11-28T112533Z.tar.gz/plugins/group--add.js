import "../settings.js";

let handler = async (m, { RyuuBotz, text, quoted, reply, mess }) => {
  try {

    let users;
    if (m.quoted) {
      users = await RyuuBotz.getPNFromLid(m.chat, m.quoted.sender)
    } else if (text) {
      let number = text.replace(/[^0-9]/g, "");
      if (number.length < 5) return reply("❌ Nomor tidak valid!");
      users = number + "@s.whatsapp.net";
    } else {
      return reply("📌 Silakan reply pesan atau ketik nomor yang ingin ditambahkan!!!");
    }

    await RyuuBotz.groupParticipantsUpdate(m.chat, [users], "add");
    reply(`✅ Berhasil menambahkan anggota @${users.split("@")[0]}!`, { mentions: [users] });
  } catch (err) {
    console.error(err);
    reply(`❌ Gagal menambahkan anggota!\n*Error:* ${err.message}`);
  }
};

handler.command = ["add"];
handler.group = true
handler.premium = false
handler.limit = false
handler.admin = true
handler.creator = false
handler.botAdmin = true
handler.privates = false
handler.usePrefix = true

export default handler;