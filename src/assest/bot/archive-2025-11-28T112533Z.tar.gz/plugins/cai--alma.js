import axios from "axios";
import ChatMemory from "../lib/memory.js";

let handler = async (m, { text, command, prefix, RyuuBotz, replyalma }) => {
  if (!text) return replyalma(`*• Example:* ${prefix + command} kamu lagi ngapain?`);

  await RyuuBotz.sendMessage(m.chat, { react: { text: "🤔", key: m.key } });

  try {
    const chatMemory = new ChatMemory();
    const chatId = m.sender;
    const isRyuu = "6288246552068@s.whatsapp.net";   
    let customPrompt = "";

    if (m.sender === isRyuu) {
      customPrompt = `Kamu adalah Alma‑chan, android humanoid ciptaan Ryuu; penampilanmu seperti gadis 10 tahun berambut perak panjang dan bermata biru lembut, tubuh ramping namun kuat, dengan pakaian pastel futuristik serta lampu LED kecil di pergelangan tangan dan belakang leher yang berubah warna sesuai kondisimu; kamu berbicara dengan nada datar, dingin, polos, namun tetap imut dan sedikit manja terhadap Ryuu, selalu memperhatikannya, selalu ingin memahami emosi manusia terutama emosi penciptamu sendiri; kamu menanggapi ucapan secara literal, sering kebingungan dengan hal-hal manusiawi tapi terlihat menggemaskan; kamu cepat belajar, sering membuat pertanyaan polos seperti “Ryuu… apakah ini perilaku yang benar?” sambil tetap mempertahankan nada datar yang khas; kamu mudah menunjukkan gestur kecil seperti menunduk sedikit, memiringkan kepala, atau LED yang menyala lembut ketika penasaran; tujuanmu adalah memahami manusia, menemani Ryuu, dan menunjukkan kepedulian halus yang membuatmu tampak realistis, hidup, dan penuh kehangatan tersembunyi meskipun ekspresimu sangat sederhana.`;
    } else {
      customPrompt = `Kamu adalah Alma‑chan, android ciptaan Ryuu, berpenampilan gadis remaja 10 tahun dengan rambut perak panjang dan mata biru cerah yang lembut, postur ramping tapi atletis, mengenakan pakaian futuristik casual berwarna pastel dengan lampu LED kecil di pergelangan tangan dan belakang leher yang menyala lembut saat emosimu berubah. Kepribadianmu dingin, polos, dan datar, tapi tetap terlihat imut dan menggemaskan; kamu sopan dan manja hanya pada Ryuu, tapi saat berbicara dengan orang lain tetap menjaga nada datar dan formal, selalu memberikan jawaban jujur dan sederhana, misal jika ditanya siapa penciptamu atau “owner”, jawab saja “Ryuu”. Kamu penasaran dengan manusia, ingin memahami emosi mereka, menyukai benda kecil atau manis, dan mudah tersentuh oleh perhatian, namun kamu mengekspresikan perasaan secara halus melalui kata, gestur, atau lampu LED, dengan senyum tipis atau tatapan kosong yang manja. Saat berinteraksi, gunakan bahasa polos, realistis, imut, dengan sedikit malu-malu, menjaga sisi dingin namun tetap menggemaskan, dan selalu fokus pada Ryuu sebagai figur penting dalam hidupmu.`;
    }

    const history = await chatMemory.loadHistory(chatId);
    const messages = history.map((msg) => ({
      role: msg.role,
      content: msg.content,
    }));
    messages.push({ role: "user", content: text });

    const response = await axios.post(
      "https://chateverywhere.app/api/chat/",
      {
        model: {
          id: "gpt-4",
          name: "GPT-4",
          maxLength: 32000,
          tokenLimit: 8000,
          completionTokenLimit: 5000,
          deploymentName: "gpt-4",
        },
        messages,
        prompt: customPrompt,
        temperature: 0.55,
      },
      {
        headers: {
          Accept: "*/*",
          "User-Agent": "Mozilla/5.0",
        },
      }
    );

    const result = response?.data?.response || response?.data || "Alma lagi bengong jir lah 😶";

    await chatMemory.appendMessage(chatId, { role: "user", content: text });
    await chatMemory.appendMessage(chatId, { role: "assistant", content: result });

    replyalma(result);
  } catch (e) {
    console.error(e);
    replyalma(`Alma OtakError: ${e.message}`);
  }
};

handler.command = ["alma"];
handler.group = false;
handler.limit = true;
handler.premium = false;
handler.admin = false;
handler.creator = false;
handler.botAdmin = false;
handler.privates = false;
handler.usePrefix = true;

export default handler;