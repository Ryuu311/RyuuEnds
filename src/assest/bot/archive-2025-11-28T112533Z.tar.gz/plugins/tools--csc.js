import "../settings.js";
import helper from "@ryuu-reinzz/button-helper";
const { sendInteractiveMessageV2 } = helper;
import axios from "axios";

let handler = async (m, { RyuuBotz, text, reply, command, prefix }) => {
  if (!text) {
    return reply(`Contoh:\n\n${prefix + command} javascript | Hello World | console.log("Hello Ryuu!");`);
  }

  // Parsing input
  const [language, title, ...codeParts] = text.split("|").map(a => a.trim());
  const code = codeParts.join("|");
  const cscApi = global.cscapi

  // Daftar bahasa yang diizinkan
  const allowedLang = [
    "plaintext", "html", "css", "javascript", "typescript",
    "php", "python", "java", "c#", "c++", "c"
  ];

  if (!allowedLang.includes(language?.toLowerCase())) {
    return reply(
      `❌ Bahasa tidak didukung!\n\nBahasa yang tersedia:\n${allowedLang.map(v => "• " + v).join("\n")}`
    );
  }

  if (!title) return reply(`*Kamu belum kasih nama kodenya* 🥺`);
  if (!code) return reply(`*Kodenya mana sayang~* 🤔`);

  await RyuuBotz.sendMessage(m.chat, {
    react: { text: "🪄", key: m.key },
  });

  try {
    const response = await axios.post(
      "https://codeshare.cloudku.click/users.php",
      {
        title: title,
        code_content: code,
        language: language,
      },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${cscApi}`,
        },
      }
    );

    const result = response.data;

if (!["success", true].includes(result.status) || !result.share_id) {
  return reply(`❌ Gagal membuat kode!\n${JSON.stringify(result, null, 2)}`);
}

const shareLink = `https://codeshare.cloudku.click/view/${result.share_id}`;
const caption = `✨ Kode berhasil dibuat!\n📜 Judul: *${title}*\n🌐 Bahasa: *${language}*\n\n🔗 ${shareLink}`;

    const buttons = {
      text: caption,
      footer: `© ${global.ownername} - 2025`,
      interactiveButtons: [
        {
          name: "cta_copy",
          buttonParamsJson: JSON.stringify({
            display_text: "Copy Link",
            copy_code: shareLink,
          }),
        },
      ],
    };

    await sendInteractiveMessageV2(RyuuBotz, m.chat, buttons);
  } catch (err) {
    console.error(err);
    reply(`❌ Error: ${err.response?.data?.message || err.message}`);
  }
};

handler.command = ["csc", "codeshare", "code_share"];
handler.group = false;
handler.premium = true;
handler.limit = true;
handler.admin = false;
handler.creator = false;
handler.botAdmin = false;
handler.privates = false;
handler.usePrefix = true

export default handler;