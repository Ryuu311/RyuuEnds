let handler = async (m, { RyuuBotz, stickerDB }) => {
  const teks = Object.entries(stickerDB).length
    ? `*📜 List Sticker Command*\n\n${Object.entries(stickerDB)
        .map(([key, value], i) => {
          const lockIcon = value.locked ? '🔒' : '🔓';
          return `${i + 1}. ${lockIcon} *${value.text}*\n   🧾 Hash: ${key}\n   👤 Creator: ${value.creator.split('@')[0]}\n`;
        })
        .join('\n')}`
    : 'Belum ada sticker command tersimpan~';

  RyuuBotz.sendText(
    m.chat,
    teks,
    m,
    {
      mentions: Object.values(stickerDB)
        .map(x => x.mentionedJid)
        .reduce((a, b) => [...a, ...b], []),
    }
  );
};

handler.command = ['listcmd'];
handler.creator = true;
handler.admin = false;
handler.group = false;
handler.premium = false;
handler.limit = false;
handler.botAdmin = false;
handler.privates = false;
handler.usePrefix = true;

export default handler;