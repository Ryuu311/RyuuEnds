import fs from "fs";
import "../settings.js";

let handler = async (m, { RyuuBotz, reply }) => {
  try {
    if (!m.quoted) return reply("📌 Mau hapus apa?");

    await RyuuBotz.sendMessage(
      m.chat,
      { sticker: fs.readFileSync("./stiker/ancam.webp") },
      { quoted: m }
    );

    await RyuuBotz.sendMessage(m.chat, {
      delete: {
        remoteJid: m.chat,
        fromMe: false,
        id: m.quoted.id,
        participant: m.quoted.sender,
      },
    });

    reply("✅ Pesan berhasil dihapus");
  } catch (err) {
    console.error(err);
    reply(`❌ Gagal menghapus pesan!\n*Error:* ${err.message}`);
  }
};

handler.command = ["delete", "cuih", "piu", "del"];
handler.group = true
handler.premium = false
handler.limit = false
handler.admin = true
handler.creator = false
handler.botAdmin = true
handler.privates = false
handler.usePrefix = true

export default handler;