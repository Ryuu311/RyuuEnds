import "../settings.js";

let handler = async (m, { text, reply, prefix, command }) => {
  if (!text) {
    return reply(
      `Contoh penggunaan:\n${prefix + command} on\n${prefix + command} off\n\nStatus autoread bot: *${global.autoread}*`
    );
  }

  if (text.toLowerCase() === "on") {
    global.autoread = true;
    reply(`✅ Autoread aktif\nStatus autoread sekarang ${global.autoread}`);
  } else if (text.toLowerCase() === "off") {
    global.autoread = false;
    reply(`✅ Autoread dimatikan\nStatus autoread sekarang ${global.autoread}`);
  } else {
    reply(
      `❌ Pilihan tidak valid.\nGunakan:\n${prefix + command} on\n${prefix + command} off`
    );
  }
};

handler.command = ["autoread"];
handler.group = false
handler.premium = false
handler.limit = false
handler.admin = false
handler.creator = true
handler.botAdmin = false
handler.privates = false
handler.usePrefix = true

export default handler;