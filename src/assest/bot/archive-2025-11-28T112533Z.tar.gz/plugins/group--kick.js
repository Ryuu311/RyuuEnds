import fs from "fs";
import "../settings.js"; // biar mess kebaca dari global

let handler = async (m, { RyuuBotz, text, reply, mess }) => {

  let users;
  if (m.mentionedJid.length > 0) {
    users = m.mentionedJid[0];
  } else if (m.quoted) {
    users = m.quoted.sender;
  } else if (text) {
    let number = text.replace(/[^0-9]/g, "");
    if (number.length < 5) return reply("Nomor tidak valid!");
    users = number + "@s.whatsapp.net";
  } else {
    return reply("Silakan tag, reply pesan, atau masukkan nomor yang ingin dikick!");
  }

  try {
    await RyuuBotz.sendMessage(
      m.chat,
      {
        sticker: fs.readFileSync("./stiker/kick.webp"),
      },
      { quoted: m }
    );

    await RyuuBotz.groupParticipantsUpdate(m.chat, [users], "remove");
    await RyuuBotz.sendMessage(m.chat, {
        text: `✅ Sukses mengeluarkan @${users.split("@")[0]}`,
        contextInfo: {
            mentionedJid: [users],
            forwardingScore: 1,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterName: '𝙕͢𝙖𝙝𝙡𝙚𝙖',
                newsletterJid: '120363419382206255@newsletter'
            },
            externalAdReply: {
                title: global.namabot,
                body: global.ownername,
                thumbnailUrl: 'https://api.ryuu-dev.offc.my.id/random/mahiruImages'
            }
        }
    }, { quoted: m });
    
  } catch (e) {
    console.error(e);
    reply("❌ Gagal mengeluarkan anggota. Mungkin karena bot bukan admin atau mencoba mengeluarkan sesama admin.");
  }
};

handler.command = ["kick", "duar", "dor"];
handler.group = true
handler.premium = false
handler.limit = false
handler.admin = true
handler.creator = false
handler.botAdmin = true
handler.privates = false
handler.usePrefix = true

export default handler;