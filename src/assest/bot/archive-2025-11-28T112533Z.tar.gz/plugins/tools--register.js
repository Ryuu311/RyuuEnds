import "../settings.js";

let handler = async (
  m,
  {
    isCreator,
    isRegistered,
    text,
    reply,
    RyuuBotz,
    deviceinfo,
    namabot,
    createSerial,
    addRegisteredUser,
    command,
    prefix
  }
) => {

  if (isRegistered) return reply("𝗸𝗮𝗺𝘂 𝘀𝘂𝗱𝗮𝗵 𝘁𝗲𝗿𝗱𝗮𝗳𝘁𝗮𝗿 𝘆𝗮𝗮 ✨");

  if (!text || text.trim().length === 0) {
    const name = m.pushName;

    return RyuuBotz.sendButton(m.chat, {
      footer: `${global.namabot}`,
      buttons: [
        {
          name: "single_select",
          buttonParamsJson: JSON.stringify({
            title: "𝗣𝗶𝗹𝗶𝗵 𝘂𝗺𝘂𝗿 𝗺𝘂 🎉🥳",
            sections: [
              {
                title: "𝗠𝗮𝘂 𝗱𝗮𝗳𝘁𝗮𝗿 𝘆𝗮𝗵? 𝗣𝗶𝗹𝗶𝗵 𝘂𝗺𝘂𝗿 𝗱𝘂𝗹𝘂 𝘆𝗮𝗮 😘",
                highlight_label: "𝗣𝗶𝗹𝗶𝗵 𝘂𝗺𝘂𝗿:",
                rows: Array.from({ length: 21 }, (_, i) => {
                  const umur = i + 10;
                  return {
                    title: `𝗨𝗺𝘂𝗿 𝗸𝘂 ${umur} 𝗧𝗮𝗵𝘂𝗻 🍰`,
                    description: `Umur diriku adalah ${umur} tahun.`,
                    id: `${prefix + command} ${name}, ${umur}`
                  };
                })
              }
            ]
          })
        }
      ],
      headerType: 1,
      viewOnce: true,
      image: { url: global.thumbnail },
      caption: `𝗠𝗮𝘂 𝗱𝗮𝗳𝘁𝗮𝗿? 𝗣𝗶𝗹𝗶𝗵 𝘂𝗺𝘂𝗿 𝗱𝘂𝗹𝘂 𝘆𝗮𝗮. 🍰\n𝗣𝗶𝗹𝗶𝗵 𝘂𝗺𝘂𝗿𝗺𝘂 𝗱𝗶 𝗯𝗮𝘄𝗮𝗵 𝗶𝗻𝗶: 🫧`,
      contextInfo: {
        mentionedJid: [m.sender],
      },
    });
  }

  const input = text.includes(",") ? text.split(",") :
                text.includes(".") ? text.split(".") : [];

  if (input.length !== 2)
    return reply("𝗙𝗼𝗿𝗺𝗮𝘁 𝗦𝗮𝗹𝗮𝗵!\n𝗚𝘂𝗻𝗮𝗸𝗮𝗻: .daftar nama,umur");

  const nama = input[0].trim();
  const umur = input[1].trim();

  if (!nama || !umur || isNaN(umur))
    return reply("𝗡𝗮𝗺𝗮 & 𝘂𝗺𝘂𝗿 𝗵𝗮𝗿𝘂𝘀 𝗱𝗶𝗶𝘀𝗶 𝗱𝗲𝗻𝗴𝗮𝗻 𝗯𝗲𝗻𝗮𝗿 𝘆𝗮𝗮 ✨");

  if (parseInt(umur) > 30)
    return reply("𝗬𝗮𝗵𝗵… 𝗺𝗮𝗸𝘀𝗶𝗺𝗮𝗹 𝘂𝗺𝘂𝗿 𝘂𝗻𝘁𝘂𝗸 𝗱𝗮𝗳𝘁𝗮𝗿 𝗶𝘁𝘂 𝟯𝟬 𝘆𝗮𝗮 🥺💗");

  const nomor = m.sender.split("@")[0];
  const serialUser = createSerial(20);
  const timeNow = Date.now();
  const limit = global.limitawal.free;

  const detectOperator = (number) => {
    const prefix = number.slice(0, 4);
    const operators = {
      Telkomsel: ["0811","0812","0813","0821","0822","0823","0852","0853","0851"],
      Indosat: ["0814","0815","0816","0855","0856","0857","0858"],
      XL: ["0817","0818","0819","0859","0877","0878"],
      Tri: ["0895","0896","0897","0898","0899"],
      Smartfren: ["0881","0882","0883","0884","0885","0886","0887","0888","0889"],
    };

    for (const [name, prefixes] of Object.entries(operators)) {
      if (prefixes.includes(prefix)) return name;
    }
    return "Tidak Diketahui";
  };

  const operator = detectOperator(
    nomor.replace(/[^0-9]/g, "").replace(/^62/, "0").slice(0, 12)
  );

  addRegisteredUser(m.sender, nama, umur, timeNow, limit, serialUser);

  let ppuser;
  try {
    ppuser = await RyuuBotz.profilePictureUrl(m.sender, "image");
  } catch {
    ppuser = "https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460960720.png?q=60";
  }

  const Msg = 
`🌸 𝗥 𝗘 𝗚 𝗜 𝗦 𝗧 𝗘 𝗥   𝗕 𝗘 𝗥 𝗛 𝗔 𝗦 𝗜 𝗟 🌸

Hai @${nomor} 🫧  
Kamu udah resmi terdaftar yaa~ 💗✨

• 👤 𝗡𝗮𝗺𝗮: ${nama}  
• 🎂 𝗨𝗺𝘂𝗿: ${umur}  
• 📱 𝗢𝗽𝗲𝗿𝗮𝘁𝗼𝗿: ${operator}  
• 📦 𝗦𝗲𝗿𝗶𝗮𝗹: ${serialUser}  
• 📟 𝗗𝗲𝘃𝗶𝗰𝗲: ${deviceinfo}

Makasih sudah daftar yaa…  
Semoga betah di sini 🤍  
Aku seneng banget nerima user baru kayak kamu~ 😘`;

  await RyuuBotz.sendMessage(m.chat, {
    text: Msg,
    contextInfo: {
      mentionedJid: [m.sender],
      externalAdReply: {
        title: "🌸 𝗡𝗘𝗪 𝗨𝗦𝗘𝗥 𝗥𝗘𝗚𝗜𝗦𝗧𝗘𝗥𝗘𝗗 🌸",
        body: "Selamat datang~ 💗",
        thumbnailUrl: ppuser,
        sourceUrl: global.saluran,
        mediaType: 1,
      },
    },
  });
};

handler.command = ["daftar", "regis", "register"];
handler.group = false
handler.premium = false
handler.limit = false
handler.admin = false
handler.creator = false
handler.botAdmin = false
handler.privates = false
handler.usePrefix = true

export default handler;