import "../settings.js";
import helper from '@ryuu-reinzz/button-helper';
const { sendInteractiveMessageV2 } = helper;
import fs from "fs";
import axios from "axios";
import FormData from "form-data";

let handler = async (m, { RyuuBotz, quoted, mime, reply }) => {
  if (!quoted) return reply(`Reply gambar/video yang ingin di-upload!`);
  if (!/image|video/.test(mime)) return reply(`Itu bukan video/gambar!`);

  await RyuuBotz.sendMessage(m.chat, {
    react: { text: "⏳️", key: m.key },
  });

  try {
    // simpan file sementara
    let mediaPath = await RyuuBotz.downloadAndSaveMediaMessage(quoted);

    const form = new FormData();
    form.append("file", fs.createReadStream(mediaPath));

    const res = await axios.post("https://api.aceimg.com/api/upload", form, {
      headers: {
        ...form.getHeaders(),
      },
    });

    fs.unlinkSync(mediaPath);

    const data = res.data;
    if (data.status && data.link) {
      // ambil filename dari link
      const match = data.link.match(/f=([^\s]+)/);
      const filename = match ? match[1] : null;

      if (filename) {
        const cdnLink = `https://cdn.aceimg.com/${filename}`;
        const caption = "Item kamu berhasil di-upload ✨";
        
        const buttons = {
  text: caption,
  footer: `© ${global.ownername} - 2025`,
  media: {
    type: 'document', 
    source: { 
      url: 'https://raw.githubusercontent.com/Ryuu311/Arisu-Botz/refs/heads/main/README.md' 
    },
    mimetype: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    fileName: 'Your Link',
    caption: '𝙍͢𝙮𝙪𝙪 𝙍͢𝙚𝙞𝙣𝙯𝙯',
    thumbnailUrl: cdnLink
  },
  interactiveButtons: [
  {
    name: 'cta_copy',
    buttonParamsJson: JSON.stringify({
      display_text: 'Your Link',
      copy_code: `${cdnLink}`
    })
  }
 ]
}          

        await sendInteractiveMessageV2(RyuuBotz, m.chat, buttons);
      } else {
        reply(`✅ Berhasil upload, tapi gagal ambil filename!\n🌐 Link: ${data.link}`);
      }
    } else {
      reply(`❌ Upload gagal!\n📄 ${data.message || "Tidak diketahui"}`);
    }
  } catch (err) {
    console.error(err);
    reply(`❌ Upload error: ${err.response?.data?.message || err.message}`);
  }
};

handler.command = ["tourl"];
handler.group = false
handler.premium = false
handler.limit = true
handler.admin = false
handler.creator = false
handler.botAdmin = false
handler.privates = false
handler.usePrefix = true

export default handler;