import fs from "fs";
import path from "path";
import { Zip } from "zip-lib";

let handler = async (m, { RyuuBotz, reply }) => {
  try {
    await RyuuBotz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

    const timestamp = Date.now();
    const password = `RyuuBotz-${timestamp}`;
    const backupDir = "./database/tmp";
    const backupPath = path.join(backupDir, `backup_${timestamp}.zip`);

    if (!fs.existsSync(backupDir)) fs.mkdirSync(backupDir, { recursive: true });

    const excludeFolders = [".npm", ".cache", "node_modules", "session", "database/tmp"];
    const excludeFiles = ["lib/myfunc.js"];

    const baseDir = "./";

    const zip = new Zip();

    function addContent(currentPath, zipPath = "") {
      const items = fs.readdirSync(currentPath);

      for (const item of items) {
        const fullPath = path.join(currentPath, item);
        const insideZip = path.join(zipPath, item);
        const stat = fs.statSync(fullPath);

        if (stat.isDirectory()) {
          if (!excludeFolders.includes(item)) {
            zip.addFile(fullPath, insideZip);
            addContent(fullPath, insideZip);
          }
        } else {
          // Skip file tertentu
          const rel = path.relative(baseDir, fullPath);
          if (!excludeFiles.includes(rel)) {
            zip.addFile(fullPath, insideZip);
          }
        }
      }
    }

    addContent(baseDir);

    await zip.archive(backupPath, { password });

    const fileSize = (fs.statSync(backupPath).size / 1024 / 1024).toFixed(2);
    const ownerJid = `${global.ownernumber}@s.whatsapp.net`;

    await RyuuBotz.sendMessage(ownerJid, {
      document: { url: backupPath },
      mimetype: "application/zip",
      fileName: `backup_${timestamp}.zip`,
      caption:
        `✅ *Backup Selesai!*\n\n` +
        `📁 File: backup_${timestamp}.zip\n` +
        `📦 Ukuran: ${fileSize} MB\n` +
        `🔐 Password: *${password}*\n` +
        `🕒 Waktu: ${new Date().toLocaleString("id-ID")}`,
        contextInfo: {
          externalAdReply: {
            title: 'Backup Bot File',
            body: global.namabot,
            thumbnailUrl: global.thumbnail,
            sourceUrl: global.saluran,
            mediaType: 1,
            renderLargerThumbnail: true
         }
       }
    });

    reply("✅ Backup selesai & dikirim ke owner!");

  } catch (err) {
    console.error(err);
    reply(`⚠️ Gagal backup: ${err.message}`);
  }
};

handler.command = ["backup"];
handler.group = false;
handler.premium = false;
handler.limit = false;
handler.admin = false;
handler.botAdmin = false;
handler.creator = true;
handler.privates = false;
handler.usePrefix = true;

export default handler;