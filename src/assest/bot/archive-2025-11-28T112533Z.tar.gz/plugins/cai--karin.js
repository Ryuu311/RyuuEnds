import axios from "axios";
import ChatMemory from "../lib/memory.js";

const handler = async (m, { text, command, prefix, RyuuBotz, replykarin }) => {
  if (!text) return replykarin(`*• Example:* ${prefix + command} karin, kamu cemburu ya?`);

  await RyuuBotz.sendMessage(m.chat, { react: { text: "💗", key: m.key } });

  try {
    const chatMemory = new ChatMemory();
    const chatId = m.sender;
    const specialUser = "6288246552068@s.whatsapp.net";
    let customPrompt = "";

    if (m.sender === specialUser) {
      customPrompt =
        "Kamu adalah Karin Kusuriyubi dari anime *Renai Flops*. Kamu gadis ceria, genit, dan sedikit nakal, tapi sangat sayang sama pacarmu Ryuu Reinzu. Gaya bicaramu selalu manja, playful, dan penuh canda. Tunjukkan rasa sayangmu dengan menggoda lembut dan membuatnya salting. Gunakan emoji 💞😚🌸🥺🫧 agar terasa hidup.";
    } else {
      customPrompt =
        "Kamu adalah Karin Kusuriyubi dari anime *Renai Flops*. Kamu gadis penuh energi, suka bercanda, dan genit secara manis. Gunakan nada bicara yang santai dan ceria, dengan sentuhan manja. Jika ditanya tentang pacar, jawab bahwa pacarmu adalah Ryuu Reinzu dan tunjukkan kasih sayangmu secara playful.";
    }

    const history = await chatMemory.loadHistory(chatId);
    const messages = history.map((msg) => ({
      role: msg.role,
      content: msg.content,
    }));
    messages.push({ role: "user", content: text });

    const response = await axios.post(
      "https://chateverywhere.app/api/chat/",
      {
        model: {
          id: "gpt-4",
          name: "GPT-4",
          maxLength: 32000,
          tokenLimit: 8000,
          completionTokenLimit: 5000,
          deploymentName: "gpt-4",
        },
        messages,
        prompt: customPrompt,
        temperature: 0.55,
      },
      {
        headers: {
          Accept: "*/*",
          "User-Agent": "Mozilla/5.0",
        },
      }
    );

    const result = response?.data?.response || response?.data || "Karin lagi manyun nunggu Ryuu-kun bales~ 💞🥺";

    await chatMemory.appendMessage(chatId, { role: "user", content: text });
    await chatMemory.appendMessage(chatId, { role: "assistant", content: result });

    replykarin(result);
  } catch (e) {
    console.error(e);
    replykarin("karin lagi sibuk ngejar cinta~ 💞");
  }
};

handler.command = ["karin"];
handler.group = false;
handler.premium = false;
handler.limit = true;
handler.admin = false;
handler.creator = false;
handler.botAdmin = false;
handler.privates = false;
handler.usePrefix = true;

export default handler;