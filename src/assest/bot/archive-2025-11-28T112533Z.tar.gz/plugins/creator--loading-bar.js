import "../settings.js";

let handler = async (m, { text, reply, prefix, command }) => {
  if (!text) {
    return reply(
      `Contoh penggunaan:\n${prefix + command} on\n${prefix + command} off\n\nStatus Loading Bar: *${global.BarLoad}*`
    );
  }

  if (text.toLowerCase() === "on") {
    global.BarLoad = true;
    reply(`✅ Loading Bar diaktifkan\nStatus Loading Bar sekarang ${global.BarLoad}`);
  } else if (text.toLowerCase() === "off") {
    global.BarLoad = false;
    reply(`✅ Loading Bar dimatikan\nStatus Loading Bar sekarang ${global.BarLoad}`);
  } else {
    reply(
      `❌ Pilihan tidak valid.\nGunakan:\n${prefix + command} on\n${prefix + command} off`
    );
  }
};

handler.command = ["loading-bar", "loading"];
handler.group = false
handler.premium = false
handler.limit = false
handler.admin = false
handler.creator = true
handler.botAdmin = false
handler.privates = false
handler.usePrefix = true

export default handler;