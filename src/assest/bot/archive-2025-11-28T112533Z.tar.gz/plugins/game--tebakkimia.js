import fs from "fs";

const filePath = "./database/game/tebakkimia.json";
const soalDB = fs.existsSync(filePath)
  ? JSON.parse(fs.readFileSync(filePath))
  : [];

const timeoutMap = {};
const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];

let handler = async (m, { reply, args }) => {
  const from = m.chat;
  const cmd = args[0]?.toLowerCase();
  if (!cmd) return reply("❌ .tebakkimia <start/jawaban/nyerah>");

  const tmpFile = `./database/tmp/tebakkimia-${from}.json`;
  const readSession = () => fs.existsSync(tmpFile) ? JSON.parse(fs.readFileSync(tmpFile)) : null;
  const saveSession = (data) => fs.writeFileSync(tmpFile, JSON.stringify(data));

  if (cmd === "start") {
    if (readSession()) return reply("⚠️ Masih ada game!");

    const data = pick(soalDB);
    reply(
      `🧪 *TEBAK KIMIA*\n` +
      `⚗️ Unsur: ${data.soal}\n` +
      `⏱️ 30 detik`
    );

    saveSession({ answer: data.jawaban.toLowerCase() });

    timeoutMap[from] = setTimeout(() => {
      if (readSession()) {
        reply(`⏱️ Habis!\nJawabannya: *${data.jawaban}*`);
        fs.unlinkSync(tmpFile);
      }
      delete timeoutMap[from];
    }, 30000);

    return;
  }

  if (cmd === "jawaban") {
    const session = readSession();
    if (!session) return reply("❌ Game belum mulai!");

    const userAns = args.slice(1).join(" ").toLowerCase();
    if (!userAns) return reply("❌ Masukkan jawaban!");

    if (userAns.includes(session.answer)) {
      clearTimeout(timeoutMap[from]);
      delete timeoutMap[from];
      fs.unlinkSync(tmpFile);
      return reply(`✨ Benar! *${session.answer}*`);
    }

    return reply("❌ Salah!");
  }

  if (cmd === "nyerah") {
    const session = readSession();
    if (!session) return reply("❌ Tidak ada game!");

    clearTimeout(timeoutMap[from]);
    delete timeoutMap[from];
    fs.unlinkSync(tmpFile);

    reply(`🫧 Jawabannya: *${session.answer}*`);
  }
};

handler.command = ["tebakkimia"];
handler.group = true;
handler.premium = false;
handler.limit = true;
handler.admin = false;
handler.creator = false;
handler.botAdmin = false;
handler.privates = false;
handler.usePrefix = true;

export default handler;