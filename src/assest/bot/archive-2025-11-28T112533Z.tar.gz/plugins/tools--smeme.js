import fs from "fs";
import axios from "axios";
import FormData from "form-data";

let handler = async (m, { RyuuBotz, text, quoted, reply, command, prefix }) => {

    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || '';
    let media = await RyuuBotz.downloadAndSaveMediaMessage(m.quoted)
    
  if (!/image|webp/.test(mime)) {
    return reply(`Kirim/reply gambar dengan caption *${prefix + command} text1|text2*`);
  }

  if (!text) {
    return reply(`✨ Contoh: *${prefix + command} atas|bawah*`);
  }

  // fungsi upload ke uguu.se
  async function UploadFileUgu(input) {
    return new Promise(async (resolve, reject) => {
      try {
        const form = new FormData();
        form.append("files[]", fs.createReadStream(input));

        const { data } = await axios.post("https://uguu.se/upload.php", form, {
          headers: {
            "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36",
            ...form.getHeaders(),
          },
        });

        resolve(data.files[0]);
      } catch (e) {
        reject(e);
      }
    });
  }

  let atas = text.split("|")[0] || "-";
  let bawah = text.split("|")[1] || "-";

  // download media
  let mem = await UploadFileUgu(media);

  // generate link meme API
  let meme = `https://api.ryuu-dev.offc.my.id/tools/smeme?img=${mem.url}&atas=${encodeURIComponent(
    atas
  )}&bawah=${encodeURIComponent(bawah)}`;

  await RyuuBotz.sendMessage(m.chat, { react: { text: "🕒", key: m.key } });

  await RyuuBotz.sendImageAsSticker(
    m.chat,
    meme,
    m,
    { packname: global.packname, author: global.author }
  );

  await RyuuBotz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
};

handler.command = ["smeme", "stickermeme", "stickmeme"];
handler.group = false
handler.premium = false
handler.limit = true
handler.admin = false
handler.creator = false
handler.botAdmin = false
handler.privates = false
handler.usePrefix = true

export default handler;