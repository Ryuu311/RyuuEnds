import "../settings.js";  
import helper from '@ryuu-reinzz/button-helper';  
const { sendInteractiveMessageV2 } = helper;  
import fs from "fs";  
import path from "path";  
import { runtime } from "../lib/myfunc.js";  
  
let handler = async (m, { RyuuBotz, prefix, command, text, isPremium, isCreator, self_, checkName }) => {  
  try {  
    await RyuuBotz.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key } });  
  
    // Hitung jumlah user terdaftar  
    function countIdsFromFile(path = "./database/registered.json") {  
      try {  
        const rawData = fs.readFileSync(path);  
        const database = JSON.parse(rawData);  
        return database.length;  
      } catch {  
        return 0;  
      }  
    }  
  
    // Ambil info dari package.json  
    const botData = fs.readFileSync("package.json", "utf8");  
    const rootPackage = JSON.parse(botData);  
  
    // Status user  
    const status = isPremium ? "ᴘʀᴇᴍɪᴜᴍ ✓" : "ғʀᴇᴇ 𝕏";  
    const status_ = isCreator ? "ᴏᴡɴᴇʀ👑" : status;  
    const totalIds = countIdsFromFile();  
  
    // Ambil plugin (kategori--fitur.js)  
    const folderPath = "./plugins";  
    let menu = {};  
    for (let file of fs.readdirSync(folderPath)) {  
      if (file.endsWith(".js") && file.includes("--")) {  
        let [category, featureWithExt] = file.split("--");  
        let feature = featureWithExt.replace(".js", "");  
        if (!menu[category]) menu[category] = [];  
        menu[category].push(feature);  
      }  
    }  
  
    // Buat sections untuk button interaktif  
    const sections = Object.keys(menu).sort().map((category) => ({  
      title: category.toUpperCase(),  
      rows: menu[category].sort().map((f) => ({  
        title: `${prefix}${f}`,  
        id: `${prefix}${f}`  
      }))  
    }));  
  
    // Tambahkan section "Info" di atas  
    sections.unshift({  
      title: "INFORMASI BOT",  
      rows: [  
        { title: `Nama Bot: ${global.namabot}`, id: global.namabot },  
        { title: `Versi ${rootPackage.version}`, id: rootPackage.version },  
        { title: `Runtime; ${runtime(process.uptime())}`, id: runtime(process.uptime()) },  
        { title: `Mode: ${self_ ? "Self" : "Public"}`, id: self_ ? "Self" : "Public" },  
        { title: `User Terdaftar: ${totalIds.toString()}`, id: totalIds.toString() }  
      ]  
    });  
  
    // Bangun pesan interaktif  
    const buttons = {  
      text: `┌───❖ 「 ɪɴꜰᴏ ᴜꜱᴇʀ 」\n│ Nama   : ${checkName(m.sender)}\n│ Status : ${status_}\n│ Nomor  : ${m.sender.split("@")[0]}\n└───────────────❖\n\nPilih menu di bawah ini ya 💫`,  
      footer: `© ${global.ownername} - 2025`,  
      media: {  
        type: "document",  
        source: { url: "https://raw.githubusercontent.com/Ryuu311/Arisu-Botz/refs/heads/main/README.md" },  
        mimetype: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",  
        fileName: "Menu",  
        caption: "𝙍͢𝙮𝙪𝙪 𝙍͢𝙚𝙞𝙣𝙯𝙯",  
        thumbnailUrl: global.thumbnail  
      },  
      interactiveButtons: [  
        {  
          name: "single_select",  
          buttonParamsJson: JSON.stringify({  
            title: "PILIH MENU DI SINI",  
            sections  
          })  
        }  
      ]  
    };  
  
    // Kirim menu  
    await sendInteractiveMessageV2(RyuuBotz, m.chat, buttons);  
  
  } catch (err) {  
    await RyuuBotz.sendMessage(m.chat, { text: `⚠️ Terjadi error: ${err.message}` }, { quoted: m });  
  }  
};  
  
handler.command = ["menu-v2", "menu-button", "menuv2", "menubutton"];  
handler.group = false  
handler.premium = false  
handler.limit = false  
handler.admin = false  
handler.creator = false  
handler.botAdmin = false  
handler.privates = false  
handler.usePrefix = true
  
export default handler;