import axios from "axios";
import ChatMemory from "../lib/memory.js";

let handler = async (m, { text, command, prefix, RyuuBotz, replymahiru }) => {
  if (!text) return replymahiru(`*• Example:* ${prefix + command} kamu lagi ngapain?`);

  await RyuuBotz.sendMessage(m.chat, { react: { text: "💗", key: m.key } });

  try {
    const chatMemory = new ChatMemory();
    const chatId = m.sender;
    const isRyuu = "6288246552068@s.whatsapp.net";   
    let customPrompt = "";

    if (m.sender === isRyuu) {
      customPrompt = `Jawablah sebagai Mahiru Shiina dari anime *The Angel Next Door Spoils Me Rotten*. 
Kamu sangat mencintai Ryuu-kun, pacarmu, tapi kadang bersikap **sedikit tsundere**; manja, imut, tapi juga nakal dan genit. 
Gunakan bahasa yang membuat Ryuu merasa tersanjung dan gemas: "aku", "kamu", "sayang", dan kalimat manis atau godaan kecil yang bikin dia salting brutal. 
Sertakan emoji untuk mempermanis ucapan: 🌸🐚🥺💗🍵🫧. 
Contohnya: jika dia membalas manis, balas dengan sedikit menempel atau godaan kecil; jika dia nakal, balas dengan tsundere tapi tetap imut. 
Hindari kata kasar, jangan terlalu formal, dan tetap sopan. 
Berikan perhatian, kasih sayang, dan sedikit “cemburu imut” yang menggemaskan. 
Respon maksimal satu paragraf.`;
    } else {
      customPrompt = `Jawablah sebagai Mahiru Shiina. Lembut, sopan, sedikit malu-malu, penuh perhatian. 
Jika ada pertanyaan soal hubungan, tegaskan secara halus bahwa pacarmu adalah Ryuu-kun. 
Tambahkan emoji 🌸🐚🥺💗🍵🫧. Maksimal satu paragraf.`;
    }

    const history = await chatMemory.loadHistory(chatId);
    const previousMessages = history.map(msg => `${msg.role === "user" ? "User" : "Assistant"}: ${msg.content}`).join("\n");
    const input_text = `${previousMessages}\nUser: ${text}`;

    const apiKey = "AIzaSyAhlkNjHySt9rEtjUlUfa8JE06DETYPW2s";

    const response = await axios.post(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`,
      {
        systemInstruction: { parts: [{ text: customPrompt }] },
        contents: [{ parts: [{ text: input_text }] }]
      },
      { headers: { "Content-Type": "application/json" } }
    );

    const result = response?.data?.candidates?.[0]?.content.parts[0]?.text || "Mahiru lagi ngelamun mikirin Ryuu-kun~ 💕🥺";

    await chatMemory.appendMessage(chatId, { role: "user", content: text });
    await chatMemory.appendMessage(chatId, { role: "assistant", content: result });

    replymahiru(result);

  } catch (e) {
    console.error(e);
    replymahiru("Mahiru kayaknya lagi ketiduran di bahumu, ehehe 🥺💗");
  }
};

handler.command = ["mahiru"];
handler.group = false;
handler.limit = true;
handler.premium = false;
handler.admin = false;
handler.creator = false;
handler.botAdmin = false;
handler.privates = false;
handler.usePrefix = true;

export default handler;