import "../settings.js";

let handler = async (
  m,
  { isRegistered, reply, RyuuBotz, removeRegisteredUser }
) => {

  if (!isRegistered)
    return reply("Ehh kamu belum terdaftar sayang… jadi belum bisa unreg dulu yaa 🥺💗");

  removeRegisteredUser(m.sender);
  const nomor = m.sender.split("@")[0];

  const teks = 
`💗✨ *U N R E G I S   B E R H A S I L* ✨💗

Kamu @${nomor}~  
Data kamu udah aku hapus yaa… 🫧

• 📌 *Status:* Tidak terdaftar lagi  
• 🗑️ *Data:* Sudah dibersihkan  

Kalau nanti kangen dan mau daftar lagi…  
ketik aja *\`.daftar nama,umur\`* yaa~  
Aku bakal sambut kamu lagi dengan senyuman manis 😘🌸`;

  let ppuser;
  try {
    ppuser = await RyuuBotz.profilePictureUrl(m.sender, "image");
  } catch {
    ppuser = "https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460960720.png?q=60";
  }

  await RyuuBotz.sendMessage(m.chat, {
    text: teks,
    contextInfo: {
      mentionedJid: [m.sender],
      externalAdReply: {
        title: "🌸 U N R E G I S T E R 🌸",
        body: "Akunmu sudah dihapus yaa sayang 💗",
        thumbnailUrl: ppuser,
        sourceUrl: global.saluran,
        mediaType: 1,
      },
    },
  });
};

handler.command = ["unregis", "unregister"];
handler.group = false;
handler.premium = false;
handler.limit = false;
handler.admin = false;
handler.creator = false;
handler.botAdmin = false;
handler.privates = false;
handler.usePrefix = true

export default handler;