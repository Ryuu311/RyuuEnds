import "../settings.js";

let handler = async (m, { text, reply, prefix, command }) => {
  if (!text) {
    return reply(
      `Contoh penggunaan:\n${prefix + command} off\n${prefix + command} on\n\nStatus antiTypo bot: *${global.antiTypo}*`
    );
  }

  if (text.toLowerCase() === "on") {
    global.antiTypo = true;
    reply(`✅ Bot antitypo off\nStatus antiTypo bot sekarang ${global.antiTypo}`);
  } else if (text.toLowerCase() === "off") {
    global.antiTypo = false;
    reply(`✅ Bot antitypo on\nStatus antiTypo bot sekarang ${global.antiTypo}`);
  } else {
    reply(
      `❌ Pilihan tidak valid.\nGunakan:\n${prefix + command} on\n${prefix + command} off`
    );
  }
};

handler.command = ["antitypo", "similitary", "didyoumean"];
handler.group = false
handler.premium = false
handler.limit = false
handler.admin = false
handler.creator = true
handler.botAdmin = false
handler.privates = false
handler.usePrefix = true

export default handler;