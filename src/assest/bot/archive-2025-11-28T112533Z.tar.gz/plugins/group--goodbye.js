import "../settings.js";
import fs from "fs";

let handler = async (m, { RyuuBotz, text, mime, quoted, reply, db, prefix, command, pushname }) => {

    if (!db.groups) db.groups = {};
    if (!db.groups[m.chat]) db.groups[m.chat] = { goodbye: false };

    if (!text) {
      return reply(
        `Gunakan:\n` +
        `.goodbye on\n` +
        `.goodbye off\n` +
        `.goodbye set <teks>\n\n` +
        `Format teks:\n@user = mention member\n@group = nama grup`
      );
    }

    if (text.toLowerCase() === "on") {
      db.groups[m.chat].goodbye = true;
      reply(`✅ Goodbye diaktifkan di grup ini.`);
    } else if (text.toLowerCase() === "off") {
      db.groups[m.chat].goodbye = false;
      reply(`❎ Goodbye dimatikan di grup ini.`);
    } else if (text.toLowerCase().startsWith("set ")) {
      let teks = text.slice(4).trim();
      db.groups[m.chat].goodbyeText = teks;
      reply(`✅ Pesan goodbye berhasil diatur:\n${teks}`);
    } else {
      reply(`❌ Opsi tidak dikenal!`);
    }

    fs.writeFileSync("./database/welcome.json", JSON.stringify(db, null, 2));
};

handler.command = ["goodbye"];
handler.group = true
handler.premium = false
handler.limit = false
handler.admin = true
handler.creator = false
handler.botAdmin = true
handler.privates = false
handler.usePrefix = true

export default handler;