import fs from "fs";

let handler = async (m, { text, reply, db }) => {

    if (!db.groups) db.groups = {};
    if (!db.groups[m.chat]) db.groups[m.chat] = { welcome: false };

    if (!text) {
      return reply(
        `Gunakan:\n` +
        `.welcome on\n` +
        `.welcome off\n` +
        `.welcome set <teks>\n\n` +
        `Format teks bisa pakai:\n` +
        `@user = mention member\n` +
        `@group = nama grup`
      );
    }

    if (text.toLowerCase() === "on") {
      db.groups[m.chat].welcome = true;
      reply(`✅ Welcome diaktifkan di grup ini.`);
    } else if (text.toLowerCase() === "off") {
      db.groups[m.chat].welcome = false;
      reply(`❎ Welcome dimatikan di grup ini.`);
    } else if (text.toLowerCase().startsWith("set ")) {
      let teks = text.slice(4).trim();
      db.groups[m.chat].welcomeText = teks;
      reply(`✅ Pesan welcome berhasil diatur:\n${teks}`);
    } else {
      reply(`❌ Opsi tidak dikenal!`);
    }

    fs.writeFileSync("./database/welcome.json", JSON.stringify(db, null, 2));
};

handler.command = ["welcome"];
handler.group = true
handler.premium = false
handler.limit = false
handler.admin = true
handler.creator = false
handler.botAdmin = true
handler.privates = false
handler.usePrefix = true

export default handler;