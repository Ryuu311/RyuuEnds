import '../settings.js';
import fs from "fs";
import path from "path";
import { startJadiBot, stopJadiBot } from "../jadibot.js";

let handler = async (m, { RyuuBotz, text, prefix, reply, command, isCreator }) => {
  const idBot = RyuuBotz.user.id;
  const botNow = idBot.split(":")[0];
  const isBot = botNow === global.nomorbot;

  const args = text.trim().split(" ");
  const sub = args[0];
  const num = args[1];
  const mode = args[2];

  const baseDir = "./database/jadibot/";

  if (!sub || !["add", "list", "delete", "trial", "set"].includes(sub)) {
    return reply(
      `📌 Cara pakai:\n\n` +
      `${prefix}${command} add <nomor>\n` +
      `${prefix}${command} delete <nomor>\n` +
      `${prefix}${command} set <nomor> self/public\n` +
      `${prefix}${command} trial <nomor> (3 jam)\n` +
      `${prefix}${command} list`
    );
  }

  switch (sub) {
    // =========================================
    case "add":
      if (!isCreator) return reply(mess.creator);
      if (!num) return reply(`❌ Masukkan nomor yang mau dibuat JadiBot.`);

      const number = num.replace(/[^0-9]/g, "");
      if (number.length < 7) return reply(`❌ Nomor tidak valid.`);

      reply(`⏳ Membuat session untuk *${number}*...`);

      try {
        const code = await startJadiBot(number);
        reply(
          `✨ *JadiBot Siap!* \n\n` +
          `Kode pairing *${number}*:\n👉 *${code}*\n\n` +
          `Silakan login via WhatsApp.`
        );
      } catch (e) {
        reply(`❌ Gagal membuat session.\n${e.message}`);
      }
    break;

    // =========================================
    case "list":
      if (!isCreator) return reply(mess.creator);

      try {
        const dirs = fs.readdirSync(baseDir).filter(d =>
          fs.statSync(path.join(baseDir, d)).isDirectory()
        );

        if (!dirs.length) return reply(`📂 Tidak ada folder nomor di database.`);

        const listText =
          `📋 *Daftar JadiBot yang tersimpan:*\n\n` +
          dirs.map((v, i) => `${i + 1}. ${v}`).join("\n");

        reply(listText);
      } catch (err) {
        reply(`❌ Gagal membaca database.\n${err.message}`);
      }
    break;

    // =========================================
    case "delete":
      if (!isCreator) return reply(mess.creator);
      if (!num) return reply(`❌ Masukkan nomor yang mau dihapus.`);

      const folder = path.join(baseDir, num);

      if (!fs.existsSync(folder))
        return reply(`❌ Folder *${num}* tidak ditemukan.`);

      try {
        stopJadiBot(num);
        fs.rmSync(folder, { recursive: true, force: true });    
        reply(`🗑️ Berhasil menghapus folder *${num}* beserta sessionnya.`);
      } catch (err) {
        reply(`❌ Gagal menghapus.\n${err.message}`);
      }
    break;

    // =========================================
    case "set":
  if (!isCreator) return reply(mess.creator);
  if (!num) return reply(`❌ Masukkan nomor yang mau di-set.`);

  const dir = `./database/jadibot/${num}`;
  const filePath = `${dir}/code-${num}.json`;

  if (!fs.existsSync(filePath))
    return reply(`❌ Data pairing untuk nomor itu belum ada.`);
  let raw = fs.readFileSync(filePath, "utf8");
  let json = JSON.parse(raw);

  if (!mode) {
    return reply(
      `ℹ️ Mode untuk nomor *${num}* sekarang: *${json.self ? "self" : "public"}*`
    );
  }

  if (!["self", "public"].includes(mode))
    return reply(`❌ Mode harus 'self' atau 'public'.`);
  try {
    json.self = mode === "self";
    fs.writeFileSync(filePath, JSON.stringify(json, null, 2));
    reply(`✔️ Setting untuk ${num} berhasil diubah ke *${mode}*`);
  } catch (err) {
    reply(`❌ Gagal mengubah setting.\n${err.message}`);
  }

  break;

    // =========================================
    case "trial":
      if (!isBot)
        return reply(`❌ Trial harus dengan bot utama! Chat ${global.nomorbot} untuk trial.`);

      if (!num) return reply(`❌ Masukkan nomor untuk jadibot *trial*.`);

      const trialNumber = num.replace(/[^0-9]/g, "");
      if (trialNumber.length < 7) return reply(`❌ Nomor tidak valid.`);

      reply(`⏳ Membuat session trial untuk *${trialNumber}*...`);

      try {
        const code = await startJadiBot(trialNumber);

        reply(
          `✨ *JadiBot Trial Siap!* \n\n` +
          `Kode pairing *${trialNumber}*:\n👉 *${code}*\n\n` +
          `Silakan login via WhatsApp.`
        );

        const trialFolder = `./database/jadibot/${trialNumber}`;
        
        setTimeout(() => {
          try {
            stopJadiBot(trialNumber);  
            fs.rmSync(trialFolder, { recursive: true, force: true });
            console.log(`Trial ${trialNumber} otomatis dihentikan & folder dihapus`);
          } catch (err) {
            console.error("Error auto-stop trial:", err);
          }
        }, 3 * 60 * 60 * 1000);

      } catch (e) {
        reply(`❌ Gagal membuat session.\n${e.message}`);
      }
    break;    
  }
};

handler.command = ["jadibot"];
handler.group = false;
handler.premium = false;
handler.limit = false;
handler.admin = false;
handler.creator = false;
handler.botAdmin = false;
handler.privates = false;
handler.usePrefix = true;

export default handler;