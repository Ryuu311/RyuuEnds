import fs from "fs";
import { exec } from "child_process";
import util from "util";
const execPromise = util.promisify(exec);

let handler = async (m, { RyuuBotz, q, reply }) => {
try {    
    if (!m.quoted) return reply("Silakan balas ke pesan audio MP3 terlebih dahulu.");
    if (!/audio/.test(m.quoted.mimetype)) return reply("Pesan yang dibalas bukan audio.");
    await RyuuBotz.sendMessage(m.chat, { react: { text: "⏱️", key: m.key } });

    if (!fs.existsSync("./database/tmp")) fs.mkdirSync("./database/tmp");

    const media = await m.quoted.download();
    const input = "./database/tmp/input.mp3";
    const output = "./database/tmp/output.ogg";

    fs.writeFileSync(input, media);

    await execPromise(
      `ffmpeg -y -i "${input}" -vn -ac 2 -b:a 128k -ar 48000 -c:a libopus "${output}"`
    );

    await RyuuBotz.sendMessage(
      m.chat,
      {
        audio: fs.readFileSync(output),
        mimetype: "audio/ogg; codecs=opus",
        ptt: true,
      },
      { quoted: m }
    );

    fs.unlinkSync(input);
    fs.unlinkSync(output);
  } catch (e) {
    console.error(e);
    reply("Terjadi kesalahan saat mengonversi audio.");
    }
  };
handler.command = ['to-ptt']
handler.group = false
handler.premium = false
handler.limit = true
handler.admin = false
handler.creator = false
handler.botAdmin = false
handler.privates = false
handler.usePrefix = true

export default handler