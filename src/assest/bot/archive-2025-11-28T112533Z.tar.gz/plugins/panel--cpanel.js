import "../settings.js";
import axios from "axios";
import helper from "@ryuu-reinzz/button-helper";
const { sendInteractiveMessageV2 } = helper;

let handler = async (m, { prefix, command, RyuuBotz, text, reply }) => {
  if (!text)
    return reply(
      `📦 *Usage:*\n.cpanel <diskGiB>|<ramGiB>|<cpu>|<nama>\n\n📌 *Example:*\n.cpanel 10|2|20|RyuuDev`
    );

  const [diskGiB, ramGiB, cpu, name, targets] = text.split("|");
  if (!diskGiB || !ramGiB || !cpu || !name)
    return reply(
      `⚠️ Format salah!\n\nGunakan seperti ini:\n${prefix + command} 10|2|20|Ryuu`
    );

  const disk = parseFloat(diskGiB) * 1024;
  const ram = parseFloat(ramGiB) * 1024;

  let target = targets ? targets + "@s.whatsapp.net" : m.sender;

  await RyuuBotz.sendMessage(m.chat, {
    react: { text: "⏱️", key: m.key },
  });

  try {
    const ptla = global.aapikey;
    const ptlc = global.capikey;
    const Domain = global.domain;
    const NestId = global.nestId;
    const node = 24;

    const res = await axios.get(
      `https://api.ryuu-dev.offc.my.id/tools/cpanel?capikey=${encodeURIComponent(
        ptlc
      )}&aapikey=${encodeURIComponent(ptla)}&ram=${encodeURIComponent(
        ram
      )}&disk=${encodeURIComponent(disk)}&name=${encodeURIComponent(
        name
      )}&nestID=${encodeURIComponent(NestId)}&egg=15&location=1&cpu=${encodeURIComponent(
        cpu
      )}&domain=${encodeURIComponent(Domain)}&node=${encodeURIComponent(node)}`
    );

    const data = res.data;
    if (!data.status)
      return reply(`❌ Gagal membuat panel!\n💬 ${data.message || "Unknown error"}`);

    const usn = data.user?.username || name;
    const pw = data.pw || `${name}001`;
    const domain = Domain || "Tidak ditemukan";

    const caption = `✅ *Create Panel Successfully*\n\n👤 *Name:* ${usn}\n🔑 *Password:* ${pw}\n🌐 *Domain:* ${domain}\n\n🧩 *CPU:* ${cpu}%\n💾 *RAM:* ${ramGiB} GiB\n📀 *Disk:* ${diskGiB} GiB`;

    const buttons = {
      text: caption,
      footer: `© ${global.ownername} - 2025`,
      media: {
        type: "document",
        source: {
          url: "https://raw.githubusercontent.com/Ryuu311/Arisu-Botz/refs/heads/main/README.md",
        },
        mimetype:
          "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        fileName: "Your Panel Ready",
        caption: "𝙍͢𝙮𝙪𝙪 𝙍͢𝙚𝙞𝙣𝙯𝙯",
        thumbnailUrl: global.thumbnail,
      },
      interactiveButtons: [
        {
          name: "cta_copy",
          buttonParamsJson: JSON.stringify({
            display_text: "Salin Username",
            copy_code: `${usn}`,
          }),
        },
        {
          name: "cta_copy",
          buttonParamsJson: JSON.stringify({
            display_text: "Salin Password",
            copy_code: `${pw}`,
          }),
        },
        {
          name: "cta_url",
          buttonParamsJson: JSON.stringify({
            display_text: "Login Panel",
            url: `${domain}`,
          }),
        },
      ],
    };

    await sendInteractiveMessageV2(RyuuBotz, target, buttons);
  } catch (err) {
    console.error(err);
    reply(
      `❌ *Error membuat panel!*\n${err.response?.data?.message || err.message}`
    );
  }
};

handler.command = ["cpanel"];
handler.group = false;
handler.premium = true;
handler.limit = false;
handler.admin = false;
handler.creator = false;
handler.botAdmin = false;
handler.privates = false;
handler.usePrefix = true

export default handler;