import fs from "fs";
import "../settings.js";
let ntlinkch = JSON.parse(fs.readFileSync('./database/antilinkch.json'));

let handler = async (m, { text, reply, pushname, prefix, command, RyuuBotz }) => {
  try {

    let set = (text || "").toLowerCase();

    if (set === "on") {
      if (ntlinkch.includes(m.chat)) return reply("⚠️ Antilinkch sudah aktif di grup ini.");
      ntlinkch.push(m.chat);
      fs.writeFileSync('./database/antilinkch.json', JSON.stringify(ntlinkch));
      reply("✅ Fitur antilinkch telah diaktifkan.\nBot akan otomatis hapus pesan yang berisi link grup.");

      let groupe = await RyuuBotz.groupMetadata(m.chat);
      let members = groupe.participants;
      let mems = members.map(adm => adm.id.replace('c.us', 's.whatsapp.net'));
      await RyuuBotz.sendMessage(m.chat, { 
        text: "⚠️ Warning ⚠️\n\nTidak boleh ada yang mengirim link grup.", 
        contextInfo: { mentionedJid: mems } 
      }, { quoted: m });

    } else if (set === "off") {
      if (!ntlinkch.includes(m.chat)) return reply("⚠️ Antilinkch belum aktif di grup ini.");
      let index = ntlinkch.indexOf(m.chat);
      ntlinkch.splice(index, 1);
      fs.writeFileSync('./database/antilinkch.json', JSON.stringify(ntlinkch));
      reply("❎ Fitur antilinkch telah dinonaktifkan.");

    } else {
      reply(
      `❌ Pilihan tidak valid.\nGunakan:\n${prefix}antilinkch on\n${prefix}antilinkch off`
    );
        }

  } catch (err) {
    console.error(err);
    reply(`❌ Terjadi kesalahan!\n*Error:* ${err.message}`);
  }
};

handler.command = ["antilinkch"];
handler.group = true
handler.premium = false
handler.limit = false
handler.admin = true
handler.creator = false
handler.botAdmin = true
handler.privates = false
handler.usePrefix = true

export default handler;