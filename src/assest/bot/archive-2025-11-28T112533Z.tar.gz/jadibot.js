// SETTINGS
import "./settings.js";
import { participantsUpdate } from "./lib/participantsUpdate.js";
import { imageToWebp, videoToWebp, writeExifImg, writeExifVid, addExif } from './lib/exif.js';
import {
  tanggal,
  day,
  bulan,
  tahun,
  weton,
  smsg,
  isUrl,
  generateMessageTag,
  getBuffer,
  getSizeMedia,
  fetchJson,
  sleep,
  runtime,
  formatp
} from './lib/myfunc.js';
import makeInMemoryStore from './lib/make-in-memory-store.js';
import makeWASocket, { 
  useMultiFileAuthState,
  fetchLatestBaileysVersion,
  DisconnectReason,
  delay,
  Browsers,
  makeCacheableSignalKeyStore,
  jidDecode,
  downloadContentFromMessage,
  proto,
  generateMessageID,
  generateWAMessageFromContent,
  prepareWAMessageMedia
} from '@ryuu-reinzz/baileys';
import { useSQLiteAuthState } from "./lib/sqliteAuth.js";

import { modul } from './module.js';
import os from 'os';
import { execSync } from 'child_process';
import moment from "moment-timezone";

import { color, bgcolor } from './lib/color.js';
import { uncache, nocache } from './lib/loader.js';
import { handleIncomingMessage } from './lib/user.js';

import fs from 'fs';
import fetch from "node-fetch";
import path from 'path';
import pino from 'pino';
import readline from "readline";
import yargs from 'yargs/yargs';
import _ from 'lodash';
import NodeCache from "node-cache";
import { mainHandler } from "./handler.js";
import extendSocketBotz from "./lib/socket.js";
const { baileys, boom, chalk, FileType, PhoneNumber, axios } = modul;
const { Boom } = boom;

// DATABASE
let db = JSON.parse(fs.readFileSync('./database/welcome.json', 'utf-8'));
let low;
try { low = await import('lowdb'); } catch { low = await import('./lib/lowdb/index.js'); }
const { Low, JSONFile } = low;
const mongoDB = await import('./lib/mongoDB.js');
global.stopJadiBot = {};

// IN MEMORY STORE

let store;
store = makeInMemoryStore({ 
    logger: pino().child({ 
    level: 'silent',
    stream: 'store'
   }) 
  });
store.contacts = store.state.contacts;

const customCode = global.codePair;
// ======================
// FUNCTION START BOT
// ======================
global.stopJadiBot = global.stopJadiBot || {};
global.jadibotStopFlag = global.jadibotStopFlag || {};
global.Client = global.Client || {};

// ====================================
// START JADIBOT
// ====================================
export async function startJadiBot(numberBotz) {
  global.stopJadiBot[numberBotz] = false;
  global.jadibotStopFlag[numberBotz] = false;

  const shouldStop = () => !!global.stopJadiBot[numberBotz];

  if (shouldStop()) return;

  if (!fs.existsSync(`./database/jadibot/${numberBotz}`)) {
    fs.mkdirSync(`./database/jadibot/${numberBotz}`, { recursive: true });
  }
  console.log(`
${chalk.cyan.bold(">> GENERATING SESSION")}
${chalk.gray("────────────────────────────────────────────")}
${chalk.white("• For Number :")} ${chalk.yellow(numberBotz)}
${chalk.gray("────────────────────────────────────────────")}
${chalk.cyan.bold(">> PLEASE WAIT…")}
`);

  if (shouldStop()) return;

  const { saveCreds, state } = await useSQLiteAuthState(`./database/jadibot/${numberBotz}/auth.db`);
  const msgRetryCounterCache = new NodeCache();

  if (shouldStop()) return;

  const jadibotz = makeWASocket({
    logger: pino({
      level: "silent"
    }),
    printQRInTerminal: false,
    browser: Browsers.macOS("Safari"),
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(state.keys, pino({ level: "silent" })),
    },
    markOnlineOnConnect: false,
    generateHighQualityLinkPreview: false,
    getMessage: async (key) => {
      let jid = jidNormalizedUser(key.remoteJid);
      let msg = await store.loadMessage(jid, key.id);
      return msg?.message || "";
    },
    msgRetryCounterCache,
  });

  global.Client[numberBotz] = jadibotz;

  extendSocketBotz(jadibotz, store, smsg);
  try {
    if (store?.bind) store.bind(jadibotz.ev);
  } catch (e) {
  }

  jadibotz.ev.on("creds.update", saveCreds);

  if (!jadibotz.authState.creds.registered) {
    if (shouldStop()) return;

    console.log(chalk.magenta(`
┌──────────────────────────────┐
│      Making pairing code...   │
└──────────────────────────────┘
`));

    const number = numberBotz;
    const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
    await delay(6000);

    if (shouldStop()) return;

    const code = await jadibotz.requestPairingCode(number, customCode);
    if (shouldStop()) return;

    const dir = `./database/jadibot/${number}`;
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    const filePath = path.join(dir, `code-${number}.json`);
    fs.writeFileSync(
      filePath,
      JSON.stringify(
        {
          code,
          self: false
        },
        null,
        2
      )
    );

    console.log(`

${chalk.cyan.bold(">> ESTABLISHING SECURE LINK WITH BOT INSTANCE")}
${chalk.gray("──────────────────────────────────────────────")}

${chalk.green("⚡ CONNECTION CHANNEL")}
${chalk.white("• Target Number :")} ${chalk.yellow(number)}
${chalk.white("• Pairing Code  :")} ${chalk.yellow(code)}
${chalk.white("• Status        :")} ${chalk.green("Connecting to WhatsApp network...")}

${chalk.gray("──────────────────────────────────────────────")}
${chalk.cyan.bold(">> HANDSHAKE IN PROGRESS…")}
${chalk.gray(">> Awaiting device confirmation...")}
`);
  }

  // ======================
  // CONNECTION UPDATE
  // ======================
  jadibotz.ev.on('connection.update', async (update) => {
    if (shouldStop() || global.jadibotStopFlag[numberBotz]) {
      console.log(`[${numberBotz}] Bot is stopped — ignoring connection updates.`);
      return;
    }

    try {
      const { connection, lastDisconnect } = update;

      // ===== CONNECTION CLOSED =====
      if (connection === 'close') {
        const reason = new Boom(lastDisconnect?.error)?.output?.statusCode;
        console.log("Connection closed:", reason);

        if (shouldStop() || global.jadibotStopFlag[numberBotz]) {
          console.log("Bot stopped intentionally → no reconnect.");
          return;
        }

        switch (reason) {
          case DisconnectReason.badSession:
            console.log("Bad session file → delete and restart.");
            startJadiBot(numberBotz);
            break;

          case DisconnectReason.connectionClosed:
            console.log("Connection closed → reconnecting...");
            startJadiBot(numberBotz);
            break;

          case DisconnectReason.connectionLost:
            console.log("Connection lost → reconnecting...");
            startJadiBot(numberBotz);
            break;

          case DisconnectReason.connectionReplaced:
            console.log("Connection replaced → exiting current session.");
            process.exit(0);
            break;

          case DisconnectReason.loggedOut:
            console.log("Logged out → deleting session and restarting.");
            try { fs.unlinkSync(`./database/jadibot/${numberBotz}/auth.db`); } catch(e) {}
            startJadiBot(numberBotz);
            break;

          case DisconnectReason.restartRequired:
            console.log("Restart required → restarting...");
            startJadiBot(numberBotz);
            break;

          case DisconnectReason.timedOut:
            console.log("Timeout → reconnecting...");
            startJadiBot(numberBotz);
            break;

          default:
            console.log("Unknown reason:", reason);
            startJadiBot(numberBotz);
        }

        return;
      }

      // ===== CONNECTING =====
      if (connection === "connecting" || update.receivedPendingNotifications === "false") {
        console.log(`

${chalk.cyan.bold(">> INITIALIZING NETWORK LINK")}
${chalk.gray("────────────────────────────────────────────")}
${chalk.green("⚡ WHATSAPP CONNECTION")}
${chalk.white("• Status :")} ${chalk.yellow("Establishing secure channel…")}
${chalk.white("• Event  :")} ${chalk.gray("Handshake request sent")}
${chalk.gray("────────────────────────────────────────────")}
${chalk.cyan.bold(">> WAITING FOR REMOTE SERVER RESPONSE…")}
`);
      }

      // ===== CONNECTED =====
      if (connection === "open" || update.receivedPendingNotifications === "true") {
        console.log(`

${chalk.green.bold(">> CONNECTION ONLINE — LINK SECURED")}
${chalk.gray("────────────────────────────────────────────")}
${chalk.green("⚡ WHATSAPP CONNECTION")}
${chalk.white("• Status :")} ${chalk.green("Connected successfully")}
${chalk.white("• Event  :")} ${chalk.gray("All channels authenticated")}
${chalk.gray("────────────────────────────────────────────")}
${chalk.green.bold(">> SYSTEM READY. STARTING BOT OPERATIONS…")}
`);
      }

    } catch (e) {
      console.log("Error in connection.update:", e);

      if (!shouldStop() && !global.jadibotStopFlag[numberBotz]) {
        console.log("Recovering from error…");
        setTimeout(() => {
          if (!shouldStop()) startJadiBot(numberBotz);
        }, 1000);
      } else {
        console.log("Error ignored because bot is stopped intentionally.");
      }
    }
  });

  // ======================
  // MESSAGES >
  // ======================
  jadibotz.ev.on("messages.upsert", async (chatUpdate) => {
    if (shouldStop()) return;

    if (typeof chatUpdate.requestId === "string" && chatUpdate.requestId.length > 0) return;
    try {
      const kay = chatUpdate.messages[0];
      if (!kay?.message) return;
      kay.message = Object.keys(kay.message)[0] === "ephemeralMessage" ? kay.message.ephemeralMessage.message : kay.message;

      const m = smsg(jadibotz, kay, store);
      const isLogs = false;
      if (shouldStop()) return;

    if (m.quoted) {
      if (m.isGroup) {
       if (m.quoted.sender !== global.botNumber + "@s.whatsapp.net") {
          m.quoted.sender = (await jadibotz.getPNFromLid(m.chat, m.quoted.sender));
  }
} else {
      m.quoted.sender = m.quoted.sender
   }
 }
      if (!m.fromMe) {
        if (m.isGroup) {
          if (m.sender !== global.botNumber + "@s.whatsapp.net") {
            m.sender = (await jadibotz.getPNFromLid(m.chat, m.sender));
          }
        } else {
          m.sender = m.key.remoteJidAlt;
        }
      }
      if (m.key.remoteJid?.endsWith('@newsletter')) return;
      if (kay.key.id.startsWith("AE59") && kay.key.id.length === 16) return;

      if (!m.key.fromMe && m.key.remoteJid.endsWith("@s.whatsapp.net") && m.text) {
        handleIncomingMessage(jadibotz, m.key.remoteJid);
      }
      mainHandler(jadibotz, m, chatUpdate, store, isLogs);
    } catch (err) {
      console.error("Error processing message:", err);
      try {
          let msg = `Error processing message: ${err}`;
          jadibotz.sendMessage(global.owmernumber + "@s.whatsapp.net", { text: String(err) });
      } catch {}
    }
  });

  // ======================
  // GROUP PARTICIPANTS
  // ======================
  jadibotz.ev.on("group-participants.update", async (anuid) => {
    if (shouldStop()) return;

    if (!anuid?.id || !anuid?.participants || !anuid?.action) {
      return console.log("anu invalid:", anuid);
    }

    try {
      const timestamp = Date.now();
      const dirPath = path.join("database", "tmp");
      if (!fs.existsSync(dirPath)) fs.mkdirSync(dirPath, { recursive: true });
      const filePath = path.join(dirPath, `grupInfo_${timestamp}.json`);
      fs.writeFileSync(filePath, JSON.stringify(anuid, null, 2));
      await global.sleep(2000);

      const grupData = fs.readFileSync(filePath, "utf8");
      const jsonDataGrup = JSON.parse(grupData);
      const { id, participants, action } = jsonDataGrup;

      if (shouldStop()) {
        try { fs.unlinkSync(filePath); } catch(e) {}
        return;
      }

      await participantsUpdate(jadibotz, id, action, participants, db);
      fs.unlinkSync(filePath);
    } catch (err) {
      console.error("Gagal baca file:", err);
    };
  });

  // ======================
  // CONTACTS UPDATE 
  // ======================
  jadibotz.ev.on("contacts.update", (update) => {
    if (shouldStop()) return;
    for (let contact of update) {
      let id = jadibotz.decodeJid(contact.id);
      if (store && store.contacts)
        store.contacts[id] = {
          id,
          name: contact.notify,
        };
    }
  });

  // ### End of sending message ###

  const pairPath = `./database/jadibot/${numberBotz}/code-${numberBotz}.json`;
  const codePairs = fs.existsSync(pairPath)
    ? JSON.parse(fs.readFileSync(pairPath)).code
    : null;

  return codePairs;
}

// =======================================
// STOP JADIBOT
// =======================================
export async function stopJadiBot(numberBotz) {
  try {
    global.stopJadiBot[numberBotz] = true;
    global.jadibotStopFlag[numberBotz] = true;

    console.log("Stopping bot:", numberBotz);

    const jadibotz = global.Client?.[numberBotz];
    if (jadibotz) {
      try {
        if (jadibotz.ev && jadibotz.ev.removeAllListeners) jadibotz.ev.removeAllListeners();
      } catch (e) {}

      try {
        if (jadibotz?.ws && jadibotz.ws.close) jadibotz.ws.close();
      } catch (e) {}

      try {
        if (typeof jadibotz.end === "function") await jadibotz.end();
      } catch (e) {}

      try {
        if (store?.bind && typeof store.bind === "function") store.bind = () => {};
      } catch (e) {}

      try { delete global.Client[numberBotz]; } catch (e) {}
    } else {
      console.log("No active client found for:", numberBotz);
    }

    console.log("Bot stopped:", numberBotz);
  } catch (e) {
    console.error("Error stopping bot:", e);
  }
}