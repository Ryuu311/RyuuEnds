// SETTINGS
import "./settings.js";
import { participantsUpdate } from "./lib/participantsUpdate.js";
import { imageToWebp, videoToWebp, writeExifImg, writeExifVid, addExif, generateMyFuncFile } from './lib/exif.js';
import {
  tanggal,
  day,
  bulan,
  tahun,
  weton,
  smsg,
  isUrl,
  generateMessageTag,
  getBuffer,
  getSizeMedia,
  fetchJson,
  sleep,
  runtime,
  formatp,
  whitelistChecking,
  checkTheNumber
} from './lib/myfunc.js';
import makeInMemoryStore from './lib/make-in-memory-store.js';
import makeWASocket, { 
  useMultiFileAuthState,
  fetchLatestBaileysVersion,
  DisconnectReason,
  delay,
  Browsers,
  makeCacheableSignalKeyStore,
  jidDecode,
  downloadContentFromMessage,
  proto,
  generateMessageID,
  generateWAMessageFromContent,
  prepareWAMessageMedia
} from '@ryuu-reinzz/baileys';
import { useSQLiteAuthState } from "./lib/sqliteAuth.js";

import { modul } from './module.js';
import os from 'os';
import { execSync } from 'child_process';
import moment from "moment-timezone";

import { color, bgcolor } from './lib/color.js';
import { uncache, nocache } from './lib/loader.js';
import { handleIncomingMessage } from './lib/user.js';

import fs from 'fs';
import fetch from "node-fetch";
import path from 'path';
import pino from 'pino';
import Pino from 'pino';
import readline from "readline";
import yargs from 'yargs/yargs';
import _ from 'lodash';
import NodeCache from "node-cache";
import { mainHandler } from "./handler.js";
const { baileys, boom, chalk, FileType, PhoneNumber, axios } = modul;
import extendSocketBotz from "./lib/socket.js";
import { startJadiBot } from './jadibot.js';
const { Boom } = boom;

// DATABASE
let db = JSON.parse(fs.readFileSync('./database/welcome.json', 'utf-8'));
let low;
try { low = await import('lowdb'); } catch { low = await import('./lib/lowdb/index.js'); }
const { Low, JSONFile } = low;
const mongoDB = await import('./lib/mongoDB.js');

// IN MEMORY STORE
let store;
store = makeInMemoryStore({ 
    logger: pino().child({ 
    level: 'silent',
    stream: 'store'
   }) 
  });
store.contacts = store.state.contacts;

// GLOBAL OPTS
global.opts = yargs(process.argv.slice(2)).exitProcess(false).parse();
global.db = new Low(
  /https?:\/\//.test(opts['db'] || '')
    ? new cloudDBAdapter(opts['db'])
    : /mongodb/.test(opts['db'] || '')
      ? new mongoDB(opts['db'])
      : new JSONFile(`./database/database.json`)
);
global.DATABASE = global.db;
global.loadDatabase = async function() {
  if (global.db.READ) return new Promise((resolve) => {
    const interval = setInterval(() => {
      if (!global.db.READ) { clearInterval(interval); resolve(global.db.data ?? global.loadDatabase()); }
    }, 1000);
  });
  if (global.db.data !== null) return;
  global.db.READ = true;
  await global.db.read();
  global.db.READ = false;
  global.db.data = {
    users: {}, chats: {}, game: {}, database: {}, settings: {}, setting: {}, others: {}, sticker: {},
    ...(global.db.data || {})
  };
  global.db.chain = _.chain(global.db.data);
};
await global.loadDatabase();
await checkTheNumber('./lib/myfunc.js');

// UTILS
const more = String.fromCharCode(8206);
const readmore = more.repeat(4001);
const prefix = "";
const type = (x) => x?.constructor?.name ?? (x === null ? "null" : "undefined");
const isStringSame = (x, y) => Array.isArray(y) ? y.includes(x) : y === x;
const buttonTypes = [];
const customCode = global.codePair;

let phoneNumber = `${nomorbot}`;
const pairingCode = false;

// ======================
// FUNCTION START BOT
// ======================
async function loadAllJadiBot(startJadiBot) {
  const basePath = "./database/jadibot";
  if (!fs.existsSync(basePath)) return;

  const folders = fs.readdirSync(basePath).filter((name) => {
    const fullPath = path.join(basePath, name);
    return fs.statSync(fullPath).isDirectory() && /^\d+$/.test(name);
  });

  for (const nomor of folders) {
    console.log(`Menjalankan jadibot untuk ${nomor}...`);
    await startJadiBot(nomor);    
    await global.sleep(500);
    console.clear();
    await global.sleep(1000);
  }
}
export async function startsesi() {
await loadAllJadiBot(startJadiBot);      
await global.sleep(5000);
await whitelistChecking({ fs, fetch, chalk });
const pluginsDir = path.resolve('./plugins');
    let loadedPlugins = [];
    const npmVersion = execSync("npm -v").toString().trim();
    const output = execSync('df -h /').toString().split('\n')[1].split(/\s+/);
    const totals = output[1];
    const useds = output[2];
    const availables = output[3];
    const percents = output[4];
    const infoBot = path.join("package.json");
    const botData = fs.readFileSync(infoBot, "utf8");
    const rootPackage = JSON.parse(botData);
    const infoBails = path.join("node_modules", "@ryuu-reinzz", "baileys", "package.json");
    const bailsData = fs.readFileSync(infoBails, "utf8");
    const baileysPackage = JSON.parse(bailsData);

    try {
     const files = fs.readdirSync(pluginsDir);
      loadedPlugins = files.filter(f => f.endsWith('.js'));
    } catch (err) {
      loadedPlugins = [];
    }
    console.log(`
${chalk.cyan.bold(">> [CORE SYSTEM] — BOT STATUS MONITORING")}
${chalk.gray("──────────────────────────────────────────────────────────")}

${chalk.green("⚡ SYSTEM METRICS")}
${chalk.white("• RAM Usage       :")} ${chalk.yellow(formatp(os.totalmem() - os.freemem()))} ${chalk.gray("/")} ${chalk.yellow(formatp(os.totalmem()))}
${chalk.white("• Disk Usage      :")} ${chalk.yellow(useds + "B")} ${chalk.gray("/")} ${chalk.yellow(totals + "B")} ${chalk.gray("(" + percents + ")")}
${chalk.white("• Disk Free       :")} ${chalk.yellow(availables + "B")}

${chalk.green("⚡ BOT CORE INFORMATION")}
${chalk.white("• Name            :")} ${chalk.magenta(rootPackage.name)}
${chalk.white("• Version         :")} ${chalk.magenta(rootPackage.version)}
${chalk.white("• Node.js         :")} ${chalk.magenta(process.version)}
${chalk.white("• NPM             :")} ${chalk.magenta(npmVersion)}
${chalk.white("• Plugins Loaded  :")} ${chalk.yellow(loadedPlugins.length)}

${chalk.blueBright("⚡ MODULE DETAILS — BAILEYS ENGINE")}
${chalk.white("• Name            :")} ${chalk.magenta(baileysPackage.name)}
${chalk.white("• Version         :")} ${chalk.magenta(baileysPackage.version)}

${chalk.gray("──────────────────────────────────────────────────────────")}
${chalk.cyan.bold(">> SYSTEM ONLINE — READY FOR OPERATION")}
`);

  const { saveCreds, state } = await useSQLiteAuthState(`./session/auth.db`);
  const msgRetryCounterCache = new NodeCache();

  const RyuuBotz = makeWASocket({
        logger: pino({
            level: "silent"
    }),
    printQRInTerminal: false,
    browser: Browsers.macOS("Safari"),
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(state.keys, Pino({ level: "silent" })),
    },
    markOnlineOnConnect: false,
    generateHighQualityLinkPreview: false,
    getMessage: async (key) => {
      let jid = jidNormalizedUser(key.remoteJid);
      let msg = await store.loadMessage(jid, key.id);
      return msg?.message || "";
    },
    msgRetryCounterCache,
  });
  extendSocketBotz(RyuuBotz, store, smsg);
  global.Client[nomorbot] = RyuuBotz;  
  store?.bind(RyuuBotz.ev);
  
  RyuuBotz.ev.on("creds.update", saveCreds);
  if (!RyuuBotz.authState.creds.registered) {
    console.log(chalk.magenta(`
┌──────────────────────────────┐
│     Making pairing code...   │
└──────────────────────────────┘
`));
    const number = phoneNumber;
    const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
    await delay(6000);
    const code = await RyuuBotz.requestPairingCode(number, customCode);
    console.log(`
${chalk.cyan.bold(">> [NETWORK MODULE] — CONNECTION INITIATED")}
${chalk.gray("──────────────────────────────────────────────")}

${chalk.green("⚡ BOT CONNECTION DETAILS")}
${chalk.white("• Target Number :")} ${chalk.yellow(number)}
${chalk.white("• Pairing Code  :")} ${chalk.yellow(code)}
${chalk.white("• Status        :")} ${chalk.green("Establishing secure channel…")}

${chalk.gray("──────────────────────────────────────────────")}
${chalk.cyan.bold(">> HANDSHAKE IN PROGRESS — AWAITING RESPONSE…")}
`);
  }

  // ======================
  // CONNECTION UPDATE
  // ======================
  RyuuBotz.ev.on('connection.update', async (update) => {


    const { connection, lastDisconnect } = update;
    try {
      if (connection === 'close') {
			let reason = new Boom(lastDisconnect?.error)?.output.statusCode
			if (reason === DisconnectReason.badSession) {
				console.log(`Bad Session File, Please Delete Session and Connect Again`);
				startsesi();
			} else if (reason === DisconnectReason.connectionClosed) {
				console.log("Connection closed, reconnecting....");
				startsesi();
			} else if (reason === DisconnectReason.connectionLost) {
				console.log("Connection Lost from Server, reconnecting...");
				startsesi();
			} else if (reason === DisconnectReason.connectionReplaced) {
				console.log("Connection Replaced, Another New Session Opened, Please Close Current Session First");
				process.exit(0);
				startsesi()
			} else if (reason === DisconnectReason.loggedOut) {
				console.log(`Device Logged Out, Please Connect Again And Run.`);
				fs.unlinkSync("./session/creds.json");
				startsesi();
			} else if (reason === DisconnectReason.restartRequired) {
				console.log("Restart Required, Restarting...");
				startsesi();
			} else if (reason === DisconnectReason.timedOut) {
				console.log("Connection TimedOut, Reconnecting...");
				startsesi();
			} else {
			  console.log(`Unknown DisconnectReason: ${reason}|${connection}`)
			  process.exit(0);
			  startsesi();
			}
		}
   
   if (update.connection === "connecting" || update.receivedPendingNotifications == "false") {
  console.log(`
${chalk.cyan.bold(">> [NETWORK MODULE] — ESTABLISHING CONNECTION")}
${chalk.gray("────────────────────────────────────────────")}

${chalk.green("⚡ WHATSAPP LINK STATUS")}
${chalk.white("• Connection :")} ${chalk.yellow("Initializing secure channel…")}
${chalk.white("• Event      :")} ${chalk.gray("Handshake request sent, awaiting response")}

${chalk.gray("────────────────────────────────────────────")}
${chalk.cyan.bold(">> STATUS : CONNECTING…")}
`);
}

if (update.connection === "open" || update.receivedPendingNotifications == "true") {
  console.log(`
${chalk.green.bold(">> [NETWORK MODULE] — CONNECTION ONLINE")}
${chalk.gray("────────────────────────────────────────────")}

${chalk.green("⚡ WHATSAPP LINK STATUS")}
${chalk.white("• Connection :")} ${chalk.green("Successfully connected! 🎉")}
${chalk.white("• Event      :")} ${chalk.gray("All channels authenticated")}

${chalk.gray("────────────────────────────────────────────")}
${chalk.green.bold(">> SYSTEM READY — BOT OPERATIONS ACTIVE")}
`);
}
 } catch (e) { console.log('Error in connection.update', e); startsesi(); }
  });

  // ======================
  // MESSAGES >
  // ======================
  RyuuBotz.ev.on("messages.upsert", async (chatUpdate) => {
  if (typeof chatUpdate.requestId === "string" && chatUpdate.requestId.length > 0) return;
    try {
      const kay = chatUpdate.messages[0];
      if (!kay.message) return;
      kay.message = Object.keys(kay.message)[0] === "ephemeralMessage"
        ? kay.message.ephemeralMessage.message
        : kay.message;

      const m = smsg(RyuuBotz, kay, store);
     if (m.quoted) {
      if (m.isGroup) {
       if (m.quoted.sender !== global.botNumber + "@s.whatsapp.net") {
          m.quoted.sender = (await RyuuBotz.getPNFromLid(m.chat, m.quoted.sender));
  }
} else {
      m.quoted.sender = m.quoted.sender
   }
 }
     if (!m.fromMe) {
      if (m.isGroup) {
       if (m.sender !== global.botNumber + "@s.whatsapp.net") {
          m.sender = (await RyuuBotz.getPNFromLid(m.chat, m.sender));
  }
} else {
      m.sender = m.key.remoteJidAlt
   }
 }
      const isLogs = true;
      if (m.key.remoteJid?.endsWith('@newsletter')) return;
      if (kay.key.id.startsWith("AE59") && kay.key.id.length === 16) return;

      if (!m.key.fromMe && m.key.remoteJid.endsWith("@s.whatsapp.net") && m.text) {
        handleIncomingMessage(RyuuBotz, m.key.remoteJid);
      }
       mainHandler(RyuuBotz, m, chatUpdate, store, isLogs);
    } catch(err) {
      console.error("Error processing message:", err);
        let msg = `Error processing message: ${err}`
      RyuuBotz.sendMessage(global.owmernumber + "@s.whatsapp.net", { text: msg });
    }
  });

  // ======================
  // GROUP PARTICIPANTS
  // ======================
    RyuuBotz.ev.on("group-participants.update", async (anuid) => {
  if (!anuid.id || !anuid.participants || !anuid.action) {
    return console.log("anu invalid:", anuid);
  }
  try {
  console.log(anuid);
  const timestamp = Date.now();
  const dirPath = path.join("database", "tmp");
  const filePath = path.join(dirPath, `grupInfo_${timestamp}.json`);

  if (!fs.existsSync(dirPath)) {
    fs.mkdirSync(dirPath, { recursive: true });
  }
  fs.writeFileSync(filePath, JSON.stringify(anuid, null, 2));
  await global.sleep(2000);

  const filename = `grupInfo_${timestamp}.json`;
  const FilePath = path.join("database", "tmp", filename);
  const grupData = fs.readFileSync(FilePath, "utf8");
  const jsonDataGrup = JSON.parse(grupData);
  const { id, participants, action } = jsonDataGrup;
  

  await participantsUpdate(RyuuBotz, id, action, participants, db);
  fs.unlinkSync(filePath)
  ;
  } catch (err) {
  console.error("Gagal baca file:", err);
};
});
  // ======================
  // CONTACTS UPDATE
  // ======================
  RyuuBotz.ev.on("contacts.update", (update) => {
    for (let contact of update) {
      let id = RyuuBotz.decodeJid(contact.id);
      if (store && store.contacts)
        store.contacts[id] = {
          id,
          name: contact.notify,
        };
    }
  });  
    // ### End of sending message ###
  return RyuuBotz;
}

// START BOT
startsesi();

// ======================
// AUTO WATCH FILE
// ======================
const file = new URL(import.meta.url).pathname;

fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.log(chalk.redBright(`Update ${file}`));
  import(`${import.meta.url}?update=${Date.now()}`);
});