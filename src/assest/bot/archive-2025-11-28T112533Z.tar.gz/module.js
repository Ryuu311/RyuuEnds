import axios from 'axios';
import * as baileys from '@ryuu-reinzz/baileys';
import Boom from '@hapi/boom';
import chalk from 'chalk';
import cheerio from 'cheerio';
import fs from 'fs';
import keyeddb from '@ryuu-reinzz/baileys';
import moment from 'moment-timezone';
import path from 'path';
import FileType from 'file-type';
import pino from 'pino';
import process from 'process';
import PhoneNumber from 'awesome-phonenumber';
import util from 'util';
import * as Utils from '@ryuu-reinzz/baileys/lib/Utils/index.js';
import speed from 'performance-now';

export const modul = {
  axios,
  baileys,
  boom: Boom,
  chalk,
  cheerio,
  fs,
  keyeddb,
  moment,
  path,
  FileType,
  pino,
  process,
  PhoneNumber,
  util,
  Utils,
  speed
};