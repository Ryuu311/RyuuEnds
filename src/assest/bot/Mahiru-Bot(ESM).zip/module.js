import axios from 'axios';
import * as baileys from '@whiskeysockets/baileys';
import Boom from '@hapi/boom';
import chalk from 'chalk';
import cheerio from 'cheerio';
import fs from 'fs';
import fsx from 'fs-extra';
import keyeddb from '@whiskeysockets/baileys';
import moment from 'moment-timezone';
import path from 'path';
import FileType from 'file-type';
import pino from 'pino';
import process from 'process';
import parseMs from 'parse-ms';
import PhoneNumber from 'awesome-phonenumber';
import util from 'util';
import * as Utils from '@whiskeysockets/baileys/lib/Utils/index.js';
import speed from 'performance-now';

export const modul = {
  axios,
  baileys,
  boom: Boom,
  chalk,
  cheerio,
  fs,
  fsx,
  keyeddb,
  moment,
  path,
  FileType,
  pino,
  process,
  parsems: parseMs,
  PhoneNumber,
  util,
  Utils,
  speed
};