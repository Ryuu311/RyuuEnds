// SETTINGS
import "./settings.js";
import pkg from '@whiskeysockets/baileys';
const { makeWASocket,
  useMultiFileAuthState,
  fetchLatestBaileysVersion,
  DisconnectReason,
  delay,
  Browsers,
  makeCacheableSignalKeyStore,
  jidDecode,
  downloadContentFromMessage
} = pkg

import { modul } from './module.js';
import cfonts from 'cfonts';
import moment from "moment-timezone";
import figlet from "figlet";
import gradient from "gradient-string";

import { makeInMemoryStore } from './lib/store/index.js';
import { tanggal, day, bulan, tahun, weton, smsg, isUrl, generateMessageTag, getBuffer, getSizeMedia, fetchJson, sleep } from './lib/myfunc.js';
import { color, bgcolor } from './lib/color.js';
import { uncache, nocache } from './lib/loader.js';
import { handleIncomingMessage } from './lib/user.js';
import { imageToWebp, videoToWebp, writeExifImg, writeExifVid, addExif } from './lib/exif.js';

import fs from 'fs';
import path from 'path';
import pino from 'pino';
import Pino from 'pino';
import readline from "readline";
import yargs from 'yargs/yargs';
import _ from 'lodash';
import NodeCache from "node-cache";
import caseHandler from "./case.js";
const { baileys, boom, chalk, FileType, PhoneNumber, axios } = modul;
const { Boom } = boom;

// DATABASE
let db = JSON.parse(fs.readFileSync('./database/welcome.json', 'utf-8'));

let low;
try { low = await import('lowdb'); } catch { low = await import('./lib/lowdb/index.js'); }
const { Low, JSONFile } = low;
const mongoDB = await import('./lib/mongoDB.js');

// IN MEMORY STORE
const store = makeInMemoryStore({
  logger: pino().child({ level: "silent", stream: "store" }),
});

// GLOBAL OPTS
global.opts = yargs(process.argv.slice(2)).exitProcess(false).parse();
global.db = new Low(
  /https?:\/\//.test(opts['db'] || '')
    ? new cloudDBAdapter(opts['db'])
    : /mongodb/.test(opts['db'] || '')
      ? new mongoDB(opts['db'])
      : new JSONFile(`./database/database.json`)
);
global.DATABASE = global.db;
global.loadDatabase = async function() {
  if (global.db.READ) return new Promise((resolve) => {
    const interval = setInterval(() => {
      if (!global.db.READ) { clearInterval(interval); resolve(global.db.data ?? global.loadDatabase()); }
    }, 1000);
  });
  if (global.db.data !== null) return;
  global.db.READ = true;
  await global.db.read();
  global.db.READ = false;
  global.db.data = {
    users: {}, chats: {}, game: {}, database: {}, settings: {}, setting: {}, others: {}, sticker: {},
    ...(global.db.data || {})
  };
  global.db.chain = _.chain(global.db.data);
};
await global.loadDatabase();

// UTILS
const more = String.fromCharCode(8206);
const readmore = more.repeat(4001);
const prefix = "";
const type = (x) => x?.constructor?.name ?? (x === null ? "null" : "undefined");
const isStringSame = (x, y) => Array.isArray(y) ? y.includes(x) : y === x;
const buttonTypes = [];
const customCode = 'RYUUHIRU';

let phoneNumber = `${nomorbot}`;
const pairingCode = false;
const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const question = (text) => new Promise(resolve => {
  const rli = readline.createInterface({ input: process.stdin, output: process.stdout });
  rli.question(text, resolve);
});

// ======================
// FUNCTION START BOT
// ======================
export async function startsesi() {
  const { saveCreds, state } = await useMultiFileAuthState(`./session`);
  const msgRetryCounterCache = new NodeCache();

  const syncKeys = async () => {
    try { await saveCreds(state.creds); } 
    catch (err) { console.error("Key synchronization failed:", err); }
  };

  const RyuuBotz = makeWASocket({
        logger: pino({
            level: "silent"
    }),
    printQRInTerminal: false,
    browser: Browsers.macOS("Safari"),
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(state.keys, Pino({ level: "silent" })),
    },
    markOnlineOnConnect: false,
    generateHighQualityLinkPreview: false,
    getMessage: async (key) => {
      let jid = jidNormalizedUser(key.remoteJid);
      let msg = await store.loadMessage(jid, key.id);
      return msg?.message || "";
    },
    msgRetryCounterCache,
  });

  global.Client = RyuuBotz;
  syncKeys();
  store?.bind(RyuuBotz.ev);
  
  RyuuBotz.ev.on("creds.update", saveCreds);
  if (!RyuuBotz.authState.creds.registered) {
  /*await delay(5000);*/
    console.log("Making pairing code.....");
    const number = phoneNumber;
    const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
    await delay(6000);
    const code = await RyuuBotz.requestPairingCode(number, customCode);
    console.log(
      chalk.black(chalk.bgGreen(`Your Pairing : `)),
      chalk.black(chalk.white(code)),
    );
  }

  // ======================
  // CONNECTION UPDATE
  // ======================
  RyuuBotz.ev.on('connection.update', async (update) => {
    const { connection, lastDisconnect } = update;
    try {
      if (connection === 'close') {
        let reason = new Boom(lastDisconnect?.error)?.output.statusCode;
        switch(reason) {
          case DisconnectReason.badSession: console.log("Bad Session, delete session & reconnect"); startsesi(); break;
          case DisconnectReason.connectionClosed: console.log("Connection closed, reconnecting"); startsesi(); break;
          case DisconnectReason.connectionLost: console.log("Connection lost, reconnecting"); startsesi(); break;
          case DisconnectReason.connectionReplaced: console.log("Connection replaced, close current session"); startsesi(); break;
          case DisconnectReason.loggedOut: console.log("Logged out, reconnect"); startsesi(); break;
          case DisconnectReason.restartRequired: console.log("Restart required"); startsesi(); break;
          case DisconnectReason.timedOut: console.log("Connection timed out, reconnecting"); startsesi(); break;
          default: console.log(`Unknown disconnect reason: ${reason}`); startsesi(); break;
        }
      }
      if (connection === "connecting") console.log(color("\nMenyambungkan...", 'blue'));
      if (connection === "open") {
        await delay(1999);
        cfonts.say('MAHIRU', { font: 'block', align: 'left', colors: ['#FFA500', 'redBright'], background: 'transparent', maxLength: 20 });
        console.log(chalk.yellow("Successfully connected to WhatsApp!!!"));
      }
    } catch(e) { console.log('Error in connection.update', e); startsesi(); }
  });

  // ======================
  // MESSAGES UPSERT
  // ======================
  RyuuBotz.ev.on("messages.upsert", async (chatUpdate) => {
    try {
      const kay = chatUpdate.messages[0];
      if (!kay.message) return;
      kay.message = Object.keys(kay.message)[0] === "ephemeralMessage"
        ? kay.message.ephemeralMessage.message
        : kay.message;

      const m = smsg(RyuuBotz, kay, store);
      if (m.key.remoteJid?.endsWith('@newsletter')) return;
      if (kay.key.id.startsWith("BAE5") && kay.key.id.length === 16) return;

      if (!m.key.fromMe && m.key.remoteJid.endsWith("@s.whatsapp.net") && m.text) {
        handleIncomingMessage(RyuuBotz, m.key.remoteJid);
      }
       caseHandler(RyuuBotz, m, chatUpdate, store);
    } catch(err) {
      console.error("Error processing message:", err);
      if (global.channel_log) {
        let msg = `Error processing message: ${err}`;
        RyuuBotz.sendMessage('120363420007790159@newsletter', { text: msg });
      }
    }
  });

  // ======================
  // GROUP PARTICIPANTS
  // ======================
  RyuuBotz.ev.on('group-participants.update', async (anu) => {
  try {
    if (!anu.id || !anu.participants || !anu.action) {
      return console.log("anu invalid:", anu);
    }
    const timestamp = Date.now();
    const dirPath = path.join("database", "tmp");
    const filePath = path.join(dirPath, `grupInfo_${timestamp}.json`);

    if (!fs.existsSync(dirPath)) {
      fs.mkdirSync(dirPath, { recursive: true });
    }
    fs.writeFileSync(filePath, JSON.stringify(anu, null, 2));
    console.log('making tmp....');
    
    let fileData = JSON.parse(fs.readFileSync(filePath, "utf-8"));
  global.sleep(3000);
    let anu_id = fileData.id;
    let anu_participants = fileData.participants;
    let anu_action = fileData.action;
    
    if (!db.groups) db.groups = {};
    if (!db.groups[anu_id]) db.groups[anu_id] = { welcome: false, goodbye: false };
    
    const groupMetadata = await RyuuBotz.groupMetadata(anu_id);
    const groupName = groupMetadata.subject || "Grup ini";   
    for (let num of anu_participants) {
      let userTag = '@' + num.split('@')[0];
      let ppUrl;
      try {
        ppUrl = await RyuuBotz.profilePictureUrl(num, 'image');
      } catch {
        ppUrl = 'https://telegra.ph/file/265c672094dfa87caea19.jpg';
      }
      let bgUrl = global.thumbnail;
      let _nama__ = RyuuBotz.getName(num)
  
      if (anu_action === 'add' && db.groups[anu_id].welcome) {
        console.log('member Update (add)');
        let teks = (db.groups[anu_id].welcomeText || `Selamat datang ${_nama__} di grup ${groupName}!`)
          .replace(/@user/gi, userTag)
          .replace(/@group/gi, groupName);
            
        let text = (`Selamat datang ${_nama__} di grup ${groupName}!`)
  
        let Bufer = `https://api.ryuu-dev.offc.my.id/tools/WelcomeLeave?desc=${encodeURIComponent(text)}&title=Welcome!!&profile=${encodeURIComponent(ppUrl)}&background=${encodeURIComponent(bgUrl)}`;
        const buffer = (await axios.get(Bufer, { responseType: 'arraybuffer' })).data;
  
        await RyuuBotz.sendMessage(anu_id, {
          text: teks,
          mentions: [num],
          contextInfo: {
            externalAdReply: {
              title: `Welcome ${_nama__}!`,
              body: text,
              mediaType: 1,
              previewType: "PHOTO",
              thumbnail: buffer,
              sourceUrl: "https://api.ryuu-dev.offc.my.id",
              renderLargerThumbnail: true
            },
          },
        });
  
      } else if (anu_action === 'remove' && db.groups[anu_id].goodbye) {
        console.log('member Update (remove)');
        let text = (db.groups[anu_id].goodbyeText || `Selamat tinggal ${_nama__}, semoga betah di luar ${groupName} 👋`)
          .replace(/@user/gi, userTag)
          .replace(/@group/gi, groupName);
            
        let teks = (`Selamat tinggal ${_nama__}, semoga betah di luar ${groupName} 👋`)
  
        let Bufer = `https://api.ryuu-dev.offc.my.id/tools/WelcomeLeave?desc=${encodeURIComponent(teks)}&title=Good%20Bye&profile=${encodeURIComponent(ppUrl)}&background=${encodeURIComponent(bgUrl)}`;
        const buffer = (await axios.get(Bufer, { responseType: 'arraybuffer' })).data;
  
        await RyuuBotz.sendMessage(anu_id, {
          text: text,
          mentions: [num],
          contextInfo: {
            externalAdReply: {
              title: `Good bye ${_nama__}!`,
              body: teks,
              mediaType: 1,
              previewType: "PHOTO",
              thumbnail: buffer,
              sourceUrl: "https://api.ryuu-dev.offc.my.id",
              renderLargerThumbnail: true
            },
          },
        });
      }
    }
    fs.unlinkSync(filePath);
    console.log('tmp clear✅');
  } catch (e) {
    console.log(`Welcome/Goodbye error: ${e.message}`);
  }
});

  // ======================
  // MORE FUNCTIONS
  // ======================
  RyuuBotz.sendTextWithMentions = async (jid, text, quoted, options = {}) =>
    RyuuBotz.sendMessage(
      jid,
      {
        text: text,
        contextInfo: {
          mentionedJid: [...text.matchAll(/@(\d{0,16})/g)].map(
            (v) => v[1] + "@s.whatsapp.net",
          ),
        },
        ...options,
      },
      {
        quoted,
      },
    );
  RyuuBotz.decodeJid = (jid) => {
    if (!jid) return jid;
    if (/:\d+@/gi.test(jid)) {
      let decode = jidDecode(jid) || {};
      return (
        (decode.user && decode.server && decode.user + "@" + decode.server) ||
        jid
      );
    } else return jid;
  };
  RyuuBotz.ev.on("contacts.update", (update) => {
    for (let contact of update) {
      let id = RyuuBotz.decodeJid(contact.id);
      if (store && store.contacts)
        store.contacts[id] = {
          id,
          name: contact.notify,
        };
    }
  });
  RyuuBotz.getName = (jid, withoutContact = false) => {
    id = RyuuBotz.decodeJid(jid);
    withoutContact = RyuuBotz.withoutContact || withoutContact;
    let v;
    if (id.endsWith("@g.us"))
      return new Promise(async (resolve) => {
        v = store.contacts[id] || {};
        if (!(v.name || v.subject)) v = RyuuBotz.groupMetadata(id) || {};
        resolve(
          v.name ||
            v.subject ||
            PhoneNumber("+" + id.replace("@s.whatsapp.net", "")).getNumber(
              "international",
            ),
        );
      });
    else
      v =
        id === "0@s.whatsapp.net"
          ? {
              id,
              name: "WhatsApp",
            }
          : id === RyuuBotz.decodeJid(RyuuBotz.user.id)
            ? RyuuBotz.user
            : store.contacts[id] || {};
    return (
      (withoutContact ? "" : v.name) ||
      v.subject ||
      v.verifiedName ||
      PhoneNumber("+" + jid.replace("@s.whatsapp.net", "")).getNumber(
        "international",
      )
    );
  };
  RyuuBotz.parseMention = (text = "") => {
    return [...text.matchAll(/@([0-9]{5,16}|0)/g)].map(
      (v) => v[1] + "@s.whatsapp.net",
    );
  };
  RyuuBotz.sendContact = async (jid, kon, quoted = "", opts = {}) => {
    let list = [];
    for (let i of kon) {
      list.push({
        displayName: await RyuuBotz.getName(i),
        vcard: `BEGIN:VCARD\nVERSION:3.0\nN:${await RyuuBotz.getName(i)}\nFN:${await RyuuBotz.getName(i)}\nitem1.TEL;waid=${i}:${i}\nitem1.X-ABLabel:Click here to chat\nitem2.EMAIL;type=INTERNET:${ytname}\nitem2.X-ABLabel:YouTube\nitem3.URL:${socialm}\nitem3.X-ABLabel:GitHub\nitem4.ADR:;;${location};;;;\nitem4.X-ABLabel:Region\nEND:VCARD`,
      });
    }
    RyuuBotz.sendMessage(
      jid,
      {
        contacts: {
          displayName: `${list.length} Contact`,
          contacts: list,
        },
        ...opts,
      },
      {
        quoted,
      },
    );
  };
  RyuuBotz.setStatus = (status) => {
    RyuuBotz.query({
      tag: "iq",
      attrs: {
        to: "@s.whatsapp.net",
        type: "set",
        xmlns: "status",
      },
      content: [
        {
          tag: "status",
          attrs: {},
          content: Buffer.from(status, "utf-8"),
        },
      ],
    });
    return status;
  };

  RyuuBotz.sendImage = async (jid, path, caption = "", quoted = "", options) => {
    let buffer = Buffer.isBuffer(path)
      ? path
      : /^data:.*?\/.*?;base64,/i.test(path)
        ? Buffer.from(path.split`,`[1], "base64")
        : /^https?:\/\//.test(path)
          ? await await getBuffer(path)
          : fs.existsSync(path)
            ? fs.readFileSync(path)
            : Buffer.alloc(0);
    return await RyuuBotz.sendMessage(
      jid,
      {
        image: buffer,
        caption: caption,
        ...options,
      },
      {
        quoted,
      },
    );
  };
  RyuuBotz.sendImageAsSticker = async (jid, path, quoted, options = {}) => {
    let buff = Buffer.isBuffer(path)
      ? path
      : /^data:.*?\/.*?;base64,/i.test(path)
        ? Buffer.from(path.split`,`[1], "base64")
        : /^https?:\/\//.test(path)
          ? await await getBuffer(path)
          : fs.existsSync(path)
            ? fs.readFileSync(path)
            : Buffer.alloc(0);
    let buffer;
    if (options && (options.packname || options.author)) {
      buffer = await writeExifImg(buff, options);
    } else {
      buffer = await imageToWebp(buff);
    }
    await RyuuBotz.sendMessage(
      jid,
      {
        sticker: {
          url: buffer,
        },
        ...options,
      },
      {
        quoted,
      },
    ).then((response) => {
      fs.unlinkSync(buffer);
      return response;
    });
  };
  RyuuBotz.sendVideoAsSticker = async (jid, path, quoted, options = {}) => {
    let buff = Buffer.isBuffer(path)
      ? path
      : /^data:.*?\/.*?;base64,/i.test(path)
        ? Buffer.from(path.split`,`[1], "base64")
        : /^https?:\/\//.test(path)
          ? await await getBuffer(path)
          : fs.existsSync(path)
            ? fs.readFileSync(path)
            : Buffer.alloc(0);
    let buffer;
    if (options && (options.packname || options.author)) {
      buffer = await writeExifVid(buff, options);
    } else {
      buffer = await videoToWebp(buff);
    }
    await RyuuBotz.sendMessage(
      jid,
      {
        sticker: {
          url: buffer,
        },
        ...options,
      },
      {
        quoted,
      },
    );
    return buffer;
  };
  RyuuBotz.sendImageAsStickerAvatar = async (
    jid,
    path,
    quoted,
    options = {},
  ) => {
    let buff = Buffer.isBuffer(path)
      ? path
      : /^data:.*?\/.*?;base64,/i.test(path)
        ? Buffer.from(path.split`,`[1], "base64")
        : /^https?:\/\//.test(path)
          ? await await getBuffer(path)
          : fs.existsSync(path)
            ? fs.readFileSync(path)
            : Buffer.alloc(0);
    let buffer;
    if (options && (options.packname || options.author)) {
      buffer = await writeExifImgAvatar(buff, options);
    } else {
      buffer = await imageToWebpAvatar(buff);
    }
    await RyuuBotz.sendMessage(
      jid,
      {
        sticker: {
          url: buffer,
        },
        ...options,
      },
      {
        quoted,
      },
    ).then((response) => {
      fs.unlinkSync(buffer);
      return response;
    });
  };
  RyuuBotz.sendVideoAsStickerAvatar = async (
    jid,
    path,
    quoted,
    options = {},
  ) => {
    let buff = Buffer.isBuffer(path)
      ? path
      : /^data:.*?\/.*?;base64,/i.test(path)
        ? Buffer.from(path.split`,`[1], "base64")
        : /^https?:\/\//.test(path)
          ? await await getBuffer(path)
          : fs.existsSync(path)
            ? fs.readFileSync(path)
            : Buffer.alloc(0);
    let buffer;
    if (options && (options.packname || options.author)) {
      buffer = await writeExifVidAvatar(buff, options);
    } else {
      buffer = await videoToWebpAvatar(buff);
    }
    await RyuuBotz.sendMessage(
      jid,
      {
        sticker: {
          url: buffer,
        },
        ...options,
      },
      {
        quoted,
      },
    );
    return buffer;
  };
  RyuuBotz.copyNForward = async (
    jid,
    message,
    forceForward = false,
    options = {},
  ) => {
    let vtype;
    if (options.readViewOnce) {
      message.message =
        message.message &&
        message.message.ephemeralMessage &&
        message.message.ephemeralMessage.message
          ? message.message.ephemeralMessage.message
          : message.message || undefined;
      vtype = Object.keys(message.message.viewOnceMessage.message)[0];
      delete (message.message && message.message.ignore
        ? message.message.ignore
        : message.message || undefined);
      delete message.message.viewOnceMessage.message[vtype].viewOnce;
      message.message = {
        ...message.message.viewOnceMessage.message,
      };
    }
    let mtype = Object.keys(message.message)[0];
    let content = await generateForwardMessageContent(message, forceForward);
    let ctype = Object.keys(content)[0];
    let context = {};
    if (mtype != "conversation") context = message.message[mtype].contextInfo;
    content[ctype].contextInfo = {
      ...context,
      ...content[ctype].contextInfo,
    };
    const waMessage = await generateWAMessageFromContent(
      jid,
      content,
      options
        ? {
            ...content[ctype],
            ...options,
            ...(options.contextInfo
              ? {
                  contextInfo: {
                    ...content[ctype].contextInfo,
                    ...options.contextInfo,
                  },
                }
              : {}),
          }
        : {},
    );
    await RyuuBotz.relayMessage(jid, waMessage.message, {
      messageId: waMessage.key.id,
    });
    return waMessage;
  };
  RyuuBotz.downloadAndSaveMediaMessage = async (
    message,
    filename,
    attachExtension = true,
  ) => {
    let quoted = message.msg ? message.msg : message;
    let mime = (message.msg || message).mimetype || "";
    let messageType = message.mtype
      ? message.mtype.replace(/Message/gi, "")
      : mime.split("/")[0];
    const stream = await downloadContentFromMessage(quoted, messageType);
    let buffer = Buffer.from([]);
    for await (const chunk of stream) {
      buffer = Buffer.concat([buffer, chunk]);
    }
    let type = await FileType.fromBuffer(buffer);
    let trueFileName;
    if (type.ext == "ogg" || type.ext == "opus") {
      trueFileName = attachExtension ? filename + ".mp3" : filename;
      await fs.writeFileSync(trueFileName, buffer);
    } else {
      trueFileName = attachExtension ? filename + "." + type.ext : filename;
      await fs.writeFileSync(trueFileName, buffer);
    }
    return trueFileName;
  };
  RyuuBotz.downloadMediaMessage = async (message) => {
    let mime = (message.msg || message).mimetype || "";
    let messageType = message.mtype
      ? message.mtype.replace(/Message/gi, "")
      : mime.split("/")[0];
    const stream = await downloadContentFromMessage(message, messageType);
    let buffer = Buffer.from([]);
    for await (const chunk of stream) {
      buffer = Buffer.concat([buffer, chunk]);
    }
    return buffer;
  };
  RyuuBotz.getFile = async (PATH, save) => {
    let res;
    let filename;
    let data = Buffer.isBuffer(PATH)
      ? PATH
      : /^data:.*?\/.*?;base64,/i.test(PATH)
        ? Buffer.from(PATH.split`,`[1], "base64")
        : /^https?:\/\//.test(PATH)
          ? await (res = await getBuffer(PATH))
          : fs.existsSync(PATH)
            ? ((filename = PATH), fs.readFileSync(PATH))
            : typeof PATH === "string"
              ? PATH
              : Buffer.alloc(0);
    let type = (await FileType.fromBuffer(data)) || {
      mime: "application/octet-stream",
      ext: ".bin",
    };
    if (data && save) fs.promises.writeFile(filename, data);
    return {
      res,
      filename,
      size: await getSizeMedia(data),
      ...type,
      data,
    };
  };
  RyuuBotz.sendText = (jid, text, quoted = "", options) =>
    RyuuBotz.sendMessage(
      jid,
      {
        text: text,
        ...options,
      },
      {
        quoted,
      },
    );
  RyuuBotz.serializeM = (m) => smsg(RyuuBotz, m, store);
  /**
   * Send Media/File with Automatic Type Specifier
   * @param {String} jid
   * @param {String|Buffer} path
   * @param {String} filename
   * @param {String} caption
   * @param {import('@whiskeysockets/baileys').proto.WebMessageInfo} quoted
   * @param {Boolean} ptt
   * @param {Object} options
   */
  RyuuBotz.sendFile = async (
    jid,
    path,
    filename = "",
    caption = "",
    quoted,
    ptt = false,
    options = {},
  ) => {
    let type = await RyuuBotz.getFile(path, true);
    let { res, data: file, filename: pathFile } = type;
    if ((res && res.status !== 200) || file.length <= 65536) {
      try {
        throw {
          json: JSON.parse(file.toString()),
        };
      } catch (e) {
        if (e.json) throw e.json;
      }
    }
    const fileSize = fs.statSync(pathFile).size / 1024 / 1024;
    if (fileSize >= 1800) throw new Error(" The file size is too large\n\n");
    let opt = {};
    if (quoted) opt.quoted = quoted;
    if (!type) options.asDocument = true;
    let mtype = "",
      mimetype = options.mimetype || type.mime,
      convert;
    if (/webp/.test(type.mime) || (/image/.test(type.mime) && options.asSticker)) mtype = 'sticker';
  else if (/image/.test(type.mime) || (/webp/.test(type.mime) && options.asImage)) mtype = 'image';
  else if (/video/.test(type.mime)) mtype = 'video';
  else if (/audio/.test(type.mime)) {
    convert = await (ptt ? toPTT : toAudio)(file, type.ext);
    file = convert.data;
    pathFile = convert.filename;
    mtype = 'audio';
    mimetype = 'audio/ogg; codecs=opus';
  } else mtype = 'document';
    if (options.asDocument) mtype = "document";
    delete options.asSticker;
    delete options.asLocation;
    delete options.asVideo;
    delete options.asDocument;
    delete options.asImage;
    let message = {
      ...options,
      caption,
      ptt,
      [mtype]: {
        url: pathFile,
      },
      mimetype,
      fileName: filename || pathFile.split("/").pop(),
    };
    /**
     * @type {import('@whiskeysockets/baileys').proto.WebMessageInfo}
     */
    let m;
    try {
      m = await RyuuBotz.sendMessage(jid, message, {
        ...opt,
        ...options,
      });
    } catch (e) {
      console.error(e);
      m = null;
    } finally {
      if (!m)
        m = await RyuuBotz.sendMessage(
          jid,
          {
            ...message,
            [mtype]: file,
          },
          {
            ...opt,
            ...options,
          },
        );
      file = null; // releasing the memory
      return m;
    }
  };
  RyuuBotz.sendFile = async (jid, media, options = {}) => {
    let file = await RyuuBotz.getFile(media);
    let mime = file.ext,
      type;
    // Tentukan tipe file berdasarkan ekstensi
    if (mime == "mp3") {
      type = "audio";
      options.mimetype = "audio/mpeg";
      options.ptt = options.ptt || false;
    } else if (mime == "jpg" || mime == "jpeg" || mime == "png") {
      type = "image";
    } else if (mime == "webp") {
      type = "sticker";
    } else if (mime == "mp4") {
      type = "video";
    } else {
      type = "document";
    }
    // Menambahkan caption dan quoted ke pengiriman pesan
    return RyuuBotz.sendMessage(
      jid,
      {
        [type]: file.data,
        caption: options.caption || "", // Menambahkan caption jika ada
        ...options,
      },
      {
        quoted: options.quoted || "", // Menambahkan quoted jika ada
        ...options,
      },
    );
  };
  RyuuBotz.sendFileUrl = async (jid, url, caption, quoted, options = {}) => {
    let mime = "";
    let res = await axios.head(url);
    mime = res.headers["content-type"];
    if (mime.split("/")[1] === "gif") {
      return RyuuBotz.sendMessage(
        jid,
        {
          video: await getBuffer(url),
          caption: caption,
          gifPlayback: true,
          ...options,
        },
        {
          quoted: quoted,
          ...options,
        },
      );
    }
    let type = mime.split("/")[0] + "Message";
    if (mime === "application/pdf") {
      return RyuuBotz.sendMessage(
        jid,
        {
          document: await getBuffer(url),
          mimetype: "application/pdf",
          caption: caption,
          ...options,
        },
        {
          quoted: quoted,
          ...options,
        },
      );
    }
    if (mime.split("/")[0] === "image") {
      return RyuuBotz.sendMessage(
        jid,
        {
          image: await getBuffer(url),
          caption: caption,
          ...options,
        },
        {
          quoted: quoted,
          ...options,
        },
      );
    }
    if (mime.split("/")[0] === "video") {
      return RyuuBotz.sendMessage(
        jid,
        {
          video: await getBuffer(url),
          caption: caption,
          mimetype: "video/mp4",
          ...options,
        },
        {
          quoted: quoted,
          ...options,
        },
      );
    }
    if (mime.split("/")[0] === "audio") {
      return RyuuBotz.sendMessage(
        jid,
        {
          audio: await getBuffer(url),
          caption: caption,
          mimetype: "audio/mpeg",
          ...options,
        },
        {
          quoted: quoted,
          ...options,
        },
      );
    }
  };
  /**
   *
   * @param {*} jid
   * @param {*} name
   * @param [*] values
   * @returns
   */
  /*
  RyuuBotz.sendPoll = (jid, name = "", values = [], selectableCount = 1) => {
    return RyuuBotz.sendMessage(jid, {
      poll: {
        name,
        values,
        selectableCount,
      },
    });
  };
  */
  /**
   * @typedef Media
   * @prop {"image"|"video"|"document"} type
   * @prop {buffer|{ url: string }} data
   * @prop {{}} [options]
   */
  /**
   * @typedef Button
   * @prop {Section[]} [sections]
   */
  /**
   * @typedef Section
   * @prop {string} title
   * @prop {Row[]} rows
   */
  /**
   * @typedef Row
   * @prop {string} header
   * @prop {string} title
   * @prop {string} description
   * @prop {string} id
   */
  /**
   * Function to send interactiveMessage
   *
   * @param {string} jid
   * @param {string} body
   * @param {string} [footer]
   * @param {string} title
   * @param {string} [subtitle]
   * @param {Media} [media]
   * @param {Button[]} buttons
   * @param {proto.WebMessageInfo} [quoted]
   * @param {{}} [options={}]
   * @returns {Promise<proto.WebMessageInfo>}
   */
 
    // ### End of sending message ###
  return RyuuBotz;
}

// START BOT
startsesi();

// ======================
// AUTO WATCH FILE
// ======================
const file = new URL(import.meta.url).pathname;

fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.log(chalk.redBright(`Update ${file}`));
  import(`${import.meta.url}?update=${Date.now()}`);
});