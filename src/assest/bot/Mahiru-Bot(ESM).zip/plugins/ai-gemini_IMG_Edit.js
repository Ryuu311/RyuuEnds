import fs from 'fs';
import { GoogleGenerativeAI } from '@google/generative-ai';

const GEMINI_API_KEY = "AIzaSyDp6HU2CJ2gWS_dU2VVDbD2Mwde5VaMYU0";

const handler = async (m, { RyuuBotz, text, reply, command, prefix }) => {
  let q = m.quoted ? m.quoted : m;
  let mime = (q.msg || q).mimetype || '';

  if (!/image/.test(mime)) {
    return reply(
      `📌 Reply gambar dengan caption: *${prefix + command} [prompt]*\nContoh: *${prefix + command} beri topi santa*`
    );
  }

  if (!text || text.trim().length < 3) {
    return reply(
      `*Prompt tidak boleh kosong!*\nContoh: *${prefix + command} beri topi santa*`
    );
  }

  await RyuuBotz.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

  try {
    // Download gambar yang di-reply
    const mediaPath = await RyuuBotz.downloadAndSaveMediaMessage(m.quoted);
    const mediaBuffer = fs.readFileSync(mediaPath);
    const mime = m.quoted.mimetype || 'image/jpeg';

    // Inisialisasi Gemini
    const genAI = new GoogleGenerativeAI(GEMINI_API_KEY);
    const model = genAI.getGenerativeModel({
      model: 'gemini-2.5-flash-image-preview',
    });

    // Generate gambar dengan prompt + input gambar
    const response = await model.generateContent([
      { text },
      { inlineData: { mimeType: mime, data: mediaBuffer.toString('base64') } },
    ]);

    // Ambil hasil gambar
    const content = response?.candidates?.[0]?.content;
    if (!content) throw new Error('No content generated');

    const result = content.find((p) => p.inlineData);
    if (!result) throw new Error('No image found in response');

    const imgBuffer = Buffer.from(result.inlineData.data, 'base64');

    // Kirim hasil ke chat
    await RyuuBotz.sendMessage(
      m.chat,
      {
        image: imgBuffer,
        caption: `✅ *Hasil AI Edit*\nPrompt: ${text}`,
      },
      { quoted: m }
    );

    await RyuuBotz.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    // Hapus file sementara
    fs.unlinkSync(mediaPath);
  } catch (err) {
    console.error(err);
    await RyuuBotz.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    reply(`❌ Gagal memproses gambar.\n*Error:* ${err.message}`);
  }
};

handler.command = ['aiedit', 'image-edit', 'imgedit'];
export default handler;