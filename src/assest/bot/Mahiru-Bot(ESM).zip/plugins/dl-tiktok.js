import fetch from 'node-fetch';
import "../settings.js";

let handler = async (m, { text, prefix, RyuuBotz, reply }) => {
  if (!text) return reply(`*Example:* ${prefix}tiktok https://vt.tiktok.com/ZSStrGRg1/`);
  if (!text.includes('tiktok.com') && !text.includes('vt.tiktok.com')) return reply('Masukkan link TikTok yang valid!');
  
  await RyuuBotz.sendMessage(m.chat, { react: { text: '🕖', key: m.key } });

  try {
    const res = await fetch(`https://ryuu-endss-api.vercel.app/download/tiktok?url=${encodeURIComponent(text)}`);
    if (!res.ok) throw await res.text();
    const json = await res.json();

    if (!json.status || !json.result) return reply('Gagal mengambil data video TikTok.');

    const { title, cover } = json.result;
    const videoNowm = json.result["no-watermark"];
    const videoWm = json.result["watermark"];
    const audio = json.result["audio"];
    const profile = json.result["profile"];
    const empty = global.kosong

    if (!videoNowm) return reply('Tidak menemukan video tanpa watermark.');

    await RyuuBotz.sendMessage(m.chat, {
      image: { url: cover },
      caption: `🎬 *TikTok Video Found!*
📌 *Title:* ${title}
👤 *Profile:* ${profile}
🎵 *Audio:* ${audio}
_Mengirim video..._
${empty}
🔗 *Download (No WM):* ${videoNowm}
🔗 *Download (WM):* ${videoWm}`
    }, { quoted: m });

    await RyuuBotz.sendMessage(m.chat, {
      video: { url: videoNowm },
      caption: `✅ *Berhasil mengunduh video!*\n🎬 ${title}`
    }, { quoted: m });

  } catch (err) {
    console.log('TikTok Error:', err);
    reply(`❌ Error saat memproses video:\n${err.message || err}`);
  }
};

handler.command = ["tiktok", "tt"];
handler.tags = ["downloader"];
handler.help = ["tiktok <url>", "tt <url>"];

export default handler;