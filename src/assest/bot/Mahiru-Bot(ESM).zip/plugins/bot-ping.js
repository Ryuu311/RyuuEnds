import '../settings.js';
import os from 'os';
import fs from 'fs';
import { execSync } from 'child_process';
import { modul } from '../module.js';
import { runtime, formatp } from '../lib/myfunc.js';

const { speed } = modul;

let handler = async (m, { RyuuBotz, reply, isCreator }) => {
  async function loadingBar(m, RyuuBotz) {
    try {
      if (BarLoad) {
        const createProgressBar = (value, maxValue, length) => {
          const percentage = value / maxValue;
          const progress = Math.round(length * percentage);
          const empty = length - progress;
          return `[${'█'.repeat(progress)}${'░'.repeat(empty)}]`;
        };

        let progress = 0;
        let message = await RyuuBotz.sendMessage(
          m.chat,
          { text: `Loading...\n${createProgressBar(progress, 100, 20)} ${progress}%` },
          { quoted: m }
        );

        while (progress < 100) {
          await global.sleep(100);
          progress += 5;
          const newText = `Loading...\n${createProgressBar(progress, 100, 20)} ${progress}%`;

          await RyuuBotz.relayMessage(
            m.chat,
            {
              protocolMessage: {
                key: message.key,
                type: 14,
                editedMessage: { conversation: newText }
              }
            },
            {}
          );
        }

        const finalText = `Loading Selesai!!!`;
        await RyuuBotz.relayMessage(
          m.chat,
          {
            protocolMessage: {
              key: message.key,
              type: 14,
              editedMessage: { conversation: finalText }
            }
          },
          {}
        );

        return message;
      } else {
        await RyuuBotz.sendMessage(m.chat, { react: { text: '⏱️', key: m.key } });
      }
    } catch (err) {
      console.log('error bang :v', err);
      reply(`Yah error ${err}`);
    }
  }

  if (!isCreator) return reply(mess.creator);

  function countIdsFromFile(path = './database/registered.json') {
    try {
      const rawData = fs.readFileSync(path);
      const database = JSON.parse(rawData);
      return database.length;
    } catch (err) {
      console.error('Gagal membaca file:', err.message);
      return 0;
    }
  }

  const totalIds = countIdsFromFile();

  try {
    const output = execSync('df -h /').toString().split('\n')[1].split(/\s+/);
    const totals = output[1];
    const useds = output[2];
    const availables = output[3];
    const percents = output[4];

    const used = process.memoryUsage();
    const cpus = os.cpus().map(cpu => {
      cpu.total = Object.keys(cpu.times).reduce((last, type) => last + cpu.times[type], 0);
      return cpu;
    });

    const cpu = cpus.reduce(
      (last, cpu, _, { length }) => {
        last.total += cpu.total;
        last.speed += cpu.speed / length;
        last.times.user += cpu.times.user;
        last.times.nice += cpu.times.nice;
        last.times.sys += cpu.times.sys;
        last.times.idle += cpu.times.idle;
        last.times.irq += cpu.times.irq;
        return last;
      },
      {
        speed: 0,
        total: 0,
        times: { user: 0, nice: 0, sys: 0, idle: 0, irq: 0 }
      }
    );

    let timestamp = speed();
    let latensi = speed() - timestamp;
    let neww = performance.now();
    let oldd = performance.now();

    const detailCPU = `_CPU Core(s) Usage (${cpus.length} Core CPU)_\n${cpus
      .map(
        (cpu, i) =>
          `${i + 1}. ${cpu.model.trim()} (${cpu.speed} MHZ)\n${Object.keys(cpu.times)
            .map(
              type =>
                `- *${(type + '*').padEnd(6)}: ${(100 * cpu.times[type] / cpu.total).toFixed(2)}%`
            )
            .join('\n')}`
      )
      .join('\n\n')}`;

    const finalText = `
\`ɪɴғᴏʀᴍᴀsɪ ʙᴏᴛ ᴡʜᴀᴛsᴀᴘᴘ\`

🕒 ᴋᴇᴄᴇᴘᴀᴛᴀɴ : ${latensi.toFixed(4)} ᴅᴇᴛɪᴋ
⏳ ᴀᴋᴛɪғ : ${runtime(process.uptime())}

👤 ᴘᴇɴɢɢᴜɴᴀ ᴛᴇʀᴅᴀғᴛᴀʀ : *${totalIds}*
📲 ᴍᴏᴅᴇ : *${self_ ? 'sᴇʟғ' : 'ᴘᴜʙʟɪᴄ'}*

⌲ Self: *${global.self_}*
⌲ Loading Animation: *${global.BarLoad}*
⌲ Channel Log: *${global.channel_log}*
⌲ Use Prefix: *${global.pref}*

📡 ɪɴғᴏ sᴇʀᴠᴇʀ
━━━━━━━━━━━━━━━
💾 RAM : ${formatp(os.totalmem() - os.freemem())} / ${formatp(os.totalmem())}

📁 Disk : ${useds}B / ${totals}B (${percents})
📂 Free : ${availables}B

🧠 CPU : User ${(100 * cpu.times.user / cpu.total).toFixed(1)}% 
         : Sys ${(100 * cpu.times.sys / cpu.total).toFixed(1)}%
         : Idle ${(100 * cpu.times.idle / cpu.total).toFixed(0)}%
        - ${cpus[0].model.trim()} (${cpus.length} Cores)
${global.kosong}
${detailCPU}
━━━━━━━━━━━━━━━

✨ ᴋᴀʟᴀᴜ ᴀᴅᴀ ᴋᴇʙᴜᴛʜᴀɴ ʟᴀɪɴɴʏᴀ ᴋᴀʙᴀʀɪɴ ᴍᴀʜɪʀᴜ ʏᴀ~ ✨
`.trim();

    await loadingBar(m, RyuuBotz);
    await global.sleep(1000);
    await RyuuBotz.sendMessage(
      m.chat,
      {
        text: finalText,
        contextInfo: {
          externalAdReply: {
            title: 'ᴋᴇᴄᴇᴘᴀᴛᴀɴ ʙᴏᴛ',
            body: `${latensi.toFixed(4)} ᴅᴇᴛɪᴋ\n${oldd - neww} _miliseconds_`,
            thumbnailUrl: global.thumbnail,
            sourceUrl: global.saluran,
            mediaType: 1,
            renderLargerThumbnail: true
          }
        }
      },
      { quoted: m }
    );
  } catch (e) {
    console.error('Error di plugin info:', e);
    reply('Terjadi kesalahan saat menjalankan info bot.');
  }
};

handler.command = ['info', 'tes', 'ping', 'bot', 'bot-tes', 'bottes'];
export default handler;