import { Sticker, StickerTypes } from 'wa-sticker-formatter';

let handler = async (m, { RyuuBotz, text, reply }) => {
  try {
    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || '';
    let media = await q.download();

    let teks1 = text?.split('|')[0] ? text.split('|')[0] : global.packname;
    let teks2 = text?.split('|')[1] ? text.split('|')[1] : global.author;

    if (!/image|video|webp/.test(mime)) {
      return reply(
        `Kirim/reply gambar/video/stiker dengan caption *${m.prefix + m.command}*\nDurasi Video/GIF 1-5 Detik 🌸`
      );
    }

    await RyuuBotz.sendMessage(m.chat, { react: { text: "⏱️", key: m.key } });

    if (/webp/.test(mime)) {
      const stiker = new Sticker(media, {
        pack: teks1,
        author: teks2,
        type: StickerTypes.FULL,
        quality: 80,
      });

      const buffer = await stiker.toBuffer();
      await RyuuBotz.sendMessage(m.chat, { sticker: buffer }, { quoted: m });

    } else if (/video/.test(mime)) {
      if ((q.msg || q).seconds > 5) return reply('Maksimal 5 detik yaa sayang 🥺🫧');
      await RyuuBotz.sendVideoAsSticker(m.chat, media, m, {
        packname: teks1,
        author: teks2,
      });

    } else if (/image/.test(mime)) {
      await RyuuBotz.sendImageAsSticker(m.chat, media, m, {
        packname: teks1,
        author: teks2,
      });
    }
  } catch (err) {
    reply(`❌ Gagal membuat stiker\n${err.message}`);
    console.error('❌ Gagal membuat stiker:', err);
  }
};

handler.command = ["s", "stiker", "sticker"];
export default handler;