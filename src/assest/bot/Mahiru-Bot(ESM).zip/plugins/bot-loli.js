import axios from "axios";

let handler = async (m, { RyuuBotz, reply }) => {
  try {
    await RyuuBotz.sendMessage(m.chat, { react: { text: "⏱️", key: m.key } });

    const url = "https://api.ryuu-dev.offc.my.id/random/cosplay-ba";
    const response = await axios.get(url, { responseType: "arraybuffer" });
    const buffer = Buffer.from(response.data, "binary");

    await RyuuBotz.sendMessage(
      m.chat,
      { image: buffer, caption: "Cosplay random dari Blue Archive ✨" },
      { quoted: m }
    );
  } catch (err) {
    console.error(err);
    reply(`❌ Terjadi kesalahan:\n${err}`);
  }
};

handler.command = ["loli"];
export default handler;