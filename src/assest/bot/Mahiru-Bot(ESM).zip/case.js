import './settings.js';
import { modul } from './module.js';
import path from 'path';
import { exec, spawn, execSync } from 'child_process';
import { color, bgcolor } from './lib/color.js';
import BodyForm from 'form-data';

const { os, axios, baileys, chalk, cheerio, FileType, fs, PhoneNumber, process, moment, speed, ms, util } = modul;
import { fileURLToPath } from 'url';
import { dirname } from 'path';
import { createCanvas, GlobalFonts } from '@napi-rs/canvas';
import Jimp from 'jimp';

import pkkg from '@whiskeysockets/baileys';
const {
  makeWaSocket,
  socket,
  BufferJSON,
  WA_DEFAULT_EPHEMERAL,
  generateWAMessageFromContent,
  proto,
  generateWAMessageContent,
  generateWAMessage,
  prepareWAMessageMedia,
  areJidsSameUser,
  getContentType,
} = pkkg;
import { 
  getRegisteredRandomId, 
  addRegisteredUser, 
  createSerial, 
  checkRegisteredUser 
} from './lib/register.js';

import { 
  clockString,
  parseMention,
  formatp,
  isUrl,
  sleep,
  runtime,
  getBuffer,
  jsonformat,
  capital,
} from './lib/myfunc.js';
import { addweb, delweb, listweb, gethtml } from './lib/webDevelopment.js';

const readFile = util.promisify(fs.readFile);
const more = String.fromCharCode(8206);
const readmore = more.repeat(4001);
let db = JSON.parse(fs.readFileSync('./database/welcome.json'));

const caseHandler = async (RyuuBotz, m, chatUpdate, store) => {
try {
const afkPath = path.join(__dirname, './database/afk.json');

// Load DB AFK
let afkDB = fs.existsSync(afkPath) ? JSON.parse(fs.readFileSync(afkPath)) : [];
if (!fs.existsSync(afkPath)) fs.writeFileSync(afkPath, JSON.stringify(afkDB, null, 2));

function saveAFK() {
    fs.writeFileSync(afkPath, JSON.stringify(afkDB, null, 2));
}

// Format waktu
function clockStrink(ms) {
    let d = Math.floor(ms / 86400000);
    let h = Math.floor(ms / 3600000) % 24;
    let m = Math.floor(ms / 60000) % 60;
    let s = Math.floor(ms / 1000) % 60;
    return [
        d > 0 ? `${d} hari` : "",
        h > 0 ? `${h} jam` : "",
        m > 0 ? `${m} menit` : "",
        s > 0 ? `${s} detik` : ""
    ].filter(Boolean).join(' ');
}


// Cek mention AFK
let mentionUsers = [...new Set([...(m.mentionedJid || []), ...(m.quoted ? [m.quoted.sender] : [])])];
for (let jid of mentionUsers) {
    if (!m.key.fromMe) { 
        let afkUser = afkDB.find(u => u.user === jid);
        if (afkUser && afkUser.afkTime > -1) {
            RyuuBotz.sendMessage(m.chat, {
                text: `📢 Jangan tag dia!\n📴 Dia sedang AFK ${afkUser.alasan ? `dengan alasan: ${afkUser.alasan}` : 'tanpa alasan'}\n🕒 Selama ${clockStrink(new Date - afkUser.afkTime)}`,
                contextInfo: {
                    forwardingScore: 1,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                    newsletterName: global.namabot,
                    newsletterJid: '120363419382206255@newsletter'
                },
                    externalAdReply: {
                        title: 'Jangan di ganggu kocak',
                        body: `Menghilang cuyy`,
                        thumbnailUrl: 'https://api.ryuu-dev.offc.my.id/random/mahiruImages',
                        sourceUrl: 'https://instagram.com/reinzz311'
                    },
                    mentions: [m.sender]
                }
            }, { quoted: m });
        }
    }
}

// Cek balik dari AFK
let senderAFK = afkDB.find(u => u.user === m.sender);
if (senderAFK && senderAFK.afkTime > -1) {
   await RyuuBotz.sendMessage(m.chat, {
        text: `👋 @${m.sender.split("@")[0]} telah berhenti AFK${senderAFK.alasan ? ` dengan alasan: ${senderAFK.alasan}` : ''}\n🕒 Selama ${clockStrink(new Date - senderAFK.afkTime)}`,
        contextInfo: {
            mentionedJid: [m.sender],       
            forwardingScore: 1,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                    newsletterName: global.namabot,
                    newsletterJid: '120363419382206255@newsletter'
                },
            externalAdReply: {
                title: 'Dia Kembali dari Afk',
                body: `Lah muncul lagi :v`,
                thumbnailUrl: 'https://api.ryuu-dev.offc.my.id/random/mahiruImages',
                sourceUrl: 'https://instagram.com/reinzz311'
            },
            mentions: [m.sender]
        }
    }, { quoted: m });

    senderAFK.afkTime = -1;
    senderAFK.alasan = '';
    saveAFK();
}

  async function appenTextMessage(text, chatUpdate) {
    let messages = await generateWAMessage(
      m.chat,
      {
        text: text,
        mentions: m.mentionedJid,
      },
      {
        userJid: RyuuBotz.user.id,
        quoted: m.quoted && m.quoted.fakeObj,
      },
    );
    messages.key.fromMe = areJidsSameUser(m.sender, RyuuBotz.user.id);
    messages.key.id = m.key.id;
    messages.pushName = m.pushName;
    if (m.isGroup) messages.participant = m.sender;
    let msg = {
      ...chatUpdate,
      messages: [proto.WebMessageInfo.fromObject(messages)],
      type: "append",
    };
    RyuuBotz.ev.emit("messages.upsert", msg);
  }
  const { type, quotedMsg, mentioned, now, fromMe } = m;
  let body =
  m.mtype === "interactiveResponseMessage"
    ? JSON.parse(m.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id
    : m.mtype === "conversation"
      ? m.message.conversation
      : m.mtype == "imageMessage"
        ? (m.message.imageMessage.caption || "")
        : m.mtype == "videoMessage"
          ? (m.message.videoMessage.caption || "")
          : m.mtype == "extendedTextMessage"
            ? m.message.extendedTextMessage.text
            : m.mtype == "buttonsResponseMessage"
              ? m.message.buttonsResponseMessage.selectedButtonId
              : m.mtype == "listResponseMessage"
                ? m.message.listResponseMessage.singleSelectReply.selectedRowId
                : m.mtype == "templateButtonReplyMessage"
                  ? m.message.templateButtonReplyMessage.selectedId
                  : m.mtype == "messageContextInfo"
                    ? m.message.buttonsResponseMessage?.selectedButtonId ||
                      m.message.listResponseMessage?.singleSelectReply?.selectedRowId ||
                      m.text
                    : m.mtype === "editedMessage"
                      ? m.message.editedMessage.message.protocolMessage.editedMessage.extendedTextMessage
                        ? m.message.editedMessage.message.protocolMessage.editedMessage.extendedTextMessage.text
                        : m.message.editedMessage.message.protocolMessage.editedMessage.conversation || ""
                      : "";


// ───────────────────────────────────────────────────────────────────────────────乂 🥀 SETTINGS AllFILE ───────────────────────────────────────────────────────────────乂 \\                                              


const premium = JSON.parse(fs.readFileSync("./database/premium.json"))
/*
RyuuBotz.ev.on('group-participants.update', async (anu) => {
let _welcome = (`*❍ 𝙒𝙀𝙇𝘾𝙊𝙈𝙀 𝙈𝙀𝙈𝘽𝙀𝙍 ❍*
*✦ User : @${num.split("@")[0]} 🔥*
*✦ Group : ${metadata.subject}*

*˚₊‧ 𝐂𝐚𝐭𝐚𝐭𝐚𝐧 𝐏𝐞𝐧𝐝𝐚𝐡𝐮𝐚𝐧 ‧₊˚*
*• Harap membaca deskripsi grup sebelum berinteraksi.*
*• Patuhi seluruh aturan yang telah ditetapkan.*
*• Gunakan bahasa yang sopan dan komunikatif.*
*• Simpan kontak admin jika diperlukan untuk keperluan teknis.*`)
    try {
        let metadata = await RyuuBotz.groupMetadata(anu.id);
        let participants = anu.participants;

        for (let num of participants) {
            if (anu.action == 'add') {
                await RyuuBotz.sendMessage(anu.id, {
                    text: _welcome,
                    mentions: [num]
                });
            }

            if (anu.action == 'remove') {
                await RyuuBotz.sendMessage(anu.id, {
                    text: `Sampai jumpa @${num.split("@")[0]} 👋`,
                    mentions: [num]
                });
            }
        }
    } catch (err) {
        console.log(err);
    }
});*/
//Fungsi skip message @lid
if (m.sender && m.sender.endsWith('@lid')) {
    return console.log('skipping @lid message....')
}
//Fungsi skip message channel
if (m.key.remoteJid && m.key.remoteJid.endsWith('@newsletter')) {
    return;
}
// ───────────────────────────────────────────────────────────────────────────────乂 🥀 SETTINGS ADMIN - BOT - OWNER ───────────────────────────────────────────────────────────────乂 \\                                                
const budy = (typeof m.text == 'string' ? m.text : '.')
let preff;
if (global.pref === true) {
    preff = global.prefix;
} else if (global.pref === false) {
    preff = '';
} else {
    preff = '.'; 
}
  const prefix = preff
  const chath = body;
  const pes = body || "";
  const messagesC = pes.slice(0).trim();
  const content = JSON.stringify(m.message);
  const isCmd = body.startsWith(prefix);
  const from = m.key.remoteJid;
  const messagesD = body.slice(0).trim().split(/ +/).shift().toLowerCase();
  const args = body.trim().split(/ +/).slice(1)
  const command = isCmd ? body.slice(prefix.length).trim().split(/ +/).shift().toLowerCase() : '';
  const botNumber = await RyuuBotz.decodeJid(RyuuBotz.user.id);
  const isCreator = m.sender === global.ownernumber.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
  const pushname = m.pushName || "Nothing";
  const text = args.join(" ");
  const q = args.join(" ");
  const quoted = m.quoted ? m.quoted : m;
  const mime = (quoted.msg || quoted).mimetype || "";
  const qmsg = quoted.msg || quoted;
  const isMedia = /image|video|sticker|audio/.test(mime);
  const isImage = type == "imageMessage";
  const isVideo = type == "videoMessage";
  const isAudio = type == "audioMessage";
  const isSticker = type == "stickerMessage";
  const isQuotedImage =
    type === "extendedTextMessage" && content.includes("imageMessage");
  const isQuotedLocation =
    type === "extendedTextMessage" && content.includes("locationMessage");
  const isQuotedVideo =
    type === "extendedTextMessage" && content.includes("videoMessage");
  const isQuotedSticker =
    type === "extendedTextMessage" && content.includes("stickerMessage");
  const isQuotedAudio =
    type === "extendedTextMessage" && content.includes("audioMessage");
  const isQuotedContact =
    type === "extendedTextMessage" && content.includes("contactMessage");
  const isQuotedDocument =
    type === "extendedTextMessage" && content.includes("documentMessage");
  const sender = m.isGroup
    ? m.key.participant
      ? m.key.participant
      : m.participant
    : m.key.remoteJid;
  const senderNumber = sender.split("@")[0];
  const groupMetadata = m.isGroup
    ? await RyuuBotz.groupMetadata(m.chat).catch((e) => {})
    : "";
  const participants =
    m.isGroup && groupMetadata ? groupMetadata.participants : [];
  const groupAdmins = m.isGroup
    ? await participants.filter((v) => v.admin !== null).map((v) => v.id)
    : [];
  const groupName = m.isGroup && groupMetadata ? groupMetadata.subject : [];
  const groupOwner = m.isGroup && groupMetadata ? groupMetadata.owner : [];
  const groupMembership =
    m.isGroup && groupMetadata ? groupMetadata.membership : [];
  const groupMembers =
    m.isGroup && groupMetadata ? groupMetadata.participants : [];
  const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false;
  const isGroupAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false;
  const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false;
  const isPremium = premium.includes(m.sender)
  const isRegistered = checkRegisteredUser(m.sender)
  const delay = ms => new Promise(resolve => setTimeout(resolve, ms))
 const deviceinfo = /^3A/.test(m.id) ? 'ɪᴏs' : m.id.startsWith('3EB') ? 'ᴡᴇʙ' : /^.{21}/.test(m.id) ? 'ᴀɴᴅʀᴏɪᴅ' : /^.{18}/.test(m.id) ? 'ᴅᴇsᴋᴛᴏᴘ' : 'ᴜɴᴋɴᴏᴡ';
  const ments = (text) => {
  return text.match('@') ? [...text.matchAll(/@([0-9]{5,16}|0)/g)].map(v => v[1] + '@s.whatsapp.net') : []}
  const froms = m.quoted ? m.quoted.sender : text ? (text.replace(/[^0-9]/g, '') ? text.replace(/[^0-9]/g, '') + '@s.whatsapp.net' : false) : false;
  const mentionUser = [
    ...new Set([
      ...(m.mentionedJid || []),
      ...(m.quoted ? [m.quoted.sender] : []),
    ]),
  ];
  const mentionByTag =
    type == "extendedTextMessage" &&
    m.message.extendedTextMessage.contextInfo != null
      ? m.message.extendedTextMessage.contextInfo.mentionedJid
      : [];
  const mentionByReply =
    type == "extendedTextMessage" &&
    m.message.extendedTextMessage.contextInfo != null
      ? m.message.extendedTextMessage.contextInfo.participant || ""
      : "";
  const numberQuery =
    q.replace(new RegExp("[()+-/ +/]", "gi"), "") + "@s.whatsapp.net";
  const usernya = mentionByReply ? mentionByReply : mentionByTag[0];
  const Input = mentionByTag[0]
    ? mentionByTag[0]
    : mentionByReply
      ? mentionByReply
      : q
        ? numberQuery
        : false;

// ───────────────────────────────────────────────────────────────────────────────乂 🥀 SETTINGS TIME ───────────────────────────────────────────────────────────────乂 \\                        
  const xtime = moment.tz("Asia/Jakarta").format("HH:mm:ss");
  const xdate = moment.tz("Asia/Jakarta").format("DD/MM/YYYY");
  const time2 = moment().tz("Asia/Jakarta").format("HH:mm:ss");
  if (time2 < "23:59:00") {
    var timewisher = `Selamat Malam`;
  }
  if (time2 < "19:00:00") {
    var timewisher = `Selamat Malam`;
  }
  if (time2 < "18:00:00") {
    var timewisher = `Selamat Sore`;
  }
  if (time2 < "15:00:00") {
    var timewisher = `Selamat Siang`;
  }
  if (time2 < "11:00:00") {
    var timewisher = `Selamat Pagi`;
  }
  if (time2 < "05:00:00") {
    var timewisher = `Selamat Pagi`;
  }
  // Waktu sekarang di zona Asia/Jakarta
  let sekarang = new Date(
    new Date().toLocaleString("en-US", { timeZone: "Asia/Jakarta" }),
  );
  // Fungsi tanggal, bulan, tahun
  function tanggal(ms) {
    return new Date(ms).getDate().toString().padStart(2, "0");
  }
  function bulan(ms) {
    return (new Date(ms).getMonth() + 1).toString().padStart(2, "0"); // +1 karena Januari = 0
  }
  function tahun(ms) {
    return new Date(ms).getFullYear();
  }
  // Fungsi jam:menit:detik
  function formatJam(date) {
    let jam = date.getHours().toString().padStart(2, "0");
    let menit = date.getMinutes().toString().padStart(2, "0");
    let detik = date.getSeconds().toString().padStart(2, "0");
    return `${jam}:${menit}:${detik}`;
  }
  // Output akhir
  let futureDescription = `
📅 *Update Kurs:* ${tanggal(sekarang.getTime())}/${bulan(sekarang.getTime())}/${tahun(sekarang.getTime())}
🕰 *Waktu Jakarta (WIB):* ${formatJam(sekarang)}`;

let ppuser;
try {
  ppuser = await RyuuBotz.profilePictureUrl(m.sender, 'image');
} catch (err) {
  ppuser = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60';
}
let ppnyauser = await getBuffer(ppuser)
try {
let isNumber = x => typeof x === 'number' && !isNaN(x)
let limitUser = isPremium ? 1000 : 30
let user = global.db.data.users[m.sender]
if (typeof user !== 'object') global.db.data.users[m.sender] = {}
if (user) {
if (!('afkReason' in user)) user.afkReason = ''
if (!isNumber(user.limit)) user.limit = limitUser
} else global.db.data.users[m.sender] = {
afkTime: -1,
afkReason: '',
limit: limitUser,
}
} catch (err) {
console.log(err)
}

// ───────────────────────────────────────────────────────────────────────────────乂 🥀 SETTINGS QUOTED ───────────────────────────────────────────────────────────────乂 \\
const qtext = {key: {remoteJid: "status@broadcast", participant: "0@s.whatsapp.net"}, message: {"extendedTextMessage": {"text": `${prefix+command}`}}}
const qbug = {key: {remoteJid: 'status@broadcast', fromMe: false, participant: '0@s.whatsapp.net'}, message: {listResponseMessage: {title: `ꪎ ${global.ownername}`
}}}
const qdoc = {key : {participant : '0@s.whatsapp.net', ...(m.chat ? { remoteJid: `status@broadcast` } : {}) },message: {documentMessage: {title: `ꪎ ${global.ownername}`,jpegThumbnail: ""}}}
const qloc = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `ꪎ ${global.ownername}`,jpegThumbnail: ""}}}
const qloc2 = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `ꪎ ${global.ownername}`,jpegThumbnail: ""}}}
const qpayment = {key: {remoteJid: '0@s.whatsapp.net', fromMe: false, id: `ownername`, participant: '0@s.whatsapp.net'}, message: {requestPaymentMessage: {currencyCodeIso4217: "USD", amount1000: 999999999, requestFrom: '0@s.whatsapp.net', noteMessage: { extendedTextMessage: { text: "Simple Bot"}}, expiryTimestamp: 999999999, amount: {value: 91929291929, offset: 1000, currencyCode: "USD"}}}}
const qtoko = {key: {fromMe: false, participant: `0@s.whatsapp.net`, ...(m.chat ? {remoteJid: "status@broadcast"} : {})}, message: {"productMessage": {"product": {"productImage": {"mimetype": "image/jpeg", "jpegThumbnail": ""}, "title": `ꪎ ${global.ownername}`, "description": null, "currencyCode": "IDR", "priceAmount1000": "999999999999999", "retailerId": `ꪎ ${global.ownername}`, "productImageCount": 1}, "businessOwnerJid": `0@s.whatsapp.net`}}}
const qlive = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {liveLocationMessage: {caption: `ꪎ ${global.ownername}`,jpegThumbnail: ""}}}

async function replymahiru(text) {

    await RyuuBotz.sendMessage(m.chat, {
        text,
        contextInfo: {
            forwardingScore: 1,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterName: global.ownername,
                newsletterJid: '120363419382206255@newsletter'
            },
            externalAdReply: {
                title: 'Mahiru-AI',
                body: 'ғᴏʟʟᴏᴡ ɪɢ reinzz.311',
                thumbnailUrl: 'https://api.ryuu-dev.offc.my.id/random/mahiruImages',
                sourceUrl: 'https://instagram.com/reinzz311'
            }
        }
    }, { quoted: m });
}

async function replyaoi(text) {
    await RyuuBotz.sendMessage(m.chat, {
        text,
        contextInfo: {
            forwardingScore: 1,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterName: 'Character AI',
                newsletterJid: '120363419382206255@newsletter'
            },
            externalAdReply: {
                title: 'Aoi-AI',
                body: 'ғᴏʟʟᴏᴡ ɪɢ reinzz.311',
                thumbnailUrl: 'https://files.catbox.moe/gy0b0m.jpg',
                sourceUrl: 'https://instagram.com/reinzz311'
            }
        }
    }, { quoted: m });
}

async function replyamelia(text) {
    await RyuuBotz.sendMessage(m.chat, {
        text,
        contextInfo: {
            forwardingScore: 1,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterName: 'Character AI',
                newsletterJid: '120363419382206255@newsletter'
            },
            externalAdReply: {
                title: 'Amelia-AI',
                body: 'ғᴏʟʟᴏᴡ ɪɢ reinzz.311',
                thumbnailUrl: 'https://files.catbox.moe/tlv50f.jpg',
                sourceUrl: 'https://instagram.com/reinzz311'
            }
        }
    }, { quoted: m });
}

async function replyiroha(text) {
    await RyuuBotz.sendMessage(m.chat, {
        text,
        contextInfo: {
            forwardingScore: 1,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterName: 'Character AI',
                newsletterJid: '120363419382206255@newsletter'
            },
            externalAdReply: {
                title: 'Iroha-AI',
                body: 'ғᴏʟʟᴏᴡ ɪɢ reinzz.311',
                thumbnailUrl: 'https://files.catbox.moe/ii8hg1.jpg',
                sourceUrl: 'https://instagram.com/reinzz311'
            }
        }
    }, { quoted: m });
}

async function replymongfa(text) {
    await RyuuBotz.sendMessage(m.chat, {
        text,
        contextInfo: {
            forwardingScore: 1,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterName: 'Character AI',
                newsletterJid: '120363419382206255@newsletter'
            },
            externalAdReply: {
                title: 'Mongfa-AI',
                body: 'ғᴏʟʟᴏᴡ ɪɢ reinzz.311',
                thumbnailUrl: 'https://files.catbox.moe/96e0td.jpg',
                sourceUrl: 'https://instagram.com/reinzz311'
            }
        }
    }, { quoted: m });
}

async function replykarin(text) {
    await RyuuBotz.sendMessage(m.chat, {
        text,
        contextInfo: {
            forwardingScore: 1,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterName: 'Character AI',
                newsletterJid: '120363419382206255@newsletter'
            },
            externalAdReply: {
                title: 'Karin-AI',
                body: 'ғᴏʟʟᴏᴡ ɪɢ reinzz.311',
                thumbnailUrl: 'https://files.catbox.moe/jjbu7b.jpg',
                sourceUrl: 'https://instagram.com/reinzz311'
            }
        }
    }, { quoted: m });
}
async function reply(text) {
    
    RyuuBotz.sendMessage(m.chat, {
        text,
        contextInfo: {
            forwardingScore: 1,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterName: 'Mahiru Botzz',
                newsletterJid: '120363419382206255@newsletter'
            },
            externalAdReply: {
                title: 'Mahiru Assistant',
                body: `ғᴏʟʟᴏᴡ ɪɢ reinzz.311`,
                thumbnailUrl: 'https://api.ryuu-dev.offc.my.id/random/mahiruImages',
                sourceUrl: 'https://instagram.com/reinzz311'
            }
        }
    }, { quoted: m });
}
async function reply_(text) {
    
    RyuuBotz.sendMessage(m.chat, {
        text,
        contextInfo: {
            mentionedJid: [botNumber],
            forwardingScore: 1,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterName: 'Mahiru Botzz',
                newsletterJid: '120363419382206255@newsletter'
            },
            externalAdReply: {
                title: 'Mahiru Assistant',
                body: `ғᴏʟʟᴏᴡ ɪɢ reinzz.311`,
                thumbnailUrl: 'https://api.ryuu-dev.offc.my.id/random/mahiruImages',
                sourceUrl: 'https://instagram.com/reinzz311'
            }
        }
    }, { quoted: m });
}
const replyafk = (text) => {

    RyuuBotz.sendMessage(m.chat, {
        text,
        contextInfo: {      
            mentionedJid: [m.sender],
            forwardingScore: 1,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                    newsletterName: global.namabot,
                    newsletterJid: '120363419382206255@newsletter'
                },
            externalAdReply: {
                title: 'Dia mau Afk',
                body: `Dadahh`,
                thumbnailUrl: "https://api.ryuu-dev.offc.my.id/random/mahiruImages",
                sourceUrl: 'https://instagram.com/reinzz311'
            },
            mentions: [m.sender]
        }
    }, { quoted: m });
};
const reply2 = (teks) => {
RyuuBotz.sendMessage(from, { text : teks }, { quoted : m })
}
const example = (teks) => {
return `\n *Contoh Penggunaan :*\n Ketik *${prefix+command}* ${teks}\n`
}

// ───────────────────────────────────────────────────────────────────────────────乂 🥀 SETTINGS PUBLICK - CONSOLE MESSAGE ───────────────────────────────────────────────────────────────乂 \\

function deleteUnwantedFiles() {
const sessionFolder = path.join(__dirname, "session");
const safeFile = "creds.json";
    fs.readdir(sessionFolder, (err, files) => {
        if (err) {
            console.error("Gagal membaca folder:", err);
            return;
        }
        const filesToDelete = files.filter(file => file !== safeFile);
        let deletedCount = 0;

        filesToDelete.forEach(file => {
            const filePath = path.join(sessionFolder, file);
            try {
                fs.unlinkSync(filePath);
                deletedCount++;
            } catch (err) {
                console.error("Gagal hapus:", file, err);
            }
        });

        console.log(`[AUTO CLEAN] ${deletedCount} file terhapus (${(moment().tz('Asia/Jakarta').format('DD/MM/YYYY HH:mm:ss'))})`);
    });
}       
if (m.message) {
    const time = chalk.yellow(moment().tz('Asia/Jakarta').format('DD/MM/YYYY HH:mm:ss'))
    const msgType = chalk.cyan(budy ? budy : m.mtype)
    const sender = `${chalk.green(pushname)} ${chalk.gray(`<${m.sender}>`)}`
    const location = m.isGroup
        ? `${chalk.blue('Group:')} ${chalk.yellow(groupName)} ${chalk.gray(`(${m.chat})`)}`
        : chalk.blue('Private Chat')        
    console.log(`${chalk.white('┌' + '─'.repeat(15) + '[ NEW MESSAGE ]' + '─'.repeat(16) + '┐')}
📅 ↳ ${time}
💬 ↳ ${msgType}
🙋 ↳ ${sender}
📍 ↳ ${location}
${chalk.white('└' + '─'.repeat(48) + '┘')}`)
 RyuuBotz.readMessages([m.key]);
 deleteUnwantedFiles();
const mess__ = 
`┌─────────[ NEW MESSAGE ]─────────┐
📅 ↳ ${(moment().tz('Asia/Jakarta').format('DD/MM/YYYY HH:mm:ss'))}
💬 ↳ ${budy ? budy : m.mtype}
🙋 ↳ ${pushname}
📲 ↳ ${m.sender}
📍 ↳ ${m.isGroup
        ? `Group: ${groupName} (${m.chat})`
        : 'Private Chat'}
└──────────────────────────────┘`;
 if (global.channel_log === true) {
  RyuuBotz.sendMessage('120363420007790159@newsletter', {
    text: mess__,
    contextInfo: {
      externalAdReply: {
        title: 'Log Bot',
        body: `Bot information`,
        thumbnailUrl: global.thumbnail,
        sourceUrl: global.saluran,
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
  });
 }
}

// Stiker Anti-Panggil Owner :v\\
try {
  if (typeof m.text === 'string' && new RegExp(`@${global.jidownernumber || global.lidownernumber}`, 'i').test(m.text)) {
    if (!isCreator) {
      const stickerBuffer = fs.readFileSync('./stiker/apa-woi.webp');
      RyuuBotz.sendImageAsSticker(
        m.chat,
        stickerBuffer,
        m,
        {
          packname: `Jangan tag owner ku 😡`
        },
        {
          quoted: m
        }
      )
      RyuuBotz.sendMessage(
      m.chat,
      {
        video: { url : "https://api.ryuu-dev.offc.my.id/src/assest/mahiru/VID-20250830-WA0024.mp4" },
        ptv: true
});
    }
  }
} catch (err) {
  console.error('Error saat mengirim stiker:', err);
  reply(`Owner ku pusing anj😭\n*Error:* ${err.message}`);
}
// ─────乂 🥀 ALL FUNCTION ────乂 \\

if (self_) {
   if (!isCreator && !m.key.fromMe) { 
    return;    
  }
}

async function RyuuCloud(filePath) {
	try {
		const fileStream = fs.createReadStream(filePath);
		const formData = new BodyForm();
		formData.append('file', fileStream);
		const response = await axios.post('https://files.ryuu-dev.offc.my.id/api/upload', formData, {
			headers:
			 { ...formHeaders },
		});
		return response.data;
	} catch (error) {
		console.error("Error at RyuuCloud uploader:", error);
		return "Terjadi kesalahan saat upload ke RyuuCloud.";
	}
};

async function CatBox(filePath) {
	try {
		const fileStream = fs.createReadStream(filePath);
		const formData = new BodyForm();
		formData.append('fileToUpload', fileStream);
		formData.append('reqtype', 'fileupload');
		formData.append('userhash', '');
		const response = await axios.post('https://catbox.moe/user/api.php', formData, {
			headers: {
				...formData.getHeaders(),
			},
		});
		return response.data;
	} catch (error) {
		console.error("Error at Catbox uploader:", error);
		return "Terjadi kesalahan saat upload ke Catbox.";
	}
};

async function loadingBar(m, RyuuBotz) {
try {
if (BarLoad) {
  const createProgressBar = (value, maxValue, length) => {
    const percentage = value / maxValue;
    const progress = Math.round(length * percentage);
    const empty = length - progress;
    return `[${"█".repeat(progress)}${"░".repeat(empty)}]`;
  };

  let progress = 0;
  let message = await RyuuBotz.sendMessage(
    m.chat,
    { text: `Loading...\n${createProgressBar(progress, 100, 20)} ${progress}%` },
    { quoted: m }
  );

  while (progress < 100) {
    await global.sleep(100);
    progress += 5;
    const newText = `Loading...\n${createProgressBar(progress, 100, 20)} ${progress}%`;

    await RyuuBotz.relayMessage(
      m.chat,
      {
        protocolMessage: {
          key: message.key,
          type: 14,
          editedMessage: { conversation: newText }
        }
      },
      {}
    );
  }

  const finalText = `Loading Selesai!!!`;
  await RyuuBotz.relayMessage(
    m.chat,
    {
      protocolMessage: {
        key: message.key,
        type: 14,
        editedMessage: { conversation: finalText }
      }
    },
    {}
  );

  return message;
  } else {
  await RyuuBotz.sendMessage(m.chat, { react: { text: '⏱️', key: m.key } });
  }
  } catch(err) {
  console.log('error bang :v', err);
  reply(`Yah error ${err}`);
  }
}

  async function sendconnMessage(chatId, message, options = {}) {
    let generate = await generateWAMessage(chatId, message, options);
    let type2 = getContentType(generate.message);
    if ("contextInfo" in options)
      generate.message[type2].contextInfo = options?.contextInfo;
    if ("contextInfo" in message)
      generate.message[type2].contextInfo = message?.contextInfo;
    return await RyuuBotz.relayMessage(chatId, generate.message, {
      messageId: generate.key.id,
    });
  }
  
  function GetType(Data) {
    return new Promise((resolve, reject) => {
      let Result, Status;
      if (Buffer.isBuffer(Data)) {
        Result = new Buffer.from(Data).toString("base64");
        Status = 0;
      } else {
        Status = 1;
      }
      resolve({
        status: Status,
        result: Result,
      });
    });
  }
  
  function randomId() {
    return Math.floor(100000 + Math.random() * 900000);
  }
  
  function monospace(string) {
    return '```' + string + '```'
}

function monospa(string) {
    return '`' + string + '`'
}

function getRandomFile(ext) {
return `${Math.floor(Math.random() * 10000)}${ext}`;
}

function pickRandom(list) {
return list[Math.floor(Math.random() * list.length)]
}

function randomNomor(min, max = null){
if (max !== null) {
min = Math.ceil(min);
max = Math.floor(max);
return Math.floor(Math.random() * (max - min + 1)) + min;
} else {
return Math.floor(Math.random() * min) + 1
}
}

function generateRandomPassword() {
const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#%^&*';
const length = 10;
let password = '';
for (let i = 0; i < length; i++) {
const randomIndex = Math.floor(Math.random() * characters.length);
password += characters[randomIndex];
}
return password;
}

function generateRandomNumber(min, max) {
return Math.floor(Math.random() * (max - min + 1)) + min;
}

    async function listbut2(m, teks, listnye, qtext) {
let msg = generateWAMessageFromContent(m.chat, {
viewOnceMessage: {
message: {
"messageContextInfo": {
"deviceListMetadata": {},
"deviceListMetadataVersion": 2
},
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: {
mentionedJid: [m.sender],
forwardingScore: 999999,
isForwarded: true,
forwardedNewsletterMessageInfo: {
newsletterJid: `120363405649403674@newsletter`,
newsletterName: `— ${namabot} AI WhatsApp Bot`,
serverMessageId: 145
}
},
body: proto.Message.InteractiveMessage.Body.create({
text: teks
}),
footer: proto.Message.InteractiveMessage.Footer.create({
text: `${namabot} By ${ownername}`
}),
header: proto.Message.InteractiveMessage.Header.create({
title: ``,
thumbnailUrl: "",
gifPlayback: true,
subtitle: "",
hasMediaAttachment: true,
...(await prepareWAMessageMedia({ image: { url: 'https://files.catbox.moe/rj0ok0.jpg' } }, { upload: RyuuBotz.waUploadToServer })),
}),
gifPlayback: true,
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
buttons: [
{
"name": "single_select",
"buttonParamsJson": JSON.stringify(listnye)
}],
}), })}
}}, {quoted: qtext})
await RyuuBotz.relayMessage(msg.key.remoteJid, msg.message, {
messageId: msg.key.id
})
}

async function dellCase(filePath, caseNameToRemove) {
            fs.readFile(filePath, 'utf8', (err, data) => {
                if (err) {
                    console.error('Terjadi kesalahan:', err);
                    return;
                }

                const regex = new RegExp(`case\\s+'${caseNameToRemove}':[\\s\\S]*?break`, 'g');
                const modifiedData = data.replace(regex, '');

                fs.writeFile(filePath, modifiedData, 'utf8', (err) => {
                    if (err) {
                        console.error('Terjadi kesalahan saat menulis file:', err);
                        return;
                    }

                    console.log(`Teks dari case '${caseNameToRemove}' telah dihapus dari file.`);
                });
            });
        }
        

// ───────────────────────────────────────────────────────────────────────────────乂 🥀 PLUGINS ───────────────────────────────────────────────────────────────乂 
 if (prefix === '.') {
    if (command && !isRegistered && !['daftar', 'regis', 'register'].includes(command)) {
  return reply(mess.notregist);
  }
}
const pluginsLoader = async (directory) => {
  let plugins = [];
  const folders = fs.readdirSync(directory);
  
  for (const file of folders) {
    const filePath = path.join(directory, file);
    if (filePath.endsWith('.js')) {
      try {
        const plugin = await import(`file://${filePath}`);
        plugins.push(plugin.default || plugin); 
      } catch (error) {
        console.log(`Error loading plugin at ${filePath}:`, error);
      }
    }
  }
  
  return plugins;
};

    let pluginsDisable = true;
    const plugins = await pluginsLoader(path.resolve(__dirname, "plugins"));
    const kyykzy = { RyuuBotz, prefix, command, reply, text, isGroup: m.isGroup, isCreator, example, sender, senderNumber, pushname, args, runtime, formatp, sleep, getBuffer, isBotAdmins, isAdmins, isCmd, qtext, isPremium, randomNomor, monospace, pickRandom, getRandomFile };
    for (let plugin of plugins) {
      if (plugin.command.find((e) => e == command.toLowerCase())) {
        pluginsDisable = false;
        if (typeof plugin !== "function") return;
        await plugin(m, kyykzy);
      }
    }
    if (!pluginsDisable) return; 
  
  
  switch (command) {  
case 'lirik':
case 'lyrics': {
 if (!text) return reply(`Contoh: ${prefix + command} Kenangan mantan`);

 await RyuuBotz.sendMessage(m.chat, { react: { text: "🎶", key: m.key } });

 try {
 const query = encodeURIComponent(text.toLowerCase());
 const url = `https://lyrics.lewdhutao.my.eu.org/v2/musixmatch/lyrics?title=${query}`;
 const res = await axios.get(url);

 const d = res.data.data;
 if (!d || !d.lyrics) return reply(`Lirik "${text}" gak ketemu bro.`);

 // header info
 const header = `🎵 *${d.trackName || text}*${d.artistName ? ` — ${d.artistName}` : ''}\n──────────────────\n`;
 let lyrics = d.lyrics.trim();

 // normalize baris (hapus spasi awal & akhir tiap baris)
 let lines = lyrics.split(/\r?\n/).map(x => x.trim()).filter(x => x);

 // kasih 1 enter kosong tiap 4 baris -> biar keliatan bait
 let formatted = '';
 for (let i = 0; i < lines.length; i++) {
 formatted += lines[i] + '\n';
 if ((i + 1) % 4 === 0) formatted += '\n';
 }

 // max per message biar rapi
 const chunkSize = 3000;
 const chunks = formatted.match(new RegExp(`.{1,${chunkSize}}`, 'gs'));

 await RyuuBotz.sendMessage(m.chat, { text: header + chunks[0] }, { quoted: m });
 for (let i = 1; i < chunks.length; i++) {
 await RyuuBotz.sendMessage(m.chat, { text: chunks[i] }, { quoted: m });
 }

 } catch (e) {
 console.error('LIRIK ERROR:', e);
 reply('⚠️ Gagal ambil lirik, coba lagi nanti ya.');
 }
}
break
  case 'welcome': {
  if (!m.isGroup) return reply("khusus grup");
  if (!isAdmins && !isCreator) return reply("khusus admin");
  if (!db.groups) db.groups = {};
  if (!db.groups[m.chat]) db.groups[m.chat] = { welcome: false };

  if (!text) return reply(`Gunakan:\n.welcome on\n.welcome off\n.welcome set <teks>\n\nFormat teks bisa pakai:\n@user = mention member\n@group = nama grup`);

  if (text.toLowerCase() === 'on') {
    db.groups[m.chat].welcome = true;
    reply(`[ ✓ ] Welcome diaktifkan di grup ini.`);
  } else if (text.toLowerCase() === 'off') {
    db.groups[m.chat].welcome = false;
    reply(`[ x ] Welcome dimatikan di grup ini.`);
  } else if (text.toLowerCase().startsWith('set ')) {
    let teks = text.slice(4).trim();
    db.groups[m.chat].welcomeText = teks;
    reply(`[ ✓ ] Pesan welcome berhasil diatur:\n${teks}`);
  } else {
    reply(`Opsi tidak dikenal!`);
  }
  fs.writeFileSync('./database/welcome.json', JSON.stringify(db, null, 2));
}
break;

case 'goodbye': {
  if (!m.isGroup) return reply("khusus grup");
  if (!isAdmins && !isCreator) return reply("khusus admin");
  if (!db.groups) db.groups = {};
  if (!db.groups[m.chat]) db.groups[m.chat] = { goodbye: false };

  if (!text) return reply(`Gunakan:\n.goodbye on\n.goodbye off\n.goodbye set <teks>\n\nFormat teks bisa pakai:\n@user = mention member\n@group = nama grup`);

  if (text.toLowerCase() === 'on') {
    db.groups[m.chat].goodbye = true;
    reply(`[ ✓ ] Goodbye diaktifkan di grup ini.`);
  } else if (text.toLowerCase() === 'off') {
    db.groups[m.chat].goodbye = false;
    reply(`[ x ] Goodbye dimatikan di grup ini.`);
  } else if (text.toLowerCase().startsWith('set ')) {
    let teks = text.slice(4).trim();
    db.groups[m.chat].goodbyeText = teks;
    reply(`[ ✓ ] Pesan goodbye berhasil diatur:\n${teks}`);
  } else {
    reply(`Opsi tidak dikenal!`);
  }
  fs.writeFileSync('./database/welcome.json', JSON.stringify(db, null, 2));
}
break;
  case 'tourl': {
				if (!mime) return reply(`Kirim/Reply Video/Gambar Dengan Caption ${prefix + command}`);
				RyuuBotz.sendMessage(m.chat, { react: { text: "⏳️",key: m.key,}})
				try {
					let media = await RyuuBotz.downloadAndSaveMediaMessage(quoted);
					if (/image|video|audio/.test(mime)) {
						let response = await CatBox(media);
						let fileSize = (fs.statSync(media).size / 1024).toFixed(2);
						let uploadDate = new Date().toLocaleString();
						let uploader = `${pushname}`;
						let caption = `> ᴜᴋᴜʀᴀɴ ғɪʟᴇ : ${fileSize} ᴋʙ\n> ᴘᴇɴɢᴜɴɢɢᴀʜ : ${uploader}`.trim();

let msg = generateWAMessageFromContent(
    m.chat,
    {
      interactiveMessage: {
        header: {
          hasMediaAttachment: true,
          imageMessage: (
            await prepareWAMessageMedia(
              { image: { url: global.thumbnail } },
              { upload: RyuuBotz.waUploadToServer }
            )
          ).imageMessage
        },
        body: { text: caption },
        footer: { text: "Powered by ReinzID | Mahiru-MD" },
        nativeFlowMessage: {
          buttons: [
            {
              name: "cta_copy",
              buttonParamsJson: JSON.stringify({
                display_text: "📋 Copy Link",
                copy_code: response
              })
            }
          ]
        }
      }
    },
    { quoted: m }
  );

  await RyuuBotz.relayMessage(msg.key.remoteJid, msg.message, {
    messageId: msg.key.id
  });					} else if (!/image/.test(mime)) {
						let response = await CatBox(media);
						reply(response);
					} else {
						reply(`Jenis media tidak didukung!`);
					}
				fs.unlinkSync(media);
				} catch (err) {
					console.log(err);
					reply(`Gagal\n*Error:* ${err}`);
				}
			}
			break
//=================={{=[===================]]\\
case 'tourl2': {
  if (!quoted) return reply(`Reply gambar yang ingin di-upload!`)
  if (!/image|video/.test(mime)) return reply(`Itu bukan video/gambar!`)
  await RyuuBotz.sendMessage(m.chat, { react: { text: "⏳️",key: m.key,}})

  try {
    let mediaPath = await RyuuBotz.downloadAndSaveMediaMessage(quoted)

    const form = new FormData()
    form.append('file', fs.createReadStream(mediaPath))

    const res = await axios.post(
      'https://api.aceimg.com/api/upload',
      form,
      {
        headers: {
          ...form.getHeaders()
        }
      }
    )

    fs.unlinkSync(mediaPath)

    const data = res.data
    if (data.status && data.link) {
      // Ambil filename dari link
      const match = data.link.match(/f=([^\s]+)/)
      const filename = match ? match[1] : null

      if (filename) {
        const cdnLink = `https://cdn.aceimg.com/${filename}`
        const caption = 'Item kamu berhasil di upload';
        let msg = generateWAMessageFromContent(
        m.chat,
    {
      interactiveMessage: {
        header: {
          hasMediaAttachment: true,
          imageMessage: (
            await prepareWAMessageMedia(
              { image: { url: global.thumbnail } },
              { upload: RyuuBotz.waUploadToServer }
            )
          ).imageMessage
        },
        body: { text: caption },
        footer: { text: "Powered by ReinzID | Mahiru-MD" },
        nativeFlowMessage: {
          buttons: [
            {
              name: "cta_copy",
              buttonParamsJson: JSON.stringify({
                display_text: "📋 Copy Link",
                copy_code: cdnLink
              })
            }
          ]
        }
      }
    },
    { quoted: m }
  );

  await RyuuBotz.relayMessage(msg.key.remoteJid, msg.message, {
    messageId: msg.key.id
  });	
      } else {
        reply(`✅ Berhasil upload, tapi gagal ambil filename!\n🌐 Link: ${data.link}`)
      }

    } else {
      reply(`❌ Upload gagal!\n📄 ${data.message || 'Tidak diketahui'}`)
    }

  } catch (err) {
    console.error(err)
    reply(`❌ Upload error: ${err.response?.data?.message || err.message}`)
  }
}
break
  case 'daftar': case 'regis': case 'register': {
    if (isRegistered) return reply('ᴋᴀᴍᴜ ᴛᴇʟᴀʜ ᴛᴇʀᴅᴀғᴛᴀʀ');

    const input = text?.includes(',') ? text.split(',') : text?.includes('.') ? text.split('.') : [];
    if (input.length !== 2) return reply('Format Salah! Gunakan: .daftar nama,umur atau .daftar nama.umur');

    const nama = input[0].trim();
    const umur = input[1].trim();

    if (!nama || !umur || isNaN(umur)) return reply('Pastikan Nama dan Umur sudah diisi dengan benar!');
    if (parseInt(umur) > 30) return reply('Maaf, Umur Maksimal Untuk Daftar Adalah 30 Tahun!');

    const serialUser = createSerial(20);
    const detectOperator = (number) => {
  const prefix = number.slice(0, 4);
  const operators = {
    Telkomsel: [
      '0811', '0812', '0813', '0821', '0822', '0823', '0852', '0853', '0851' // Kartu As, Simpati, Loop, By.U
    ],
    Indosat: [
      '0814', '0815', '0816', '0855', '0856', '0857', '0858' // IM3, Matrix
    ],
    XL: [
      '0817', '0818', '0819', '0859', '0877', '0878' // XL, Axis
    ],
    Tri: [
      '0895', '0896', '0897', '0898', '0899'
    ],
    Smartfren: [
      '0881', '0882', '0883', '0884', '0885', '0886', '0887', '0888', '0889'
    ]
  };

  for (const [name, prefixes] of Object.entries(operators)) {
    if (prefixes.includes(prefix)) return name;
  }

  return 'Tidak Diketahui';
};
    const nomor = m?.sender.split('@')[0];
    const channelJid = '120363419884279670@newsletter';
    const operator = detectOperator(nomor.replace(/[^0-9]/g, '').replace(/^62/, '0').slice(0, 12));

    const mzd = `REGISTERED USERS\n` +
                `Nomor  : @${nomor}\n` +
                `Nama   : ${nama}\n` +
                `Umur   : ${umur}\n` +
                `Status : Sukses✅\n` +
                `Serial : ${serialUser}\n` +
                `Operator: ${operator}\n` +
                `Device: ${deviceinfo}\n\n` +     
                `ᴠᴇʀɪғɪᴋᴀsɪ sᴛᴀᴛᴜs`;

    const notifLog = `REGISTERED USERS\n` +
                `Nomor  : @${nomor}\n` +
                `Nama   : ${nama}\n` +
                `Umur   : ${umur}\n` +
                `Status : Sukses✅\n` +
                `Serial : ${serialUser}\n` +
                `Operator: ${operator}\n` +
                `Device: ${deviceinfo}\n\n` +     
                    `ɪɴғᴏ ʀᴇɢɪsᴛᴇʀ ʙʏ ${namabot}`;

    veri = m?.sender;
    addRegisteredUser(m?.sender, nama, serialUser);

    let ppuser;
    try {
       ppuser = await RyuuBotz.profilePictureUrl(m.sender, 'image');
    } catch {
      ppuser = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460960720.png?q=60';
    }

    RyuuBotz.sendMessage(m.chat, {
        text: mzd,
        contextInfo: {
            mentionedJid: [m.chat],
            externalAdReply: {
                title: m.isGroup ? 'R E G I S T E R' : '𝗡 𝗘 𝗪 - 𝗨 𝗦 𝗘 𝗥',
                body: '',
                thumbnailUrl: ppuser,
                sourceUrl: global.ceha,
                mediaType: 1,
                renderLargerThumbnail: false
            }
        }
    });
}
break;
case 'hidetag': case 'h': case 'ht': { 
if (!m.isGroup) return reply(mess.group)
if (!isAdmins && !isCreator) return reply('Khusus Admin!!')
if (!isBotAdmins) return reply('_Jadiin gw Admin Terlebih Dahulu_')
let mem = m.isGroup ? await groupMetadata.participants.map(a => a.id) : ""
RyuuBotz.sendMessage(m.chat, {
text: `@${m.chat}\n${text}`,
contextInfo: {
mentionedJid: mem, 
groupMentions: [
   {
groupSubject: `minna!!`,
groupJid: m.chat,
    },
   ],
  },
});
}
break;
case 'tagall': {
if (!m.isGroup) return reply(mess.group)
if (!isAdmins && !isCreator) return reply('Khusus Admin!!')
if (!isBotAdmins) return reply('_Bot Harus Menjadi Admin Terlebih Dahulu_')
me = m.sender
let teks = `╚»˙·٠${themeemoji}●♥ Tag All ♥●${themeemoji}٠·˙«╝ 
 
 😶 *penanda :*  @${me.split('@')[0]}
 🌿 *Isi pesan : ${q ? q : 'tidak ada pesan'}*\n\n`
for (let mem of participants) {
teks += `${themeemoji} @${mem.id.split('@')[0]}\n`
}
RyuuBotz.sendMessage(m.chat, { text: teks, mentions: participants.map(a => a.id) }, { quoted: m })
}
break
  case 'channel-log':
 case 'c-log': {
 if (!isCreator) return reply(mess.creator)
    if (!text) return reply(`Contoh penggunaan:\n${prefix + command} on\n${prefix + command} off`);
    
    if (text.toLowerCase() === 'on') {
        global.channel_log = true;
        reply(`✅ Channel log diaktifkan\nStatus c-log sekarang ${global.channel_log}`);
    } else if (text.toLowerCase() === 'off') {
        global.channel_log = false;
        reply(`✅ Channel log dimatikan.\nStatus c-log sekarang ${global.channel_log}`);
    } else {
        reply(`❌ Pilihan tidak valid.\nGunakan:\n${prefix + command} on\n${prefix + command} off`);
    }
}
break;
case 'mode':
case 'bot-mode': {
 if (!isCreator) return reply(mess.creator)
    if (!text) return reply(`Contoh penggunaan:\n${prefix + command} self\n${prefix + command} public\n\nStatus Self bot: *${global.self_}*`);
    
    if (text.toLowerCase() === 'self') {
        global.self_ = true;
        reply(`✅ Bot mode self aktif\nStatus self bot sekarang ${global.self_}`);
    } else if (text.toLowerCase() === 'public') {
        global.self_ = false;
        reply(`✅ Bot mode public.\nStatus self bot sekarang ${global.self_}`);
    } else {
        reply(`❌ Pilihan tidak valid.\nGunakan:\n${prefix + command} self\n${prefix + command} public`);
    }
}
break;
case 'loading-bar': 
case 'loading': {
 if (!isCreator) return reply(mess.creator)
    if (!text) return reply(`Contoh penggunaan:\n${prefix + command} on\n${prefix + command} off`);
    
    if (text.toLowerCase() === 'on') {
        global.BarLoad = true;
        reply(`✅ Loading Bar diaktifkan\nStatus Loading Bar sekarang ${global.BarLoad}`);
    } else if (text.toLowerCase() === 'off') {
        global.BarLoad = false;
        reply(`✅ Loading Bar dimatikan.\nStatus Loading Bar sekarang ${global.BarLoad}`);
    } else {
        reply(`❌ Pilihan tidak valid.\nGunakan:\n${prefix + command} on\n${prefix + command} off`);
    }
}
break;
case 'owner': {
try {
const owner = global.ownernumber
 function formatNomor(nomor) {
  nomor = nomor.replace(/\D/g, '');

  if (!nomor.startsWith('62')) return 'Format salah, harus diawali 62';

  const kodeNegara = '+62';
  const bagian1 = nomor.slice(2, 5);   
  const bagian2 = nomor.slice(5, 9);   
  const bagian3 = nomor.slice(9);     

  return `${kodeNegara} ${bagian1}-${bagian2}-${bagian3}`;
}
const nomorAsli = owner;
const ownerEdit = formatNomor(nomorAsli);

    const vcard = `
BEGIN:VCARD
VERSION:3.0
FN:Ryuu/Reinzz
ORG:The Developer Of Mahiru AI;
TEL;type=CELL;type=VOICE;waid=${owner}:${ownerEdit}
URL: https://api.ryuu-dev.offc.my.id
END:VCARD
    `.trim()

   await RyuuBotz.sendMessage(m.chat, {
      contacts: {
        displayName: "Ryuu Reinzz",
        contacts: [{ vcard }]
      },
      contextInfo: {
        externalAdReply: {
          title: "WhatsApp Business • Store",
          body: "The Developer Of Mahiru AI",
          thumbnailUrl: '' + global.thumbnail,
          sourceUrl: 'https://wa.me/6288246552068',
          mediaUrl: 'https://linkbio.co',
          mediaType: 1,
          renderLargerThumbnail: true
        }
      }
    }, { quoted : m })
    global.sleep(500)
    reply(`Semua transaksi di luar command \`.owner\` tidak di tanggung oleh developer asli *Ryuu Reinzz*, jika ada pembelian di luar command \`.owner\`, developer tidak bertanggung jawab atas apa yang terjadi`);
  } catch (e) {
     RyuuBotz.sendMessage(m.chat, {
      text: typeof e === 'string' ? e : '🚫 *Terjadi kesalahan saat memproses permintaan.*',
      quoted: m
    });
  } finally {
    await RyuuBotz.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
  }
  }
  break;
  case 'idch':
case 'cekidch': {
  if (!text) return reply("linkchnya mana?");
  if (!text.includes("https://whatsapp.com/channel/")) return reply("Link tautan tidak valid");

  let result = text.split('https://whatsapp.com/channel/')[1];
  let res = await RyuuBotz.newsletterMetadata("invite", result);

  let teks = `*ID:* ${res.id}
*Nama:* ${res.name}
*Total Pengikut:* ${res.subscribers}
*Status:* ${res.state}
*Verified:* ${res.verification === "VERIFIED" ? "Terverifikasi" : "Tidak"}`;

  // bikin pesan interactive
  let msg = generateWAMessageFromContent(m.chat, {
    interactiveMessage: {
      body: { text: teks },
      footer: { text: "powered by ReinzID | Mahiru-MD" },
      nativeFlowMessage: {
        buttons: [
          {
            name: "cta_copy",
            buttonParamsJson: JSON.stringify({
              display_text: "Copy ID",
              copy_code: res.id
            })
          }
        ]
      }
    }
  }, { quoted: m });

  // kirim pesan interactive
  await RyuuBotz.relayMessage(
    msg.key.remoteJid,
    msg.message,
    { messageId: msg.key.id }
  );
}
break;
  case 'afk': {
    let alasan = m.text.split(' ').slice(1).join(' ') || 'Tanpa alasan :v';
    let existing = afkDB.find(u => u.user === m.sender);

    if (existing) {
        existing.afkTime = Date.now();
        existing.alasan = alasan;
    } else {
        afkDB.push({
            user: m.sender,
            afkTime: Date.now(),
            alasan: alasan
        });
    }

    saveAFK();
    replyafk(`@${m.sender.split("@")[0]} sekarang AFK${alasan ? ` dengan alasan: ${alasan}` : ''}`);
}
break;
  case 'addweb': {
addweb(m, RyuuBotz, text, prefix, reply, qmsg, isCreator, mess, example); }
break;
case 'delweb': {
delweb(m, RyuuBotz, text, reply, isCreator, mess); }
break;
case 'listweb': {
listweb(m, reply, isCreator, mess); }
break;
case 'scweb':
case 'gethtml': {
gethtml(m, RyuuBotz, text, reply, isCreator, mess); 
}
break
case 'clear-session': {
    const sessionFolder = path.join(__dirname, "session");
    const safeFile = "creds.json";
    const files = fs.readdirSync(sessionFolder).filter(file => file !== safeFile);

    if (files.length === 0) {
        reply("✨ Tidak ada file yang perlu dihapus, Ryuu-kun 💗");
    } else {
        files.forEach(file => fs.unlinkSync(path.join(sessionFolder, file)));
        reply(`🧹 ${files.length} file terhapus:\n${files.join("\n")}`);
    }
}
break;
case 'arting': {
  RyuuBotz.sendMessage(m.chat, { react: { text: '🕒', key: m.key }})
    try {
        let prompt = text?.trim();
        if (!prompt) return reply(`❌ Masukkan prompt gambar.\nContoh: ${prefix + command} loli imut`);

        const base = `https://aiqtech-nsfw-real.hf.space`;
        const session_hash = Math.random().toString(36).slice(2);

        // Step 1: Join queue
        await axios.post(`${base}/gradio_api/queue/join`, {
            data: [
                prompt
            ],
            event_data: null,
            fn_index: 9, 
            trigger_id: 16,
            session_hash
        });

        // Step 2: Polling hasil
        let resultUrl = null;
        const startTime = Date.now();
        while (Date.now() - startTime < 20000) {
            const { data: raw } = await axios.get(`${base}/gradio_api/queue/data?session_hash=${session_hash}`, {
                responseType: 'text'
            });

            const lines = raw.split('\n\n');
            for (const line of lines) {
                if (line.startsWith('data:')) {
                    const json = JSON.parse(line.slice(6));
                    if (json.msg === 'process_completed') {
                        resultUrl = json.output?.data?.[0]?.url;
                        break;
                    }
                }
            }

            if (resultUrl) break;
            await new Promise(r => setTimeout(r, 1500));
        }

        if (!resultUrl) return reply(`⚠️ Limit atau timeout, coba lagi nanti.`);

        // Step 3: Kirim gambar
        RyuuBotz.sendMessage(m.chat, { image: { url: resultUrl }, caption: `✅ Gambar berhasil dibuat.` }, { quoted: m });

    } catch (err) {
        console.error(err);
        reply(`⚠️ Terjadi kesalahan saat membuat gambar.\n*Message:* ${err}`);
    }
}
break;
case 'smeme': case 'stickermeme': case 'stickmeme': {
if (!/webp/.test(mime) || /image/.test(mime)) {
if (!text) return reply(`Kirim/reply Gambar Dengan Caption ${prefix + command}
 text1|text2`)
 async function UploadFileUgu (input) {
	return new Promise (async (resolve, reject) => {
			const form = new BodyForm();
			form.append("files[]", fs.createReadStream(input))
			await axios({
				url: "https://uguu.se/upload.php",
				method: "POST",
				headers: {
					"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36",
					...form.getHeaders()
				},
				data: form
			}).then((data) => {
				resolve(data.data.files[0])
			}).catch((err) => reject(err))
	})
}
let atas = text.split('|')[0] ? text.split('|')[0] : '-'
let bawah = text.split('|')[1] ? text.split('|')[1] : '-'
let mee = await RyuuBotz.downloadAndSaveMediaMessage(quoted)
let mem = await UploadFileUgu(mee)
let meme = `https://api.ryuu-dev.offc.my.id/tools/smeme?img=${mem.url}&atas=${encodeURIComponent(atas)}&bawah=${encodeURIComponent(bawah)}`
RyuuBotz.sendMessage(m.chat, { react: { text: '🕒', key: m.key }})
let memek = await RyuuBotz.sendImageAsSticker(m.chat, meme, m, { packname: global.packname, author: global.author })
RyuuBotz.sendMessage(m.chat, { react: { text: '✅', key: m.key }})
} else {
reply(`Kirim/reply Gambar Dengan Caption ${prefix + command}
 text1|text2`)
}
}
break
case 'brat2': {

  // Daftarin font teks dan emoji (pastikan file TTF-nya ada di folder lib)
  GlobalFonts.registerFromPath('./lib/arialnarrow.ttf', 'Arial Narrow');
  GlobalFonts.registerFromPath('./lib/NotoColorEmoji.ttf', 'Noto Color Emoji');

  async function BratGenerator(teks) {
    let width = 512;
    let height = 512;
    let margin = 20;
    let wordSpacing = 50;
    let fontSize = 280;
    let lineHeightMultiplier = 1.3;

    const canvas = createCanvas(width, height);
    const ctx = canvas.getContext('2d');

    ctx.fillStyle = 'white';
    ctx.fillRect(0, 0, width, height);
    ctx.textAlign = 'left';
    ctx.textBaseline = 'top';
    ctx.fillStyle = 'black';

    let words = teks.split(' ');
    let lines = [];

    function rebuildLines() {
      lines = [];
      let currentLine = '';
      for (let word of words) {
        let testLine = currentLine ? `${currentLine} ${word}` : word;
        ctx.font = `${fontSize}px "Arial Narrow", "Noto Color Emoji"`;
        let lineWidth =
          ctx.measureText(testLine).width +
          (currentLine.split(' ').length - 1) * wordSpacing;
        if (lineWidth < width - 2 * margin) {
          currentLine = testLine;
        } else {
          lines.push(currentLine);
          currentLine = word;
        }
      }
      if (currentLine) lines.push(currentLine);
    }

    ctx.font = `${fontSize}px "Arial Narrow", "Noto Color Emoji"`;
    rebuildLines();

    while (lines.length * fontSize * lineHeightMultiplier > height - 2 * margin) {
      fontSize -= 2;
      ctx.font = `${fontSize}px "Arial Narrow", "Noto Color Emoji"`;
      rebuildLines();
    }

    let lineHeight = fontSize * lineHeightMultiplier;
    let y = margin;
    for (let line of lines) {
      let wordsInLine = line.split(' ');
      let x = margin;
      for (let word of wordsInLine) {
        ctx.fillText(word, x, y);
        x += ctx.measureText(word).width + wordSpacing;
      }
      y += lineHeight;
    }

    let buffer = await canvas.encode('png');
    let image = await Jimp.read(buffer);
    image.blur(3);
    let blurredBuffer = await image.getBufferAsync(Jimp.MIME_PNG);

    return RyuuBotz.sendImageAsSticker(m.chat, blurredBuffer, m, {
      packname: global.packname,
      author: global.author
    });
  }

  if (!text) return reply(`Masukkan teks untuk stiker.\n\nContoh:\n.brat2 Aku 🥺 Sayang Kamu 💗`);
  return BratGenerator(text);
}
break;
  case 'prefix': {
    if (!text) return reply(`Contoh penggunaan:\n${prefix}prefix on\n${prefix}prefix off`);
    
    if (text.toLowerCase() === 'on') {
        global.pref = true;
        reply(`✅ Prefix diaktifkan.\nPrefix sekarang: "${global.prefix}"`);
    } else if (text.toLowerCase() === 'off') {
        global.pref = false;
        reply(`✅ Prefix dimatikan.\nSekarang command tanpa prefix.`);
    } else {
        reply(`❌ Pilihan tidak valid.\nGunakan:\n${prefix}prefix on\n${prefix}prefix off`);
    }
}
break;
case 'hd':
case 'remini': {
  if (!/image/.test(mime) || !quoted) return reply(`Kirim/reply Foto dengan caption ${prefix + command}`);

  await RyuuBotz.sendMessage(m.chat, { react: { text: `⏳️`, key: m.key } });

  try {
    let mediaPath = await RyuuBotz.downloadAndSaveMediaMessage(quoted);
    let fileSize = (fs.statSync(mediaPath).size / 1024).toFixed(2);

async function UploadFileUgu (input) {
	return new Promise (async (resolve, reject) => {
			const form = new BodyForm();
			form.append("files[]", fs.createReadStream(input))
			await axios({
				url: "https://uguu.se/upload.php",
				method: "POST",
				headers: {
					"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36",
					...form.getHeaders()
				},
				data: form
			}).then((data) => {
				resolve(data.data.files[0])
			}).catch((err) => reject(err))
	})
}
let mem = await UploadFileUgu(mediaPath)
    const apiKey = 'RyuuGanteng';
    const apiUrl = `https://api.ryuu-dev.offc.my.id/imagecreator/remini?apikey=${apiKey}&url=${mem.url}`;

    const { data } = await axios.get(apiUrl,
     {
      headers: { 'Content-Type': 'application/json', 'User-Agent': 'RyuuBotz/1.0' }
    });

    if (!data.status || !data.result) {
      throw new Error('Remini API gagal memproses gambar');
    }

    await RyuuBotz.sendMessage(m.chat, {
      image: { url: data.result },
      caption: `_Sudah HD kak_\nUkuran file asli: ${fileSize} KB`
    }, { quoted: m });

    fs.unlinkSync(mediaPath);

  } catch (err) {
    console.error(err);
    reply(`Ups, terjadi kesalahan. Laporkan ke owner ya.\n*Makan tuh Error:* ${err.message}`);
  }
}
break;
      case "runtime":
      {
        let lowq = `*@${botNumber.split("@")[0]} Telah Online Selama:*\n${runtime(
          process.uptime(),
        )}`;
        reply_(`${lowq}`);
      }
      break      

case 'kick':
case 'duar':
case 'dor':
{
 if (!m.isGroup) return reply('Perintah ini khusus admin grup dan hanya bisa digunakan di dalam grup.');

 if (!isAdmins && !isCreator) return reply(mess.admin);
 
 if (!isBotAdmins) return reply('_Bot harus menjadi admin terlebih dahulu untuk mengeluarkan anggota._');

 let users;
 if (m.mentionedJid.length > 0) {
 users = m.mentionedJid[0];
 } else if (m.quoted) {
 users = m.quoted.sender;
 } else if (text) {
 let number = text.replace(/[^0-9]/g, '');
 if (number.length < 5) return reply('Nomor tidak valid!');
 users = number + '@s.whatsapp.net';
 } else {
 return reply('Silakan tag, reply pesan, atau masukkan nomor yang ingin dikick!');
 }

 try {
 await RyuuBotz.sendMessage(m.chat, {
 sticker: fs.readFileSync('./stiker/kick.webp')
}, { quoted: m });

 await RyuuBotz.groupParticipantsUpdate(m.chat, [users], 'remove');
 reply(`Sukses mengeluarkan @${users.split('@')[0]}`, { mentions: [users] });
 } catch (e) {
 console.error(e);
 reply('Gagal mengeluarkan anggota. Mungkin karena bot bukan admin atau mencoba mengeluarkan sesama admin.');
 }
}
break;
case 'add': {
 try {
 if (!m.isGroup) return reply(mess.group)
 if (!isBotAdmins) return reply(mess.botAdmin)
 let users = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
 await RyuuBotz.groupParticipantsUpdate(m.chat, [users], 'add')
 await reply(`✅ Berhasil menambahkan anggota!`)
 } catch (err) {
 await reply(`❌ Gagal menambahkan anggota!\nError: ${err}`)
 }
}
break

case "1x-liat":
case "rvo-ft":
case "getimg":
case "getft": {

 if (!m.quoted || typeof m.quoted.download !== "function") {
 return reply(`Reply gambar 1x liat yang ingin di ambil dengan perintah *${prefix + command}*`);
 }

 const mime = m.quoted.mimetype || "";
 if (!/image\/(jpe?g|png)/.test(mime)) {
 return reply(`Media yang direply bukan gambar. Hanya mendukung jpg/jpeg/png`);
 }

 reply("Mengambil gambar...");
 try {
 const imgBuffer = await m.quoted.download();

 await RyuuBotz.sendMessage(m.chat, {
 image: imgBuffer,
 caption: "*Berhasil mengambil gambar!*"
 }, { quoted: m });
 } catch (err) {
 console.error(err);
 reply(`Gagal mengirim ulang gambar: ${err.message}`);
 }
}
break;



case 'delete':
 case 'cuih': 
 case 'piu': 
 case 'del': { 
if (!isAdmins) return reply(global.mess.admin)
if (!m.isGroup) return reply(global.mess.group) 
if (!m.quoted) return reply('mau hapus apa jir?');
let { chat, id } = m.quoted
await RyuuBotz.sendMessage(m.chat, {
 sticker: fs.readFileSync('./stiker/ancam.webp')
}, { quoted: m });
 RyuuBotz.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.quoted.id, participant: m.quoted.sender } })
 }
 break
case 'addcase': {
 if (!isCreator) return reply(mess.creator)
 if (!text) return reply('Mana case nya');
const namaFile = 'case.js';
const caseBaru = `${text}`;
fs.readFile(namaFile, 'utf8', (err, data) => {
    if (err) {
        console.error('Terjadi kesalahan saat membaca file:', err);
        return;
    }
    const posisiAwalGimage = data.indexOf("case 'addcase':");

    if (posisiAwalGimage !== -1) {
        const kodeBaruLengkap = data.slice(0, posisiAwalGimage) + '\n' + caseBaru + '\n' + data.slice(posisiAwalGimage);
        fs.writeFile(namaFile, kodeBaruLengkap, 'utf8', (err) => {
            if (err) {
                reply('Terjadi kesalahan saat menulis file:', err);
            } else {
                reply('Sukses Menambahkan Fitur\nJika Ingin Menginfokan Ss Dan Reply Ssan Barcaption .newfitur');
            }
        });
    } else {
        reply('Tidak dapat menambahkan case dalam file.');
    }
});

}
break
case 'getcase': {       
 if (!isCreator) return reply('Fitur Khusus Owner!')
 if (!text) return reply('Case apa bang?');

    try {
        const fileContent = fs.readFileSync('./case.js', 'utf8')

        const casePattern1 = `case "${text}"`
        const casePattern2 = `case '${text}'`

        let startIndex = -1
        let caseDeclaration = ''

        if (fileContent.includes(casePattern1)) {
            startIndex = fileContent.indexOf(casePattern1)
            caseDeclaration = casePattern1
        } else if (fileContent.includes(casePattern2)) {
            startIndex = fileContent.indexOf(casePattern2)
            caseDeclaration = casePattern2
        } else {
            return reply(`❌ Case "${text}" tidak ditemukan.`)
        }

        const caseContentFromStart = fileContent.substring(startIndex)
        const breakIndex = caseContentFromStart.indexOf('break')

        if (breakIndex === -1) return reply('❌ Tidak menemukan akhir dari case (break).')

        const finalCaseContent = caseContentFromStart.substring(0, breakIndex + 5) // +5 karena 'break'.length == 5
        reply(`✅ Isi case *${text}*:\n\n\`\`\`js\n${finalCaseContent}\n\`\`\``)

    } catch (err) {
        console.error(err)
        reply('❌ Terjadi kesalahan saat mengambil case.')
    }
    }
    break
            case 'delcase': {
                if (!isCreator) return reply('Fitur Khusus Owner!')
                if (!text) return reply('Mana case nya bang?');
                dellCase('./case.js', q)
                reply('Berhasil menghapus case!.');
            }
            break
      case "addprem": {
    if (!isCreator) return
    if (!args[0]) return reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} ${global.owner}`)
   let prrkek = q.split("|")[0].replace(/[^0-9]/g, '') + `@s.whatsapp.net`
    let ceknya = await RyuuBotz.onWhatsApp(prrkek) // Mengecek Apkah Nomor ${prrkek} Terdaftar Di WhatsApp 
    if (ceknya.length == 0) return reply(`Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp!!!`)
    premium.push(prrkek)
    fs.writeFileSync("./database/premium.json", JSON.stringify(premium))
    reply(`Successfully Added ${prrkek} To Database`)
}
break
case "delprem": {
    if (!isCreator) return
    if (!args[0]) return reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} ${global.owner}`)
    let ya = q.split("|")[0].replace(/[^0-9]/g, '') + `@s.whatsapp.net`
    let unp = premium.indexOf(ya)
    premium.splice(unp, 1)
    fs.writeFileSync("./database/premium.json", JSON.stringify(premium))
    reply(`Successfully Removed ${ya} From Database`)
}
break
case "listprem": {
if (!isCreator) return reply("❗ *Access Denied*\nFitur Only `Owner`")
 let premList = JSON.parse(fs.readFileSync("./database/premium.json"));
 
 if (premList.length === 0) return reply("⚠️ Tidak ada Premium yang terdaftar!");
 let text = "💭 *Daftar Premium:*\n\n";
 premList.forEach((prrem, index) => {
 text += `- ${index + 1}. @${prrem}\n`;
 });
 RyuuBotz.sendMessage(m.chat, { text, mentions: premList.map(v => v + "@s.whatsapp.net") }, { quoted: qtext });
}
break;
      
    default:
    
if (budy.startsWith('=>')) {
    if (!isCreator) return

    function Return(sul) {
        sat = JSON.stringify(sul, null, 2)
        bang = util.format(sat)
        if (sat == undefined) {
            bang = util.format(sul)
        }
        return reply(bang)
    }
    try {
        reply(util.format(eval(`(async () => { return ${budy.slice(3)} })()`)))
    } catch (e) {
        reply(String(e))
    }
}

if (budy.startsWith('>')) {
    if (!isCreator) return;
    try {
        let evaled = await eval(budy.slice(2));
        if (typeof evaled !== 'string') evaled = util.inspect(evaled);
        await reply(evaled);
    } catch (err) {
        await reply(String(err));
    }
}

if (budy.startsWith('$')) {
    if (!isCreator) return
    exec(budy.slice(2), (err, stdout) => {
        if (err) return reply(`${err}`)
        if (stdout) return reply(stdout)
    })
}

}
} catch (err) {
    console.log(util.format(err))
}
}
export default caseHandler;
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
let file = __filename;
fs.watchFile(file, async () => {
    fs.unwatchFile(file);
    console.log(chalk.redBright(`Update ${file}`));
    try {
        const module = await import(`${file}?update=${Date.now()}`); 
    } catch (err) {
        console.error(err);
    }
});

