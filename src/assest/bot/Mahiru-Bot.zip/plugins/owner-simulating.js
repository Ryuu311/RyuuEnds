require('../settings');

let handler = async (m, { RyuuBotz, args, isBotAdmins, isAdmins, isCreator, reply }) => {
  if (!m.isGroup) return reply(mess.group)
  if (!isBotAdmins) return reply(`Bot harus menjadi admin untuk menggunakan fitur ini.`)
  if (!isCreator) return reply(mess.creator)

  const keyword = args[0]?.toLowerCase()
  if (!keyword || !['add', 'out'].includes(keyword))
    return reply(`Gunakan format:\n.simulating add\n.simulating out`)

  const fakeUser = m.sender // Pengirim sebagai target simulasi

  if (keyword === 'add') {
    RyuuBotz.ev.emit('group-participants.update', {
      id: m.chat,
      participants: [fakeUser],
      action: 'add',
    })
    reply(`Simulasi pengguna masuk berhasil.`)
  } else if (keyword === 'out') {
    RyuuBotz.ev.emit('group-participants.update', {
      id: m.chat,
      participants: [fakeUser],
      action: 'remove',
    })
    reply(`Simulasi pengguna keluar berhasil.`)
  }
}

handler.command = ["simulating"]
module.exports = handler;