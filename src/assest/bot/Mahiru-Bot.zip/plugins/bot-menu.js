require('../settings')
const fs = require("fs");
const { runtime } = require("../lib/myfunc");

let handler = async (m, { RyuuBotz, reply, pushname, isPremium, isCreator }) => {
  try {
    await RyuuBotz.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key } });

    // fungsi hitung user terdaftar
    function countIdsFromFile(path = "./database/registered.json") {
      try {
        const rawData = fs.readFileSync(path);
        const database = JSON.parse(rawData);
        return database.length;
      } catch (err) {
        console.error("❌ Gagal membaca file:", err.message);
        return 0;
      }
    }

    const totalIds = countIdsFromFile();
    const kosong = global.kosong;
    const status = isPremium ? "ᴘʀᴇᴍɪᴜᴍ ✓" : "ғʀᴇᴇ 𝕏";
    const status_ = isCreator ? "ᴏᴡɴᴇʀ👑" : `${status}`;

    const ReinzID_sad = `*Konnichiwa ${pushname}!*  
Aku adalah *${global.namabot}*, asisten virtualmu 💫

╭─⌈ *𝙄𝙉𝙁𝙊 𝙐𝙎𝙀𝙍* ⌋
│◦ ɴᴀᴍᴀ : *${pushname}*
│◦ sᴛᴀᴛᴜs : *${status_}*
│◦ ɴᴏᴍᴏʀ : @${m.sender.split("@")[0]}
╰─────────────

╭─⌈ *𝙊𝙒𝙉𝙀𝙍 𝙄𝙉𝙁𝙊* ⌋
│𖥔 ᴄʀᴇᴀᴛᴏʀ : ${global.ownername}
│𖥔 ɴᴀᴍᴀ ʙᴏᴛ : ${global.namabot}
│𖥔 ᴠᴇʀsɪ : 1.0.0
│𖥔 ᴛʏᴘᴇ : ᴄᴀsᴇ x ᴘʟᴜɢɪɴ
╰─────────────

╭─⌈ *𝘽𝙊𝙏 𝙎𝙏𝘼𝙏𝙐𝙎* ⌋
│◦ ɴᴀᴍᴀ : *${global.namabot}*
│◦ ʀᴜɴᴛɪᴍᴇ : *${runtime(process.uptime())}*
│◦ ᴅᴇᴠᴇʟᴏᴘᴇʀ : *${global.ownername}*
│◦ ᴍᴏᴅᴇ : *${self_ ? "Self" : "Public"}*
│◦ ᴘᴇɴɢɢᴜɴᴀ : *${totalIds}*
╰─────────────
${kosong}
┏『 *乂 SYSTEM - CORE 乂* 』━━◧
║◦ ${prefix}ping        
║◦ ${prefix}runtime    
║◦ ${prefix}c-log        
║◦ ${prefix}loading-bar  
║◦ ${prefix}bot-mode    
║◦ ${prefix}prefix        
║◦ ${prefix}addcase     
║◦ ${prefix}delcase      
║◦ ${prefix}getcase      
║◦ ${prefix}addplugin    
║◦ ${prefix}delplugin     
║◦ ${prefix}getplugin     
┗━━━━━━━━━━━━━━━━⊱

┏『 *乂 FUN - INTERFACE 乂* 』━━◧
║◦ ${prefix}sticker       
║◦ ${prefix}smeme      
║◦ ${prefix}play         
║◦ ${prefix}ytmp3       
║◦ ${prefix}ytmp4
║◦ ${prefix}yytmp3
║◦ ${prefix}yytmp4
║◦ ${prefix}yttmp3
║◦ ${prefix}yttmp4
║◦ ${prefix}tiktok      
┗━━━━━━━━━━━━━━━━⊱

┏『 *乂 AI - MODULE 乂* 』━━◧
║◦ ${prefix}mahiru    ⌲ Istri owner :v
║◦ ${prefix}aoi         
║◦ ${prefix}karin       
║◦ ${prefix}mongfa    
║◦ ${prefix}amelia     
║◦ ${prefix}iroha       
║◦ ${prefix}ailabs       
┗━━━━━━━━━━━━━━━━⊱

┏『 *乂 TOOLS 乂* 』━━◧
║◦ ${prefix}remini     
║◦ ${prefix}cekidch    
║◦ ${prefix}tourl       
║◦ ${prefix}tourl2      
║◦ ${prefix}aiedit       
║◦ ${prefix}hidetag   
║◦ ${prefix}tagall    
║◦ ${prefix}brat2        
║◦ ${prefix}brat        
║◦ ${prefix}bratnime   
┗━━━━━━━━━━━━━━━━━━━━⊱

┏『 *乂 GROUP - INTERFACE 乂* 』━━◧
║◦ .welcome       
║◦ .goodbye      
║◦ .simulating         
║◦ .add       
║◦ .kick      
┗━━━━━━━━━━━━━━━━⊱`;

    await RyuuBotz.sendMessage(
      m.chat,
      {
        video: fs.readFileSync("./database/assest/thumbvid.mp4"),
        gifPlayback: true,
        caption: ReinzID_sad,
        contextInfo: {
          mentionedJid: [m.sender],
          forwardingScore: 1,
          isForwarded: true,
          forwardedNewsletterMessageInfo: {
            newsletterName: global.namabot,
            newsletterJid: "120363419382206255@newsletter",
          },
          externalAdReply: {
            title: global.namabot,
            body: global.ownername,
            thumbnailUrl: `${global.thumbnail}`,
            sourceUrl: `https://whatsapp.com/channel/0029Vb49CCWJ93wO2dLDqx14`,
            mediaType: 1,
            renderLargerThumbnail: true,
          },
        },
      },
      { quoted: m }
    );

    // kirim backsound ptt
    const musik = {
      audio: fs.readFileSync("./database/assest/menu.mp3"),
      mimetype: "audio/mp4",
      ptt: true,
    };
    await RyuuBotz.sendMessage(m.chat, musik, { quoted: m });
  } catch (err) {
    console.error("❌ Terjadi kesalahan di menu plugin:", err);
    await RyuuBotz.sendMessage(
      m.chat,
      { text: `⚠️ Ups, ada error: ${err.message}` },
      { quoted: m }
    );
  }
};

handler.command = ["menu"];
module.exports = handler;
