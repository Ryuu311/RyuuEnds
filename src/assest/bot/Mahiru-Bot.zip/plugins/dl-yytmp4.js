const fetch = require('node-fetch');

let handler = async (m, { text, prefix, RyuuBotz, reply }) => {
  if (!text) return reply(`*Example:* ${prefix}ytmp4 https://youtube.com/watch?v=czQ2KID9plQ`);
  if (!text.includes('youtu')) return reply('Masukkan link YouTube yang valid!');
  
  await RyuuBotz.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

  try {
    const res = await fetch(`https://api.ryuu-dev.offc.my.id/download/ytplay?url=${encodeURIComponent(text)}`);
    if (!res.ok) throw new Error(await res.text());
    
    const json = await res.json();
    if (!json?.status || !json?.output?.videoUrl) return reply('❌ Gagal mengambil video.');

    const { title, thumbnail, videoUrl } = json.output;

    await RyuuBotz.sendMessage(m.chat, {
      image: { url: thumbnail },
      caption: `🎬 *YouTube Video Found!*\n\n📺 *Title:* ${title}\nVideo:${videoUrl}\n\n_Mengirim video..._`    }, { quoted: m });

    await RyuuBotz.sendMessage(m.chat, {
      video: { url: videoUrl },
      caption: title
    }, { quoted: m });

  } catch (err) {
    console.error('YTMP4 Error:', err);
    reply(`❌ Error saat memproses video:\n${err.message || err}`);
  }
};

handler.command = ["ytmp4"];
handler.tags = ["downloader"];
handler.help = ["ytmp4 <url>"];

module.exports = handler;
